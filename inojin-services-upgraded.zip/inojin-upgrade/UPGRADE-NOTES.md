# Inojin Services — Upgrade Notes

## Contact and social links
- Added the Facebook profile URL provided by the owner to the shared site settings.
- Added the Instagram profile `@yameinojin` to the shared site settings.
- Made both social profiles clickable on the Contact page, homepage contact section, and footer.
- Added a clear external-link indicator to social follow links.

## Service detail improvements
- Added expanded, category-aware scope guidance for all 236 listed services across 10 categories.
- Service detail pages now include “What's included”, “What to prepare”, “What you can expect”, and “Scope & limitations” sections.
- Added extra guidance for matched service types such as official phone recovery, backups/data transfers, system reinstalls, Wi-Fi/router troubleshooting, branding, social graphics, presentations, account/database/payment-connected websites, landing pages, captions, thumbnails, spreadsheets, forms, and coding lessons.
- Extended service search so it can find terms inside service guidance and scope notes, not only titles and one-line summaries.
- Kept prices unpublished where no official amount exists and avoided adding unsupported promises or fake reviews.

## Verification
- Passed TypeScript/TSX syntax transpilation checks on the modified source files.
- Passed catalog smoke tests: 236 services, 10 categories, unique service IDs, and a complete guide for every service.
- Full app build/browser verification could not be run in this export because project dependencies were not present and `npm ci` timed out in this environment.
