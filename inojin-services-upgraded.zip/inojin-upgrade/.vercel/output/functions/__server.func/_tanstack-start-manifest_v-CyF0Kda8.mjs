//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CyF0Kda8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/faq",
			"/portfolio",
			"/privacy",
			"/request",
			"/services",
			"/support",
			"/terms"
		],
		preloads: [
			"/assets/index-BOU0rQeE.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/react-Biqg-U6H.js",
			"/assets/preload-helper-CsPsu6O_.js",
			"/assets/link-HSHRxg1o.js",
			"/assets/useMatch-Yo1WJmew.js",
			"/assets/root-DLTE-HSj.js",
			"/assets/useSelector-CRqqBMds.js",
			"/assets/matchContext-wephjrwY.js",
			"/assets/site-Dahv1MJG.js",
			"/assets/catalog-D2LqbX2F.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BOU0rQeE.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B_iQqPNY.js",
			"/assets/useNavigate-C4PZbXRq.js",
			"/assets/concept-board-oL6dz2m8.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-CqeZpLOO.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-Crd2Ksqu.js", "/assets/inquiry-form-CjapX5Ew.js"]
	},
	"/faq": {
		filePath: "/workspace/src/routes/faq.tsx",
		children: void 0,
		preloads: ["/assets/faq-C_gcLOfh.js"]
	},
	"/portfolio": {
		filePath: "/workspace/src/routes/portfolio.tsx",
		children: void 0,
		preloads: ["/assets/portfolio-B14BUbXC.js", "/assets/concept-board-oL6dz2m8.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-CBBSnENl.js"]
	},
	"/request": {
		filePath: "/workspace/src/routes/request.tsx",
		children: void 0,
		preloads: ["/assets/request-ztuPoIob.js", "/assets/inquiry-form-CjapX5Ew.js"]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: ["/services/$serviceId", "/services/"],
		preloads: ["/assets/services-BNzgUVdQ.js"]
	},
	"/support": {
		filePath: "/workspace/src/routes/support.tsx",
		children: void 0,
		preloads: ["/assets/support-bkF6RE1A.js"]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-CjBjNcY_.js"]
	},
	"/services/$serviceId": {
		filePath: "/workspace/src/routes/services.$serviceId.tsx",
		children: void 0,
		preloads: ["/assets/services._serviceId-BFvAYof_.js"]
	},
	"/services/": {
		filePath: "/workspace/src/routes/services.index.tsx",
		children: void 0,
		preloads: ["/assets/services.index-DqG6wONM.js", "/assets/useNavigate-C4PZbXRq.js"]
	}
} });
//#endregion
export { tsrStartManifest };
