import { i as __toESM } from "../_runtime.mjs";
import { n as site } from "./site-DBkIVCbS.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as categories, o as DonationPanel } from "./router-BIUHyiyQ.mjs";
import { n as portfolio, t as ConceptBoard } from "./concept-board-DcmtTyMO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Du2BFLsh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var featured = categories.slice(0, 6);
var more = categories.slice(6);
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid w-full max-w-6xl items-end gap-10 px-5 py-12 lg:grid-cols-12 lg:py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
							children: "Inojin Services"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 font-display text-4xl font-semibold leading-tight tracking-tight text-ink sm:text-6xl",
							children: site.heroTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-lg text-ink-soft",
							children: site.heroText
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm font-medium text-ink",
							children: site.tagline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/services",
								search: {
									category: "all",
									q: "",
									group: "all"
								},
								className: "inline-flex min-h-11 items-center bg-teal-deep px-5 font-semibold text-paper hover:bg-navy",
								children: site.copy.explore
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/request",
								search: { service: "" },
								className: "inline-flex min-h-11 items-center border border-ink px-5 font-semibold text-ink hover:bg-ink hover:text-paper",
								children: site.copy.start
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchStrip, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "lg:col-span-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/desk.jpg",
						alt: "Studio desk with a navy laptop, a phone, and printed sheets",
						className: "aspect-[16/10] w-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "mt-2 text-sm text-ink-soft",
						children: "Studio photograph for the site. Not a client project."
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto w-full max-w-6xl px-5 py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl text-ink",
						children: "Service categories"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/services",
						search: {
							category: "all",
							q: "",
							group: "all"
						},
						className: "text-sm font-semibold text-teal-deep underline underline-offset-4",
						children: "Full list"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 divide-y divide-line border-y border-line",
					children: featured.map((category, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/services",
						search: {
							category: category.id,
							q: "",
							group: "all"
						},
						className: "grid gap-2 py-5 sm:grid-cols-[4rem_1fr_auto] sm:items-baseline",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-display text-2xl text-teal-deep",
								children: ["0", index + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-3xl text-ink",
								children: category.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block max-w-xl text-ink-soft",
								children: category.blurb
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold text-teal-deep",
								children: "Browse"
							})
						]
					}) }, category.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 flex flex-wrap gap-3",
					children: more.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/services",
						search: {
							category: category.id,
							q: "",
							group: "all"
						},
						className: "inline-flex min-h-11 items-center border border-line px-3 text-sm font-semibold hover:border-ink",
						children: category.name
					}) }, category.id))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line bg-paper-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-6xl px-5 py-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl text-ink",
						children: "Featured work"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-ink-soft",
						children: site.copy.portfolioNote
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-ink",
						children: "Every item below is labeled. None of it is presented as a client commission."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
						children: portfolio.slice(0, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border border-line bg-paper",
							children: [item.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.image,
								alt: item.imageAlt ?? item.title,
								className: "aspect-[4/3] w-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConceptBoard, {
								kind: item.kind,
								title: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
									children: item.status
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-display text-xl text-ink",
									children: item.title
								})]
							})]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/portfolio",
						className: "mt-6 inline-flex min-h-11 items-center font-semibold text-teal-deep underline underline-offset-4",
						children: "Open the gallery"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid w-full max-w-6xl gap-12 px-5 py-14 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl text-ink",
				children: "How it works"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-6 space-y-5",
				children: site.copy.steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-[3rem_1fr] gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-2xl text-teal-deep",
						children: ["0", index + 1]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pt-1 text-ink",
						children: step
					})]
				}, step))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl text-ink",
				children: "Why Inojin Services"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-5",
				children: site.copy.why.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-t border-line pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-ink",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-ink-soft",
						children: item.text
					})]
				}, item.title))
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-6xl px-5 py-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl text-ink",
					children: "Client notes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-ink-soft",
					children: "No customer testimonials are published yet. When someone gives permission, their words can be added here. This site does not invent reviews, names, star ratings, or customer counts."
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonationPanel, { compact: true }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto w-full max-w-6xl px-5 py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl text-ink",
					children: "Contact"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-ink-soft",
					children: site.copy.contactNote
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "font-semibold text-teal-deep underline underline-offset-4",
						href: `tel:${site.phoneTel}`,
						children: site.phoneDisplay
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/contact",
					className: "mt-4 inline-flex min-h-11 items-center font-semibold text-ink underline underline-offset-4",
					children: "Contact page"
				})
			]
		})
	] });
}
function SearchStrip() {
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-8 flex max-w-xl flex-col gap-2 sm:flex-row",
		role: "search",
		onSubmit: (event) => {
			event.preventDefault();
			navigate({
				to: "/services",
				search: {
					category: "all",
					q,
					group: "all"
				}
			});
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "sr-only",
				htmlFor: "home-search",
				children: "Search services"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "home-search",
				value: q,
				onChange: (event) => setQ(event.target.value),
				placeholder: "Search phone help, logos, websites",
				className: "min-h-11 flex-1 border border-line bg-paper px-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "inline-flex min-h-11 items-center justify-center border border-ink px-4 font-semibold",
				children: "Search"
			})
		]
	});
}
//#endregion
export { Home as component };
