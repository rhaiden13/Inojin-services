import { i as __toESM } from "../_runtime.mjs";
import { n as site } from "./site-DBkIVCbS.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as object, n as boolean, o as string, t as _enum } from "../_libs/zod.mjs";
import { _ as copyText, c as categories, d as findService, g as servicesIn, l as categoryById } from "./router-BIUHyiyQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inquiry-form-DqdBmDsp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var contactMethods = [
	{
		id: "phone",
		label: "Phone call or text"
	},
	{
		id: "facebook",
		label: "Facebook"
	},
	{
		id: "instagram",
		label: "Instagram"
	},
	{
		id: "email",
		label: "Email"
	}
];
var meetingOptions = [
	{
		id: "remote",
		label: "Remote"
	},
	{
		id: "in-person",
		label: "In person"
	},
	{
		id: "either",
		label: "Either is fine"
	},
	{
		id: "not-applicable",
		label: "Not applicable"
	}
];
var budgetOptions = [
	"Prefer not to say",
	"I will decide after the quotation",
	"Student or modest budget",
	"A standard one-time project",
	"A larger or ongoing project"
];
var secretPattern = /\b(passwords?|passcodes?|otp|one[-\s]?time|mpin|pin\s*code|recovery\s*codes?|cvv|seed\s*phrase)\b/i;
var inquirySchema = object({
	fullName: string().trim().min(2, "Enter your name.").max(80, "Use a shorter name."),
	contactMethod: _enum([
		"phone",
		"facebook",
		"instagram",
		"email"
	]),
	contactDetails: string().trim().min(5, "Enter a way for us to reply.").max(120),
	category: string().min(1, "Choose a category."),
	serviceId: string().min(1, "Choose a service."),
	projectType: string().trim().min(2, "Name the device or the project.").max(140),
	description: string().trim().min(20, "Describe the request in at least a sentence.").max(2e3, "Shorten the description to 2000 characters."),
	budget: string().max(80).optional(),
	schedule: string().trim().min(2, "Share a preferred schedule.").max(140),
	meeting: _enum([
		"remote",
		"in-person",
		"either",
		"not-applicable"
	]),
	instructions: string().max(1e3, "Shorten the extra notes.").optional(),
	consent: boolean(),
	website: string()
}).superRefine((value, ctx) => {
	if (value.website.trim() !== "") ctx.addIssue({
		code: "custom",
		message: "The form could not be prepared.",
		path: ["website"]
	});
	if (!value.consent) ctx.addIssue({
		code: "custom",
		message: "Consent is required before the message is prepared.",
		path: ["consent"]
	});
	if (!categoryById(value.category)) ctx.addIssue({
		code: "custom",
		message: "Choose a category from the list.",
		path: ["category"]
	});
	const service = findService(value.serviceId);
	if (!service || service.category !== value.category) ctx.addIssue({
		code: "custom",
		message: "Choose a service in that category.",
		path: ["serviceId"]
	});
	const blob = `${value.description}\n${value.instructions ?? ""}\n${value.contactDetails}`;
	if (secretPattern.test(blob)) ctx.addIssue({
		code: "custom",
		message: "Remove passwords, OTPs, MPINs, and recovery codes. We will never ask for them.",
		path: ["description"]
	});
	if (value.contactMethod === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.contactDetails)) ctx.addIssue({
		code: "custom",
		message: "Enter a valid email address.",
		path: ["contactDetails"]
	});
	if (value.contactMethod === "phone" && value.contactDetails.replace(/\D/g, "").length < 10) ctx.addIssue({
		code: "custom",
		message: "Enter a phone number with at least 10 digits.",
		path: ["contactDetails"]
	});
});
function formatInquiry(input, fileNames) {
	const service = findService(input.serviceId);
	const category = categoryById(input.category);
	const method = contactMethods.find((item) => item.id === input.contactMethod)?.label ?? input.contactMethod;
	const meeting = meetingOptions.find((item) => item.id === input.meeting)?.label ?? input.meeting;
	return [
		"Inojin Services — service inquiry",
		"",
		`Name: ${input.fullName}`,
		`Preferred contact: ${method}`,
		`Contact details: ${input.contactDetails}`,
		`Category: ${category?.name ?? input.category}`,
		`Service: ${service?.name ?? input.serviceId}`,
		`Device or project: ${input.projectType}`,
		`Preferred schedule: ${input.schedule}`,
		`Remote or in person: ${meeting}`,
		`Budget note: ${input.budget?.trim() || "Not specified"}`,
		"",
		"Description:",
		input.description.trim(),
		"",
		"Additional instructions:",
		input.instructions?.trim() || "None",
		"",
		"Reference files to send separately:",
		fileNames.length ? fileNames.join(", ") : "None named",
		"",
		"I agree that these details may be used only to reply about this inquiry.",
		"This message was prepared on the Inojin Services website. The site does not store it."
	].join("\n");
}
function smsHref(body) {
	const limit = 700;
	const text = body.length > limit ? `${body.slice(0, limit)}\n\n(Message shortened. Paste the full copied inquiry.)` : body;
	return `sms:${site.phoneTel}?body=${encodeURIComponent(text)}`;
}
function mailtoHref(body, subject) {
	return `mailto:${site.inquiryEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
var empty = {
	fullName: "",
	contactMethod: "phone",
	contactDetails: "",
	category: "",
	serviceId: "",
	projectType: "",
	description: "",
	budget: "",
	schedule: "",
	meeting: "remote",
	instructions: "",
	consent: false,
	website: ""
};
function InquiryForm({ initialService = "" }) {
	const preset = findService(initialService);
	const [values, setValues] = (0, import_react.useState)({
		...empty,
		category: preset?.category ?? "",
		serviceId: preset?.id ?? ""
	});
	const [fileNames, setFileNames] = (0, import_react.useState)([]);
	const [fileNote, setFileNote] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [phase, setPhase] = (0, import_react.useState)("edit");
	const [message, setMessage] = (0, import_react.useState)("");
	const [copyState, setCopyState] = (0, import_react.useState)("idle");
	(0, import_react.useEffect)(() => {
		if (!preset) return;
		setValues((current) => ({
			...current,
			category: preset.category,
			serviceId: preset.id
		}));
	}, [preset]);
	const choices = (0, import_react.useMemo)(() => servicesIn(values.category || "none"), [values.category]);
	const designHint = values.category === "design" || values.category === "business";
	function update(key, value) {
		setValues((current) => {
			const next = {
				...current,
				[key]: value
			};
			if (key === "category") next.serviceId = "";
			return next;
		});
	}
	function validate(target) {
		const parsed = inquirySchema.safeParse(target);
		if (parsed.success) {
			setErrors({});
			return parsed.data;
		}
		const next = {};
		for (const issue of parsed.error.issues) {
			const key = String(issue.path[0] ?? "form");
			if (!next[key]) next[key] = issue.message;
		}
		setErrors(next);
		return null;
	}
	function review(event) {
		event.preventDefault();
		const parsed = validate(values);
		if (!parsed) {
			setPhase("edit");
			return;
		}
		setValues(parsed);
		setMessage(formatInquiry(parsed, fileNames));
		setPhase("review");
		setCopyState("idle");
	}
	async function handoff() {
		const ok = await copyText(message);
		setCopyState(ok ? "copied" : "failed");
		if (ok) setPhase("ready");
	}
	const destination = site.inquiryEmail ? mailtoHref(message, `Inquiry from ${values.fullName || "a visitor"}`) : smsHref(message);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-line bg-paper px-4 py-6 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink-soft",
				children: site.inquiryEmail ? `Submitting opens your email app to ${site.inquiryEmail} after the message is copied. This website does not store the request.` : `There is no server inbox yet. Submitting copies your inquiry and opens Messages to ${site.phoneDisplay}. We see it only after you press send.`
			}),
			phase === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 grid gap-5",
				onSubmit: review,
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Honeypot, {
						value: values.website,
						onChange: (value) => update("website", value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Full name",
						error: errors.fullName,
						htmlFor: "full-name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "full-name",
							className: inputClass,
							value: values.fullName,
							onChange: (event) => update("fullName", event.target.value),
							autoComplete: "name",
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Preferred contact method",
						error: errors.contactMethod,
						htmlFor: "contact-method",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "contact-method",
							className: inputClass,
							value: values.contactMethod,
							onChange: (event) => update("contactMethod", event.target.value),
							children: contactMethods.map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: method.id,
								children: method.label
							}, method.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Contact details",
						error: errors.contactDetails,
						htmlFor: "contact-details",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "contact-details",
							className: inputClass,
							value: values.contactDetails,
							onChange: (event) => update("contactDetails", event.target.value),
							autoComplete: values.contactMethod === "email" ? "email" : "tel",
							placeholder: values.contactMethod === "email" ? "you@email.com" : "Your number or profile name",
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Service category",
						error: errors.category,
						htmlFor: "category",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "category",
							className: inputClass,
							value: values.category,
							onChange: (event) => update("category", event.target.value),
							required: true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Choose a category"
							}), categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: category.id,
								children: category.name
							}, category.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Specific service",
						error: errors.serviceId,
						htmlFor: "service",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "service",
							className: inputClass,
							value: values.serviceId,
							onChange: (event) => update("serviceId", event.target.value),
							required: true,
							disabled: !values.category,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: values.category ? "Choose a service" : "Choose a category first"
							}), choices.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: service.id,
								children: service.name
							}, service.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Device or project type",
						error: errors.projectType,
						htmlFor: "project-type",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "project-type",
							className: inputClass,
							value: values.projectType,
							onChange: (event) => update("projectType", event.target.value),
							placeholder: "Android phone, class deck, small shop site",
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: "Description",
						error: errors.description,
						htmlFor: "description",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "description",
							className: `${inputClass} min-h-36`,
							value: values.description,
							onChange: (event) => update("description", event.target.value),
							required: true
						}), designHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-ink-soft",
							children: "For design work, include dimensions, colors, audience, platform, deadline, and the deliverables you want."
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Budget range, optional",
						error: errors.budget,
						htmlFor: "budget",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "budget",
							className: inputClass,
							value: values.budget ?? "",
							onChange: (event) => update("budget", event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "No budget note"
							}), budgetOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: option,
								children: option
							}, option))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Preferred schedule",
						error: errors.schedule,
						htmlFor: "schedule",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "schedule",
							className: inputClass,
							value: values.schedule,
							onChange: (event) => update("schedule", event.target.value),
							placeholder: "This week, or a date you have in mind",
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Remote or in person",
						error: errors.meeting,
						htmlFor: "meeting",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "meeting",
							className: inputClass,
							value: values.meeting,
							onChange: (event) => update("meeting", event.target.value),
							children: meetingOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: option.id,
								children: option.label
							}, option.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: "Reference files, optional",
						error: "",
						htmlFor: "files",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "files",
								type: "file",
								multiple: true,
								className: "block w-full text-sm",
								onChange: (event) => {
									const files = [...event.target.files ?? []];
									const large = files.filter((file) => file.size > 15728640);
									setFileNames(files.map((file) => file.name));
									setFileNote(large.length ? "A selected file is over 15 MB. Nothing is uploaded. Only the file name is added to the message so you can send it later." : "Files stay on your device. This site cannot store uploads yet. The names are added to the message.");
								}
							}),
							fileNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-ink-soft",
								children: fileNote
							}) : null,
							fileNames.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-ink",
								children: ["Named: ", fileNames.join(", ")]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Additional instructions",
						error: errors.instructions,
						htmlFor: "instructions",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "instructions",
							className: `${inputClass} min-h-24`,
							value: values.instructions ?? "",
							onChange: (event) => update("instructions", event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-start gap-3 text-sm text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "mt-1 size-5",
							checked: values.consent,
							onChange: (event) => update("consent", event.target.checked)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I agree that Inojin Services may use this information only to reply about the inquiry. I will not include passwords, OTPs, or payment PINs." })]
					}),
					errors.consent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						role: "alert",
						children: errors.consent
					}) : null,
					errors.website ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						role: "alert",
						children: errors.website
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "inline-flex min-h-11 items-center justify-center bg-teal-deep px-5 font-semibold text-paper hover:bg-navy",
						children: "Review inquiry"
					})
				]
			}) : null,
			phase === "review" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl text-ink",
						children: "Review before sending"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-4 overflow-x-auto whitespace-pre-wrap border border-line bg-paper-2 p-4 text-sm text-ink",
						children: message
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex min-h-11 items-center border border-ink px-4 font-semibold",
							onClick: () => setPhase("edit"),
							children: "Edit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex min-h-11 items-center bg-teal-deep px-4 font-semibold text-paper",
							onClick: () => void handoff(),
							children: site.inquiryEmail ? "Copy inquiry and open email" : "Copy inquiry and open Messages"
						})]
					}),
					copyState === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-danger",
						role: "alert",
						children: [
							"The message was not copied, so it was not handed to your phone or email app. Select the text above and copy it, then contact ",
							site.phoneDisplay,
							"."
						]
					}) : null
				]
			}) : null,
			phase === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 border border-teal bg-foam px-4 py-5",
				role: "status",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl text-ink",
						children: "Ready to send — not received yet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-ink",
						children: site.copy.inquiryWarmth
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-ink",
						children: [
							"The full inquiry is on your clipboard.",
							site.inquiryEmail ? ` Open your email app to send it to ${site.inquiryEmail}.` : ` Open Messages to send it to ${site.phoneDisplay}.`,
							" ",
							"This website cannot confirm delivery, and it does not keep a copy."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: destination,
								className: "inline-flex min-h-11 items-center bg-teal-deep px-4 font-semibold text-paper",
								children: site.inquiryEmail ? "Open email" : "Open Messages"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `tel:${site.phoneTel}`,
								className: "inline-flex min-h-11 items-center border border-ink px-4 font-semibold",
								children: ["Call ", site.phoneDisplay]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex min-h-11 items-center px-2 font-semibold text-teal-deep underline",
								onClick: () => setPhase("edit"),
								children: "Start another inquiry"
							})
						]
					})
				]
			}) : null
		]
	});
}
var inputClass = "mt-2 w-full border border-line bg-paper px-3 py-3 text-ink";
function Field({ label, htmlFor, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor,
			className: "text-sm font-semibold text-ink",
			children: label
		}),
		children,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-danger",
			role: "alert",
			children: error
		}) : null
	] });
}
function Honeypot({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sr-only",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Company website", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			tabIndex: -1,
			autoComplete: "off",
			value,
			onChange: (event) => onChange(event.target.value)
		})] })
	});
}
//#endregion
export { InquiryForm as t };
