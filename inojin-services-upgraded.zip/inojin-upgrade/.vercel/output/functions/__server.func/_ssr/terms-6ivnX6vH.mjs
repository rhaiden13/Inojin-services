import { n as site } from "./site-DBkIVCbS.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-6ivnX6vH.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto w-full max-w-3xl space-y-4 px-5 py-12 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl sm:text-5xl",
				children: "Terms"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Browsing this site is free. A service starts only after you and Inojin Services agree on the scope, the price, and the schedule. A quotation is not a guarantee that every device can be fixed or that every file can be recovered." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Recovery, password, and network help uses official methods and requires ownership or permission. Unauthorized access is not offered. Hardware repair may be referred elsewhere. Software help is not the same as opening a machine." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: site.copy.priceDepends }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Design and website work uses materials you have the right to share. We do not claim a front-end page is a complete system with accounts, storage, or payments unless that is written into the scope. Domain, hosting, printing, music licenses, and app-store fees are third-party costs you pay to those providers." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "School help explains the work. It is not an offer to sit an exam or submit a graded assignment as if it were yours alone." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Voluntary GCash support is a gift, not a service payment and not a purchase. Send it only after you check the name ",
				site.gcash.accountName,
				" and the number ",
				site.gcash.number,
				". This website cannot confirm, receipt, or automatically refund a transfer, because the transfer happens in GCash, not here. If a gift was a mistake, contact ",
				site.phoneDisplay,
				" and we will try to help, within what GCash allows."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The portfolio is demonstration material unless a piece is clearly marked as permitted client work. Nothing on the site is a promise of an award, a ranking, or a business result." })
		]
	});
}
//#endregion
export { TermsPage as component };
