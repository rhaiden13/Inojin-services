import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as DonationPanel } from "./router-BIUHyiyQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/support-DltYnRB2.js
var import_jsx_runtime = require_jsx_runtime();
function SupportPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-6xl px-5 py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
					children: "Support"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-3xl font-display text-4xl text-ink sm:text-5xl",
					children: "Support Inojin Services"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-lg text-ink-soft",
					children: "This page is only for voluntary gifts. It is not a checkout, and it is not how you pay for a design or a repair."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonationPanel, {})] });
}
//#endregion
export { SupportPage as component };
