import { n as site } from "./site-DBkIVCbS.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-d6q6F0Qq.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto w-full max-w-3xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
				children: "About"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl text-ink sm:text-5xl",
				children: "A small studio for practical digital work"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-lg text-ink-soft",
				children: site.tagline
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-4 text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Inojin Services helps students, individuals, creators, and small businesses with phone and computer trouble, home networks, graphic design, and websites. The work is scoped in writing, then quoted, then done." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This page does not list awards, years in business, or customer totals. Those claims are omitted until there is something real to say." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: site.availability })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-12 font-display text-3xl text-ink",
				children: "What is working today"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 list-disc space-y-2 pl-5 text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The service catalog, filters, and search." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A portfolio of labeled demonstrations." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"An inquiry form that copies a message and opens your phone’s Messages app to ",
						site.phoneDisplay,
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Click-to-call, and copy buttons for the phone and GCash numbers." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"A voluntary GCash note for ",
						site.gcash.accountName,
						", number ",
						site.gcash.number,
						"."
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-12 font-display text-3xl text-ink",
				children: "What still needs a real account or file"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 list-disc space-y-2 pl-5 text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Facebook and Instagram buttons, until those profile URLs are pasted into the site settings." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Official prices. Every service is labeled, but amounts are blank on purpose." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "An email inbox, if you want inquiries to open mail instead of SMS." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stored inquiries, file uploads, and an admin screen. Those need a database and sign-in. They are not pretended here." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A GCash QR or payment link, only after you supply the real image or URL." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Client projects and permitted testimonials." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Service payments. Donations and invoices stay separate, and this site does not take card payments." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-ink-soft",
				children: "Edit names, numbers, URLs, and the public sentences in the site configuration. Service names and summaries live beside the catalog."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/contact",
				className: "mt-8 inline-flex min-h-11 items-center font-semibold text-teal-deep underline underline-offset-4",
				children: "Contact Inojin Services"
			})
		]
	});
}
//#endregion
export { AboutPage as component };
