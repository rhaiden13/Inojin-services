import { n as site } from "./site-DBkIVCbS.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as CopyButton, s as ProfileLink } from "./router-BIUHyiyQ.mjs";
import { t as InquiryForm } from "./inquiry-form-DqdBmDsp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CaTMux62.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid w-full max-w-6xl gap-12 px-5 py-12 lg:grid-cols-[1fr_1.2fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
				children: "Contact"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl text-ink sm:text-5xl",
				children: "Let’s work on your next idea together."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-lg text-ink-soft",
				children: site.copy.contactNote
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-8 space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs font-semibold uppercase tracking-widest text-ink-soft",
						children: "Phone"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "font-display text-3xl text-ink underline decoration-teal underline-offset-4",
							href: `tel:${site.phoneTel}`,
							children: site.phoneDisplay
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								value: site.phoneDisplay,
								label: "Copy phone number"
							})
						})]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs font-semibold uppercase tracking-widest text-ink-soft",
						children: "Social"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-3 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileLink, {
								href: site.facebookUrl,
								network: "Facebook",
								name: site.facebookName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileLink, {
								href: site.instagramUrl,
								network: "Instagram",
								name: site.instagramName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-ink-soft",
								children: site.copy.socialNote
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs font-semibold uppercase tracking-widest text-ink-soft",
						children: "Donations through GCash"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 text-ink",
						children: [
							site.gcash.accountName,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: site.gcash.number
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs font-semibold uppercase tracking-widest text-ink-soft",
						children: "Availability"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-ink",
						children: site.availability
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-sm text-ink-soft",
				children: "Privacy, in short: the form prepares a message on your device. It is not saved on this website. Do not send passwords, OTPs, or GCash MPINs. Read the privacy note for the rest."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InquiryForm, {})]
	});
}
//#endregion
export { ContactPage as component };
