import { n as site } from "./site-DBkIVCbS.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-BLYQLxUk.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto w-full max-w-3xl space-y-4 px-5 py-12 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl sm:text-5xl",
				children: "Privacy"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Inojin Services uses this website to explain services and to help you prepare a message. The inquiry form runs in your browser. It does not save your name, number, or project notes on a server." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"When you choose to send, the message goes through your own SMS or email app to ",
				site.phoneDisplay,
				site.inquiryEmail ? ` or ${site.inquiryEmail}` : "",
				". What happens after that is a normal message between you and the business."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Do not put passwords, one-time codes, GCash MPINs, recovery codes, or card numbers in the form. The form blocks some of those words. It is not a place to hand over account access." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Reference files you pick are not uploaded. Only the file names you select can be written into the message, and only on your device." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Phone and GCash numbers on the page are business contact details, not a request for your private credentials. Donations are sent inside GCash by you. This site does not see them." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The typefaces load from Google Fonts. That is a third-party request your browser makes when the page opens. Hosting and domain fees, if you later buy them for your own project, are charged by those companies, not hidden inside this page." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Device and network help is only for equipment and networks you own or are allowed to administer. We do not want locks, passwords, or router admin secrets sent through the form." })
		]
	});
}
//#endregion
export { PrivacyPage as component };
