import { i as __toESM } from "../_runtime.mjs";
import { n as site } from "./site-DBkIVCbS.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { n as portfolio, r as portfolioFilters, t as ConceptBoard } from "./concept-board-DcmtTyMO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portfolio-CF0g09GW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PortfolioGallery({ initial = "All" }) {
	const [filter, setFilter] = (0, import_react.useState)(initial);
	const [open, setOpen] = (0, import_react.useState)(null);
	const closeRef = (0, import_react.useRef)(null);
	const titleId = (0, import_react.useId)();
	const visible = portfolio.filter((item) => filter === "All" || item.category === filter);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(null);
		};
		window.addEventListener("keydown", onKey);
		closeRef.current?.focus();
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = previous;
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-6xl px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-2",
				role: "tablist",
				"aria-label": "Portfolio filters",
				children: portfolioFilters.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": filter === item,
					onClick: () => setFilter(item),
					className: "inline-flex min-h-11 shrink-0 items-center px-3 text-sm font-semibold " + (filter === item ? "bg-navy text-paper" : "border border-line bg-paper text-ink"),
					children: item
				}, item))
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 border border-line px-4 py-6",
				role: "status",
				children: "Nothing in this filter yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 grid gap-8 sm:grid-cols-2",
				children: visible.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border border-line bg-paper",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "block w-full text-left",
						onClick: () => setOpen(item),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, { item }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block px-4 py-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
									children: item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block font-display text-2xl text-ink",
									children: item.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block text-sm text-ink-soft",
									children: item.category
								})
							]
						})]
					})
				}, item.id))
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-navy/70 sm:items-center",
				role: "presentation",
				onClick: () => setOpen(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": titleId,
					className: "max-h-[92vh] w-full max-w-3xl overflow-y-auto bg-paper p-4 sm:p-6",
					onClick: (event) => event.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
								children: open.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: titleId,
								className: "mt-1 font-display text-3xl text-ink",
								children: open.title
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								ref: closeRef,
								type: "button",
								className: "inline-flex size-11 items-center justify-center border border-line",
								onClick: () => setOpen(null),
								"aria-label": "Close preview",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
								item: open,
								large: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-ink-soft",
							children: open.summary
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid gap-3 text-sm sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "font-semibold",
									children: "Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: open.category })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "font-semibold",
									children: "Tools"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: open.tools })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "font-semibold",
									children: "Deliverables"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: open.deliverables })] })
							]
						})
					]
				})
			}) : null
		]
	});
}
function Preview({ item, large = false }) {
	if (item.kind === "photo" && item.image) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: item.image,
		alt: item.imageAlt ?? item.title,
		className: large ? "max-h-[60vh] w-full object-cover" : "aspect-[4/3] w-full object-cover"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConceptBoard, {
		kind: item.kind,
		title: item.title
	});
}
function PortfolioPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-6xl px-5 py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
					children: "Gallery"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-4xl text-ink sm:text-5xl",
					children: "Portfolio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-lg text-ink-soft",
					children: site.copy.portfolioNote
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-ink",
					children: "These are demonstration concepts and studio photographs. They are not client projects, and they are not testimonials. Real jobs will be added only with permission."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortfolioGallery, {})] });
}
//#endregion
export { PortfolioPage as component };
