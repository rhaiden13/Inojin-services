import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Route$5 } from "./router-BIUHyiyQ.mjs";
import { t as InquiryForm } from "./inquiry-form-DqdBmDsp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/request-BUXpHbTa.js
var import_jsx_runtime = require_jsx_runtime();
function RequestPage() {
	const { service } = Route$5.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-3xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
				children: "Inquiry"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl text-ink sm:text-5xl",
				children: "Request a service"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-ink-soft",
				children: "Describe the job. You will review it before anything is copied. Service payments, if you later agree to them, are separate from donations."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InquiryForm, { initialService: service })
			})
		]
	});
}
//#endregion
export { RequestPage as component };
