import { n as site } from "./site-DBkIVCbS.mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as categories, f as groupsFor, p as priceKindLabel, r as Route$1, u as filterServices } from "./router-BIUHyiyQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.index-7rVPPggu.js
var import_jsx_runtime = require_jsx_runtime();
function ServiceBrowser({ search, onSearch }) {
	const groups = search.category === "all" ? [] : groupsFor(search.category);
	const list = filterServices(search.category, search.q, search.group);
	const active = categories.find((item) => item.id === search.category);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-6xl px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3 sm:grid-cols-[1fr_auto]",
				onSubmit: (event) => event.preventDefault(),
				role: "search",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "service-search",
					className: "text-sm font-semibold text-ink",
					children: "Search services"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "service-search",
					value: search.q,
					onChange: (event) => onSearch({
						...search,
						q: event.target.value
					}),
					placeholder: "Try backup, logo, Wi-Fi, resume",
					className: "mt-2 w-full border border-line bg-paper px-3 py-3 text-ink"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-auto inline-flex min-h-11 items-center justify-center border border-ink px-4 text-sm font-semibold",
					onClick: () => onSearch({
						category: "all",
						q: "",
						group: "all"
					}),
					children: "Clear"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex gap-2 overflow-x-auto pb-2",
				role: "tablist",
				"aria-label": "Service categories",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: search.category === "all",
					onClick: () => onSearch({
						...search,
						category: "all",
						group: "all"
					}),
					label: `All (${filterServices("all", "", "all").length})`
				}), categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: search.category === category.id,
					onClick: () => onSearch({
						...search,
						category: category.id,
						group: "all"
					}),
					label: category.name
				}, category.id))]
			}),
			groups.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: search.group === "all",
					onClick: () => onSearch({
						...search,
						group: "all"
					}),
					label: "Every group"
				}), groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: search.group === group,
					onClick: () => onSearch({
						...search,
						group
					}),
					label: group
				}, group))]
			}) : null,
			active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 border-l-2 border-teal pl-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl text-ink",
						children: active.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-3xl text-ink-soft",
						children: active.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-3xl text-sm text-ink",
						children: active.disclaimer
					})
				]
			}) : null,
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 border border-line bg-paper-2 px-4 py-6 text-ink",
				role: "status",
				children: "No services match that search. Try a shorter word, or choose another category."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 divide-y divide-line border-y border-line",
				children: list.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-3 py-5 md:grid-cols-[1fr_auto] md:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
							children: [categories.find((item) => item.id === service.category)?.name, service.group ? ` · ${service.group}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-2xl text-ink",
							children: service.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-2xl text-ink-soft",
							children: service.summary
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-semibold text-ink",
							children: priceKindLabel(service.priceKind)
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/services/$serviceId",
							params: { serviceId: service.id },
							className: "inline-flex min-h-11 items-center border border-ink px-4 text-sm font-semibold hover:bg-ink hover:text-paper",
							children: "Details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/request",
							search: { service: service.id },
							className: "inline-flex min-h-11 items-center bg-teal-deep px-4 text-sm font-semibold text-paper hover:bg-navy",
							children: "Inquire"
						})]
					})]
				}, service.id))
			})
		]
	});
}
function FilterChip({ active, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: "inline-flex min-h-11 shrink-0 items-center px-3 text-sm font-semibold " + (active ? "bg-navy text-paper" : "border border-line bg-paper text-ink hover:border-ink"),
		children: label
	});
}
function ServicesPage() {
	const search = Route$1.useSearch();
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-6xl px-5 py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
					children: "Catalog"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-4xl text-ink sm:text-5xl",
					children: "Services"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 max-w-2xl text-lg text-ink-soft",
					children: ["Pick a category, search by name, and open a service before you request it. Prices stay unpublished until an official amount is set. ", site.copy.priceDepends]
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceBrowser, {
		search,
		onSearch: (next) => {
			navigate({
				to: "/services",
				search: next
			});
		}
	})] });
}
//#endregion
export { ServicesPage as component };
