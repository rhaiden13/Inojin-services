import { n as site } from "./site-DBkIVCbS.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as findService, h as services, l as categoryById, m as priceText, n as Route } from "./router-BIUHyiyQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services._serviceId-1OKLwHQf.js
var import_jsx_runtime = require_jsx_runtime();
function ServicePage() {
	const { serviceId } = Route.useParams();
	const service = findService(serviceId);
	if (!service) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-3xl px-5 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl text-ink",
				children: "That service is not listed"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-ink-soft",
				children: "The link may be old. The catalog is the current list."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/services",
				search: {
					category: "all",
					q: "",
					group: "all"
				},
				className: "mt-6 inline-flex min-h-11 items-center font-semibold text-teal-deep underline",
				children: "Back to services"
			})
		]
	});
	const category = categoryById(service.category);
	const related = services.filter((item) => item.category === service.category && item.id !== service.id).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto w-full max-w-3xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/services",
					search: {
						category: service.category,
						q: "",
						group: "all"
					},
					className: "underline underline-offset-4",
					children: category?.name
				}), service.group ? ` · ${service.group}` : ""]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl text-ink sm:text-5xl",
				children: service.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-lg text-ink-soft",
				children: service.summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 border border-line bg-foam px-4 py-3 text-sm font-semibold text-ink",
				children: priceText(service)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-ink-soft",
				children: site.copy.priceDepends
			}),
			category ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-ink",
				children: category.disclaimer
			}) : null,
			service.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 border-l-2 border-brass pl-4 text-ink",
				children: service.notes
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/request",
					search: { service: service.id },
					className: "inline-flex min-h-11 items-center bg-teal-deep px-5 font-semibold text-paper",
					children: "Inquire about this"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/services",
					search: {
						category: service.category,
						q: "",
						group: service.group ?? "all"
					},
					className: "inline-flex min-h-11 items-center border border-ink px-5 font-semibold",
					children: "More in this category"
				})]
			}),
			related.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 border-t border-line pt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-ink",
					children: "Nearby services"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3",
					children: related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/services/$serviceId",
						params: { serviceId: item.id },
						className: "font-semibold text-teal-deep underline underline-offset-4",
						children: item.name
					}) }, item.id))
				})]
			}) : null
		]
	});
}
//#endregion
export { ServicePage as component };
