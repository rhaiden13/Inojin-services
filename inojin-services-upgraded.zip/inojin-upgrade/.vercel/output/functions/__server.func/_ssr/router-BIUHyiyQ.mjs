import { i as __toESM } from "../_runtime.mjs";
import { n as site } from "./site-DBkIVCbS.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useRouter, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Copy, i as Heart, n as TriangleAlert, o as Check, r as Menu, s as ArrowUp, t as X } from "../_libs/lucide-react.mjs";
import { a as object, i as number, o as string, r as literal, s as union } from "../_libs/zod.mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/copy-text-CsWEV5ZP.js
async function copyText(value) {
	try {
		if (navigator.clipboard?.writeText) {
			await navigator.clipboard.writeText(value);
			return true;
		}
	} catch {}
	try {
		const area = document.createElement("textarea");
		area.value = value;
		area.setAttribute("readonly", "true");
		area.style.position = "fixed";
		area.style.left = "-9999px";
		document.body.appendChild(area);
		area.select();
		const ok = document.execCommand("copy");
		area.remove();
		return ok;
	} catch {
		return false;
	}
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-BC9eAMVF.js
var KIND = {
	fixed: "Fixed Price",
	starting: "Starting At",
	quote: "Custom Quotation",
	assessment: "Assessment Required"
};
function priceKindLabel(kind) {
	return KIND[kind];
}
function priceText(service) {
	const kind = KIND[service.priceKind];
	if (service.priceAmount) return `${kind}: ${service.priceAmount}`;
	return `${kind}. Official price not published yet — request a quotation.`;
}
var categories = [
	{
		id: "phone",
		name: "Phone & Mobile",
		eyebrow: "Devices",
		blurb: "Diagnostics, setup, backups, and everyday phone problems. Recovery stays on official methods.",
		disclaimer: "Screen-lock and account recovery use the manufacturer or provider’s own steps, and only with proof that you own the device or have permission. We do not bypass locks and we do not guarantee access."
	},
	{
		id: "computer",
		name: "Computers & Laptops",
		eyebrow: "Desk",
		blurb: "Windows help, setup, slow machines, and software that will not start. Physical repair is a separate question.",
		disclaimer: "This is software troubleshooting and setup, not a promise of physical repair. Reformatting and system installs can erase files, so we back up first when the disk still allows it. Data recovery and hardware faults are assessments only — not every file or part can be saved or fixed. Some jobs need the computer in front of us, or an authorized technician."
	},
	{
		id: "network",
		name: "Wi-Fi & Networks",
		eyebrow: "Connection",
		blurb: "Home and small-shop networks you own or are allowed to administer.",
		disclaimer: "Password recovery and router changes are only for networks the client owns or is authorized to administer. We do not try to enter someone else’s network."
	},
	{
		id: "design",
		name: "Graphic Design",
		eyebrow: "Studio",
		blurb: "Presentations, print, social posts, brand boards, and documents. Tell us the size, colors, audience, and deadline.",
		disclaimer: "Demonstration concepts in the gallery are not client work. A design job can include dimensions, colors, audience, platform, deadline, reference images you have rights to, and the deliverables you need. Revisions are agreed in the quotation."
	},
	{
		id: "web",
		name: "Websites",
		eyebrow: "Web",
		blurb: "Portfolios, small business sites, landing pages, and focused web projects for students, creators, and shops.",
		disclaimer: "A page you can open in a browser is not the same as a hosted app with accounts, a database, or card payments. If a request needs those, the quotation says so. Domain, hosting, and third-party fees are paid by you to those providers."
	},
	{
		id: "business",
		name: "Business Solutions",
		eyebrow: "Shops",
		blurb: "A practical digital presence: profile, menu, deck, catalog, and a site that can take inquiries.",
		disclaimer: "Packages can combine design and a website in one quotation. We do not invent sales results or claim a package will guarantee customers."
	},
	{
		id: "video",
		name: "Video & Multimedia",
		eyebrow: "Motion",
		blurb: "Short edits, captions, thumbnails, and simple motion. Longer films are quoted after we see the footage.",
		disclaimer: "We can edit material you own or have permission to use. Advanced motion, licensed music, and long-form films are marked for assessment when the scope is not clear yet."
	},
	{
		id: "products",
		name: "Digital Products",
		eyebrow: "Files",
		blurb: "Templates and starter files you can reuse: decks, planners, resumes, and simple HTML starts.",
		disclaimer: "Template packs are starting-price items once an official amount is published. A custom version is quoted separately. Files are delivered after the scope is approved."
	},
	{
		id: "tools",
		name: "Productivity & Tools",
		eyebrow: "Systems",
		blurb: "Spreadsheets, checklists, simple calculators, and file organization for real daily use.",
		disclaimer: "Calculators and sheets are tools, not financial, legal, or medical advice. Automation that touches private accounts is assessed before any build."
	},
	{
		id: "learning",
		name: "Technical Learning",
		eyebrow: "Lessons",
		blurb: "Beginner help with HTML, CSS, JavaScript, software setup, and how a small website fits together.",
		disclaimer: "Sessions are tutoring and setup help, not a certified course and not a promise of a grade or a job."
	}
];
function slug(value) {
	return value.toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
function add(category, group, rows) {
	return rows.map(([name, summary, priceKind, notes]) => ({
		id: slug(`${category}-${name}`),
		category,
		group,
		name,
		summary,
		priceKind,
		priceAmount: null,
		notes
	}));
}
var ownDevice = "Official recovery only, with proof of ownership or permission. No lock bypass, and no promise that access will be restored.";
var hardware = "This can turn out to be a physical fault. We will say if an in-person inspection or another technician is the honest next step.";
var noGuarantee = "Assessment only. We cannot promise the files or the repair.";
var services = [
	...add("phone", "Support", [
		[
			"Phone Diagnostics and Troubleshooting",
			"We reproduce the problem where we can, then suggest the next practical step before anything is erased.",
			"assessment"
		],
		[
			"Forgotten Screen Lock Recovery Guidance",
			"A walkthrough of the official lock recovery for a phone you own.",
			"assessment",
			ownDevice
		],
		[
			"Official Phone Account Recovery Assistance",
			"Help using the account provider’s own recovery, not a shortcut around it.",
			"assessment",
			ownDevice
		],
		[
			"Phone Security and Privacy Checkups",
			"A calm pass over lock screen, accounts, and privacy choices you decide to change.",
			"assessment"
		],
		[
			"Suspicious Application and Permission Reviews",
			"We look at installed apps and permissions and explain which ones deserve a closer look.",
			"assessment"
		],
		[
			"App Installation and Configuration",
			"Install an app you are allowed to use and check that it opens and signs in with you present.",
			"quote"
		],
		[
			"Phone Setup and Personalization",
			"A new or freshly reset phone, arranged around how you actually use it.",
			"quote"
		],
		[
			"Storage Management and Performance Optimization",
			"See what is using space and apply safe cleanups you approve.",
			"assessment"
		],
		[
			"Software and Operating System Updates",
			"Check for an official system or app update and install it when the phone and connection allow.",
			"assessment"
		],
		[
			"Application Errors and Crash Troubleshooting",
			"Catch the crash, try the usual fixes, and stop before a reset if the data matters.",
			"assessment"
		],
		[
			"Contact and File Backup Assistance",
			"Copy contacts and files to a place you control and can open again.",
			"quote"
		],
		[
			"Photo and Video Backup Guidance",
			"Set up a backup you understand. Your gallery stays yours.",
			"quote"
		],
		[
			"Device-to-Device Data Transfer",
			"Move data between two devices when both are present and you unlock them.",
			"quote"
		],
		[
			"Wi-Fi and Mobile Data Troubleshooting",
			"Separate a phone setting from a router or SIM problem.",
			"assessment"
		],
		[
			"Notification and Permission Fixes",
			"Restore missing alerts or quiet the ones you do not want.",
			"assessment"
		],
		[
			"Battery Usage Assessment",
			"See which apps draw power. This is not a battery replacement.",
			"assessment",
			hardware
		],
		[
			"Factory Reset Guidance",
			"What a reset erases, and how to do it only after a backup you can verify.",
			"assessment"
		],
		[
			"Post-Reset Device Setup",
			"Accounts you can sign in to, essential apps, and the settings you still remember needing.",
			"quote"
		],
		[
			"Email Account Setup Assistance",
			"Add mail with the provider’s official settings.",
			"quote"
		],
		[
			"Bluetooth and Accessory Troubleshooting",
			"Pair headphones, watches, speakers, or other accessories you own.",
			"assessment",
			hardware
		],
		[
			"Mobile Browser Troubleshooting",
			"Unstick a browser, a site, or a download without wiping the phone first.",
			"assessment"
		],
		[
			"Phone Privacy Settings Review",
			"Walk the privacy screens and explain what each choice actually does.",
			"assessment"
		],
		[
			"Device Compatibility Assessment",
			"Check whether an app, cable, accessory, or file type fits this phone.",
			"assessment"
		],
		[
			"App Configuration and Data Organization",
			"Arrange app settings and on-phone files so they are easier to find.",
			"quote"
		],
		[
			"General Mobile Technology Support",
			"A practical session for a phone question that does not fit a narrower service.",
			"assessment"
		]
	]),
	...add("computer", "Support", [
		[
			"Computer and Laptop Diagnostics",
			"Find whether the trouble is software, settings, or something that looks physical.",
			"assessment",
			hardware
		],
		[
			"Windows Troubleshooting",
			"Everyday Windows faults: updates stuck, settings wrong, features missing.",
			"assessment"
		],
		[
			"Forgotten Password Recovery Guidance",
			"Official ways to regain a Windows or account sign-in you own.",
			"assessment",
			ownDevice
		],
		[
			"Official Account Recovery Assistance",
			"Microsoft, Google, or similar recovery using that company’s own flow.",
			"assessment",
			ownDevice
		],
		[
			"Operating System Installation Assistance",
			"Install or reinstall an operating system you are licensed to use, after a backup plan.",
			"assessment",
			"Installation can erase the disk. We confirm that with you first."
		],
		[
			"Computer Reformatting and Reinstallation",
			"A clean start when you have decided the current setup should be replaced.",
			"assessment",
			"Reformatting removes programs and files. Back up anything you still need."
		],
		[
			"Software Installation and Configuration",
			"Install software you own or that is free to use, then set the options you need.",
			"quote"
		],
		[
			"Driver Installation and Troubleshooting",
			"Official drivers for a device the computer should already support.",
			"assessment",
			hardware
		],
		[
			"Software and System Updates",
			"Apply updates that are actually offered for this machine.",
			"assessment"
		],
		[
			"Startup and Boot Error Diagnosis",
			"Read the startup failure and separate a setting issue from a disk or hardware fault.",
			"assessment",
			hardware
		],
		[
			"Blue Screen and System Error Troubleshooting",
			"Collect the error and try the safe software fixes. Not every stop code is repairable in software.",
			"assessment",
			noGuarantee
		],
		[
			"Slow PC Performance Assessment",
			"See startup apps, disk space, and settings that make a computer feel tired.",
			"assessment"
		],
		[
			"Storage Cleanup and File Organization",
			"Clear space you approve and put folders where you can find them.",
			"quote"
		],
		[
			"Application Crash and Compatibility Fixes",
			"An app that closes or refuses to run on this version of the system.",
			"assessment"
		],
		[
			"Basic Malware and Suspicious Software Checks",
			"A first look for unwanted programs. This is not a certified incident response.",
			"assessment",
			"If the machine holds sensitive work or the infection looks serious, we will say so."
		],
		[
			"Computer Security and Privacy Reviews",
			"Accounts, updates, browser, and sharing settings, changed only with you.",
			"assessment"
		],
		[
			"Browser Errors and Configuration",
			"Homepage, extensions, downloads, and sites that misbehave.",
			"assessment"
		],
		[
			"Printer and Peripheral Setup",
			"Install a printer, scanner, or similar device you own, on a computer or a network you administer.",
			"assessment",
			hardware
		],
		[
			"Data Backup and Migration Assistance",
			"Copy files to a drive or computer you control, and check that a sample opens.",
			"quote"
		],
		[
			"Local File Recovery Assessment",
			"See whether deleted or missing files still have a reasonable chance of return.",
			"assessment",
			noGuarantee
		],
		[
			"PC Setup and Personalization",
			"A new or reset computer: accounts, browser, and the programs you use.",
			"quote"
		],
		[
			"Basic Hardware Issue Assessment",
			"Ports, power, display, heat, or noise — enough to tell software from hardware.",
			"assessment",
			hardware
		],
		[
			"Keyboard, Mouse, and Accessory Troubleshooting",
			"Input devices that skip, disconnect, or type the wrong thing.",
			"assessment",
			hardware
		],
		[
			"Coding Environment Setup",
			"Install a beginner-friendly editor, language, and the tools a school or project named.",
			"quote"
		],
		[
			"Developer Tool Installation",
			"Git, a browser, runtimes, and similar tools, pinned to versions your project needs.",
			"quote"
		],
		[
			"Software Configuration and Maintenance",
			"A return visit to fix settings that drifted or to install an update you want.",
			"quote"
		],
		[
			"Video Conferencing Setup",
			"Camera, microphone, and a Zoom, Meet, or Teams check before a class or meeting.",
			"quote"
		],
		[
			"Email Client Configuration",
			"Desktop or web mail with the correct official server settings.",
			"quote"
		],
		[
			"External Drive Setup",
			"Format or organize a drive you own, after we explain what formatting erases.",
			"assessment"
		],
		[
			"General Computer Technical Support",
			"A session for a computer question that does not match a single service above.",
			"assessment"
		]
	]),
	...add("network", "Networks", [
		[
			"Wi-Fi Connection Troubleshooting",
			"Why a device associates, drops, or never joins a network you administer.",
			"assessment"
		],
		[
			"Forgotten Wi-Fi Password Recovery Guidance",
			"Official ways to view or replace a password for a network you own.",
			"assessment",
			"Only for a network you own or are authorized to administer."
		],
		[
			"Router Setup and Configuration",
			"First setup of a router you own: name, password, and a connection that actually passes traffic.",
			"quote"
		],
		[
			"Router Password Change Assistance",
			"Change the Wi-Fi or admin password and write down where you stored it. We never keep it.",
			"quote"
		],
		[
			"Slow Internet Troubleshooting",
			"Separate a busy Wi-Fi, a weak spot, and a line that is slow before it reaches the router.",
			"assessment"
		],
		[
			"Internet Connectivity Diagnosis",
			"No connection at all: modem, router, cables, and the device in your hand.",
			"assessment"
		],
		[
			"Wi-Fi Signal and Coverage Assessment",
			"Where the signal falls off in a home or a small shop, and simple placement changes.",
			"assessment"
		],
		[
			"Device Connection Troubleshooting",
			"One phone, laptop, or TV that will not stay on a network the others can use.",
			"assessment"
		],
		[
			"DNS and Basic Network Configuration",
			"Straightforward DNS or adapter settings when a site fails and the rest of the network is fine.",
			"assessment"
		],
		[
			"Router Firmware Update Guidance",
			"Install an official firmware update from the router maker, when one is offered.",
			"assessment"
		],
		[
			"Home Network Security Checkups",
			"Admin password, Wi-Fi password, encryption, and remote-admin settings left open by mistake.",
			"assessment"
		],
		[
			"Connected Device Reviews",
			"A list of what is on the network, so you can remove what you do not recognize.",
			"assessment"
		],
		[
			"Guest Network Setup Guidance",
			"A separate guest name for visitors, if the router supports it.",
			"quote"
		],
		[
			"Home Wi-Fi Optimization",
			"Channel, band, and placement changes that are realistic for the router you already have.",
			"assessment"
		],
		[
			"Basic LAN Configuration",
			"A small wired setup: router to switch to the computers that need a cable.",
			"assessment"
		],
		[
			"Network Setup for Small Businesses",
			"A simple shop network for till, printer, and staff phones. Larger builds are quoted after a look.",
			"quote"
		],
		[
			"Router Placement Recommendations",
			"Where to put the router you own, without selling you equipment you may not need.",
			"assessment"
		],
		[
			"Printer Network Troubleshooting",
			"A printer that used to be on the Wi-Fi and now is not.",
			"assessment",
			hardware
		],
		[
			"Internet Setup and Configuration",
			"New line or new modem: get the first devices online and the Wi-Fi named properly.",
			"quote"
		],
		[
			"Secure Wi-Fi Configuration Advice",
			"Encryption, a non-default password, and admin access that is not left on factory settings.",
			"assessment"
		],
		[
			"Basic Hotspot Configuration",
			"Phone hotspot or a small travel router, for a use you describe.",
			"assessment"
		],
		[
			"Network Device Compatibility Checks",
			"Whether a device can join the kind of Wi-Fi the router offers.",
			"assessment"
		],
		[
			"Connectivity Troubleshooting for Online Classes",
			"Camera, bandwidth, and a connection stable enough for a class period.",
			"assessment"
		],
		[
			"Remote Network Troubleshooting Guidance",
			"Help over chat or a call when we cannot stand next to the router. Some faults still need someone on site.",
			"assessment"
		]
	]),
	...add("design", "Presentations", [
		[
			"PowerPoint Design",
			"A deck with a clear order, readable type, and slides that match the talk you are actually giving.",
			"quote"
		],
		[
			"School Presentation Design",
			"Class reports and group slides, laid out so the teacher can follow the point.",
			"quote"
		],
		[
			"Research Presentation Layouts",
			"Findings, citations, and figures with room to breathe. We do not invent data.",
			"quote"
		],
		[
			"Business Presentation Decks",
			"A pitch or internal deck from notes you provide.",
			"quote"
		],
		[
			"Project Defense Presentation Layouts",
			"Defense or final-defense slides structured around the panel’s questions.",
			"quote"
		],
		[
			"Educational Infographics",
			"One topic, one page, explained in an order a student can scan.",
			"quote"
		],
		[
			"Learning Materials",
			"Handouts and visual explainers for a lesson you outline.",
			"quote"
		],
		[
			"Study Guides and Reviewer Layouts",
			"Reviewers that are easy to print or read on a phone.",
			"quote"
		],
		[
			"Lesson Presentation Templates",
			"A reusable school or training deck you can duplicate.",
			"starting"
		],
		[
			"Certificates and Recognition Designs",
			"Certificates with the names and wording you supply.",
			"quote"
		]
	]),
	...add("design", "Print", [
		[
			"Pubmat Design",
			"A publication material sized for the feed or the wall you name.",
			"quote"
		],
		[
			"Tarpaulin and Banner Design",
			"Large-format artwork with the printer’s size and bleed. Printing is a third-party cost.",
			"quote"
		],
		[
			"Advertisement Posters",
			"A poster with one offer, one date, and type that still reads across a room.",
			"quote"
		],
		[
			"Business Flyers",
			"A single sheet for a shop, event, or service.",
			"quote"
		],
		[
			"Brochures",
			"A folded piece with a front, an inside story, and a way to contact you.",
			"quote"
		],
		[
			"Event Posters",
			"Time, place, and what the event is, before decoration.",
			"quote"
		],
		[
			"Digital Invitations",
			"An invitation sized for chat or stories.",
			"quote"
		],
		[
			"Business Cards",
			"A card with the details you want public. We do not add private account numbers unless you ask.",
			"quote"
		],
		[
			"Product Price Lists",
			"A clean list from prices you provide. We do not invent discounts.",
			"quote"
		],
		[
			"Service Menus",
			"Services and how to inquire, without fake ‘limited time’ claims.",
			"quote"
		],
		[
			"Restaurant Menu Design",
			"A menu guests can read. Food photos only if you have rights to them.",
			"quote"
		],
		[
			"Product Catalogs",
			"A catalog or lookbook from your real products.",
			"quote"
		],
		[
			"Promotional Banners",
			"Web or print banners at the pixel or centimeter size you need.",
			"quote"
		],
		[
			"Event and Community Materials",
			"Programs, signage, and neighbor-scale announcements.",
			"quote"
		]
	]),
	...add("design", "Social", [
		[
			"Facebook Promotional Graphics",
			"Feed graphics sized for Facebook, with copy you approve.",
			"quote"
		],
		[
			"Instagram Posts and Stories",
			"Square posts and vertical stories for a campaign or a single announcement.",
			"quote"
		],
		[
			"Social Media Cover Photos",
			"Cover and channel art that still works when the screen crops it.",
			"quote"
		],
		[
			"Product Advertisement Pictures",
			"A product frame from photos you supply or from a simple studio setup we agree.",
			"quote"
		],
		[
			"Product Launch Graphics",
			"A small set for announcing something you are actually releasing.",
			"quote"
		],
		[
			"YouTube Thumbnails",
			"A thumbnail that stays readable at small size.",
			"quote"
		],
		[
			"Creator Branding Graphics",
			"A consistent frame for a creator who is not ready for a full identity system.",
			"quote"
		],
		[
			"Promotional Campaign Creatives",
			"A related set, not one isolated poster.",
			"quote"
		],
		[
			"Digital Marketing Materials",
			"Images for a specific offer, audience, and platform.",
			"quote"
		],
		[
			"Sale and Discount Posters",
			"Only for a discount you confirm. We do not draw fake countdown pressure.",
			"quote"
		],
		[
			"Content Calendar Templates",
			"A calendar you can fill. We do not pretend to schedule posts to your accounts.",
			"starting"
		],
		[
			"Profile and Channel Graphics",
			"Profile mark, banner, and a short visual note so the page looks settled.",
			"quote"
		]
	]),
	...add("design", "Brand", [
		[
			"Logo Concepts",
			"A small set of logo directions, delivered as files you can actually use. Not a trademark search.",
			"quote"
		],
		[
			"Color Palette and Typography Selection",
			"Colors and type chosen for print and screen, written down so the next piece matches.",
			"quote"
		],
		[
			"Brand Identity Boards",
			"A board that shows mark, color, and type together.",
			"quote"
		],
		[
			"Basic Brand Guidelines",
			"A short guide: clear space, misuse, and the files to hand a printer.",
			"quote"
		],
		[
			"Business Visual Identity",
			"The look of a small business across card, social, and a simple cover.",
			"quote"
		],
		[
			"Product Label Concepts",
			"A label sized for the package you describe. Printing is separate.",
			"quote"
		],
		[
			"Packaging Mockups",
			"A visual mockup. This is not manufacturing or a dieline unless we agree one.",
			"quote"
		],
		[
			"Brand Presentation Decks",
			"A deck that explains the identity to a partner or a printer.",
			"quote"
		],
		[
			"Personal Branding Materials",
			"A personal set for a student, freelancer, or creator.",
			"quote"
		]
	]),
	...add("design", "Documents", [
		[
			"Resume and CV Layouts",
			"A resume designed from your real history. We do not invent jobs or skills.",
			"quote"
		],
		[
			"Portfolio Layouts",
			"A PDF or slide portfolio of work you have the right to show.",
			"quote"
		],
		[
			"E-book Design",
			"Interior and cover for a manuscript you provide.",
			"quote"
		],
		[
			"PDF Formatting",
			"A long document made consistent: headings, margins, page numbers.",
			"quote"
		],
		[
			"Digital Workbooks",
			"Exercises and write-in space for a class or a workshop.",
			"quote"
		],
		[
			"Printable Planners",
			"Pages you can print at home: weeks, lists, or trackers you describe.",
			"starting"
		],
		[
			"Digital Catalogs",
			"A flip-friendly PDF catalog.",
			"quote"
		],
		[
			"Professional Reports",
			"A report layout. The findings stay yours — we do not write false results.",
			"quote"
		],
		[
			"Guides and Manuals",
			"Step-by-step guides with figures that match the real product.",
			"quote"
		],
		[
			"Document Cover Design",
			"A cover for a thesis, report, or booklet.",
			"quote"
		]
	]),
	...add("web", "Sites", [
		[
			"Personal Portfolio Websites",
			"A small site for your work, fast on a phone, with a way to contact you.",
			"quote"
		],
		[
			"Business Websites",
			"Pages for what you offer, where you are, and how to inquire. Not an online store unless scoped.",
			"quote"
		],
		[
			"Freelancer Websites",
			"Services, selected work, and a request form or contact path.",
			"quote"
		],
		[
			"Student Portfolio Websites",
			"School and personal work, labeled honestly, for applications or defense.",
			"quote"
		],
		[
			"School Project Websites",
			"A project site that matches the brief your class actually gave.",
			"quote"
		],
		[
			"Educational Websites",
			"Lessons or a school presence as pages. Student accounts are a larger build.",
			"quote",
			"A content site. Accounts, grades, and a full classroom need a separate scope."
		],
		[
			"Digital Services Websites",
			"A service list and inquiry path, similar in purpose to this one, built around your offers.",
			"quote"
		],
		[
			"Product Showcase Websites",
			"Products with photos and details. Checkout is not included unless a payment provider is scoped.",
			"quote",
			"Showcase only, unless payment integration is quoted separately."
		],
		[
			"Landing Pages",
			"One page, one action: call, message, or a request.",
			"quote"
		],
		[
			"Personal Profile Websites",
			"A simple personal page: who you are and how to reach you.",
			"quote"
		],
		[
			"Interactive Resume Websites",
			"A resume you can click through. Content comes from you.",
			"quote"
		],
		[
			"Online Event Invitation Websites",
			"Date, place, and a note. Not ticket sales unless scoped.",
			"quote"
		],
		[
			"Relationship Goals and Memory Websites",
			"A shared page for a story you want to tell.",
			"quote",
			"This is a page people can open. Private accounts are extra."
		],
		[
			"Family Memories Websites",
			"Photos and stories your family has rights to share.",
			"quote",
			"Private galleries need hosting and access rules, quoted separately."
		],
		[
			"Restaurant Menu Websites",
			"A menu that is easy to update in the files. Ordering and payments are extra.",
			"quote"
		],
		[
			"Product Catalog Websites",
			"A catalog to browse. Stock counts and checkout are a different project.",
			"quote"
		],
		[
			"Booking and Inquiry Websites",
			"A request a visitor can send. Live calendar booking and card payments are not assumed.",
			"quote",
			"Inquiry first. A connected booking system needs a provider and a backend."
		],
		[
			"Creator and Content Portfolio Websites",
			"A home for videos, posts, or writing, with links you control.",
			"quote"
		],
		[
			"Website Redesign",
			"A clearer structure and look for a site you already have.",
			"quote"
		],
		[
			"Mobile-Friendly Website Improvements",
			"Fix overflow, tiny tap targets, and type that is hard to read on a phone.",
			"quote"
		],
		[
			"HTML, CSS, and JavaScript Projects",
			"A front-end project for school or for yourself, explained so you can present it.",
			"quote"
		],
		[
			"Frontend Interface Development",
			"The screens and interactions. Data storage and sign-in are named separately if you need them.",
			"quote",
			"Interface only, unless a backend is part of the written scope."
		],
		[
			"Interactive Browser-Based Tools",
			"A small tool that runs in the browser: a calculator, a planner, a checker.",
			"quote"
		],
		[
			"Simple Browser Games",
			"A small game with a clear rule. Not a multiplayer live service unless scoped.",
			"quote"
		],
		[
			"Dashboard Interface Prototypes",
			"A clickable picture of a dashboard. Live data is not included unless we say it is.",
			"assessment",
			"Prototype. Not a connected admin system by default."
		],
		[
			"Website Bug Fixes",
			"A specific bug on a site we can access with your permission.",
			"assessment"
		],
		[
			"Content and Layout Improvements",
			"Rewrite placement, headings, and sections so the page says what you mean.",
			"quote"
		],
		[
			"Website Maintenance",
			"Small updates after launch, quoted per visit or as a short retainer once we know the site.",
			"quote"
		],
		[
			"Basic Search Engine Optimization",
			"Titles, descriptions, headings, and speed basics. No promise of a ranking.",
			"assessment"
		],
		[
			"Website Performance Improvements",
			"Images, scripts, and layout choices that make a page feel late.",
			"assessment"
		],
		[
			"Domain and Hosting Setup Guidance",
			"Help on an account you own. You pay the registrar and the host directly.",
			"assessment",
			"We do not take ownership of your domain."
		],
		[
			"Custom Interactive Web Projects",
			"Something that does not fit the list, scoped in writing before build.",
			"quote"
		],
		[
			"Online Learning Platform Prototypes",
			"Screens for a lesson flow. Not a finished school platform with accounts.",
			"assessment",
			"Prototype only, unless hosting, accounts, and storage are quoted."
		],
		[
			"Digital Product Showcase Pages",
			"A page that presents a template or download you sell or give away.",
			"quote"
		],
		[
			"QR Code Landing Pages",
			"A short page a QR code can open: contact, menu, or event.",
			"quote"
		],
		[
			"Small Business Online Presence Setup",
			"The minimum useful set: a page, a contact path, and graphics that match.",
			"quote"
		]
	]),
	...add("business", "Presence", [
		[
			"Business Branding Packages",
			"Mark, colors, and a few pieces that match, scoped as one project.",
			"quote"
		],
		[
			"Business Profile Design",
			"A profile image set for the networks you actually use.",
			"quote"
		],
		[
			"Digital Service Menus",
			"What you offer and how to ask, in a file or a page.",
			"quote"
		],
		[
			"Business Presentation Decks",
			"A deck for a partner, a lender, or a customer meeting.",
			"quote"
		],
		[
			"Social Media Content Packages",
			"A defined number of graphics, not an endless posting contract.",
			"quote"
		],
		[
			"Digital Product Catalogs",
			"Products, variants, and prices you confirm.",
			"quote"
		],
		[
			"Promotional Campaign Materials",
			"One campaign, one message, several sizes.",
			"quote"
		],
		[
			"Product Advertisement Sets",
			"A matched set for a product you are ready to show.",
			"quote"
		],
		[
			"Online Portfolio Setup",
			"Where the work lives and how a visitor writes to you.",
			"quote"
		],
		[
			"Inquiry and Contact Page Setup",
			"A contact path that tells the truth about how you reply.",
			"quote"
		],
		[
			"Small Business Website Development",
			"A compact site for a shop, tutor, or independent service.",
			"quote"
		],
		[
			"Digital Workflow Planning",
			"A written map of how an inquiry becomes a finished file. Not software unless scoped.",
			"assessment"
		],
		[
			"Online Presence Improvements",
			"What to fix first on the page and profiles you already have.",
			"assessment"
		],
		[
			"Product Launch Visuals",
			"The pictures and the page for a launch date you choose.",
			"quote"
		],
		[
			"Custom Digital Project Consultation",
			"A paid or quoted conversation to decide scope before design starts.",
			"assessment"
		],
		[
			"QR Code Contact Pages",
			"One QR, one page, the details you want public.",
			"quote"
		],
		[
			"Digital Brochure Creation",
			"A brochure PDF a customer can download.",
			"quote"
		],
		[
			"Basic Content Organization",
			"Headings and folders so your existing text is easier to publish.",
			"quote"
		],
		[
			"Business Information Page Setup",
			"Hours, service area, and contact, only with facts you provide.",
			"quote"
		],
		[
			"Digital Proposal and Pitch Deck Design",
			"A proposal that states scope, not imaginary guarantees.",
			"quote"
		]
	]),
	...add("video", "Video", [
		[
			"Short Promotional Video Editing",
			"A short cut from footage you provide and have rights to use.",
			"quote"
		],
		[
			"Social Media Video Layouts",
			"Captions, crop, and a cover frame for Reels, Stories, or a short post.",
			"quote"
		],
		[
			"YouTube Intro and Outro Concepts",
			"A short open and close. Longer channel packages are quoted after a sample.",
			"quote"
		],
		[
			"Basic Motion Graphics",
			"Simple moving type and shapes. Complex animation is assessed first.",
			"assessment"
		],
		[
			"Animated Presentation Elements",
			"A few motions inside a deck, not a full cartoon.",
			"quote"
		],
		[
			"Video Thumbnail Design",
			"A still thumbnail. Listed here when it belongs to a video, not only a poster.",
			"quote"
		],
		[
			"Simple Product Showcase Videos",
			"A short product clip from footage or photos you supply.",
			"quote"
		],
		[
			"Video Captions and Subtitle Formatting",
			"Captions timed to speech you provide. We do not invent a transcript of audio we cannot hear.",
			"quote"
		]
	]),
	...add("products", "Templates", [
		[
			"Presentation Templates",
			"A deck shell you can duplicate for class or work.",
			"starting"
		],
		[
			"Social Media Template Packs",
			"A set of editable post sizes.",
			"starting"
		],
		[
			"Website Template Designs",
			"A visual starting point. Connecting a database is not included.",
			"starting"
		],
		[
			"Digital Planners",
			"Undated or dated pages, as agreed.",
			"starting"
		],
		[
			"Budget Tracking Templates",
			"A spreadsheet for personal tracking. Not financial advice.",
			"starting"
		],
		[
			"Personal Productivity Templates",
			"Lists and weekly pages for your own use.",
			"starting"
		],
		[
			"Printable Worksheets",
			"Exercises for a subject you specify.",
			"starting"
		],
		[
			"Study and Reviewer Templates",
			"A reviewer structure students can fill.",
			"starting"
		],
		[
			"Digital Invitation Templates",
			"An invitation file you can edit with your event details.",
			"starting"
		],
		[
			"Resume Templates",
			"A layout. The career history has to be yours.",
			"starting"
		],
		[
			"Business Document Templates",
			"Letter, quotation, or simple proposal shells.",
			"starting"
		],
		[
			"Simple HTML Starter Templates",
			"A small HTML and CSS start for learning or a school hand-in.",
			"starting"
		],
		[
			"Beginner Coding Resources",
			"Notes and tiny examples we are willing to maintain. Not a full course.",
			"starting"
		],
		[
			"Downloadable Design Assets",
			"Patterns, frames, or marks made for reuse, with a note on how you may use them.",
			"starting"
		],
		[
			"Custom Digital Product Concepts",
			"A product idea scoped before any files are made.",
			"assessment"
		]
	]),
	...add("tools", "Tools", [
		[
			"Spreadsheet Design and Formatting",
			"A sheet that calculates what you describe, with labels a stranger could follow.",
			"quote"
		],
		[
			"Basic Budget Calculators",
			"A calculator for a budget you define. Not a forecast of your income.",
			"quote"
		],
		[
			"Online Forms and Checklists",
			"A form or checklist. Permanent storage needs an inbox or a database, which we will name if it is missing.",
			"quote"
		],
		[
			"Simple Web Calculators",
			"A browser calculator for one job: fees, sizes, or a class formula you provide.",
			"quote"
		],
		[
			"Digital Recordkeeping Templates",
			"A table for records you decide to keep. Not a legal archive.",
			"quote"
		],
		[
			"Interactive Information Tools",
			"A small explainer someone can click through.",
			"quote"
		],
		[
			"Basic Data Organization",
			"Sort and label a spreadsheet or folder of files you are allowed to share.",
			"assessment"
		],
		[
			"PDF and Document Formatting",
			"Consistent styles in a document that already has the words.",
			"quote"
		],
		[
			"File Organization Guidance",
			"A folder plan for a computer or drive, applied with you.",
			"assessment"
		],
		[
			"Basic Automation Prototypes",
			"A small script or macro. Anything that logs into accounts is assessed and may be declined.",
			"assessment"
		],
		[
			"Website Content Migration Assistance",
			"Move text and images you own from an old page to a new one.",
			"quote"
		],
		[
			"Simple QR Code Generation",
			"A QR code that points at a real URL you control.",
			"quote"
		],
		[
			"Web-Based Project Prototypes",
			"A prototype in the browser so you can react before a larger build.",
			"assessment"
		]
	]),
	...add("learning", "Learning", [
		[
			"Basic Coding Assistance",
			"Help on a beginner exercise. We will not quietly do a graded exam for you.",
			"assessment",
			"We help you understand the work. We do not take tests in your place."
		],
		[
			"HTML and CSS Learning Projects",
			"A page you build, with review of structure and layout.",
			"quote"
		],
		[
			"Beginner JavaScript Projects",
			"A small interactive page and an explanation of the parts you wrote.",
			"quote"
		],
		[
			"Website Troubleshooting Tutorials",
			"A guided look at a broken page so you can fix the next one.",
			"assessment"
		],
		[
			"Programming Environment Setup",
			"Editor, browser, and a first file that runs on your machine.",
			"quote"
		],
		[
			"Software Setup Guidance",
			"Install a program your class or job named, using a license you have.",
			"assessment"
		],
		[
			"Beginner Technology Consultations",
			"A plain-language session before you buy a course, a laptop, or a website.",
			"assessment"
		],
		[
			"Digital Productivity Guidance",
			"A simpler way to keep files, classes, and messages you already use.",
			"assessment"
		],
		[
			"Basic Website Accessibility Improvements",
			"Contrast, labels, headings, and keyboard use on a site we can review.",
			"assessment"
		],
		[
			"Website Usability Assessments",
			"Where a visitor gets stuck, written as notes rather than a redesign you did not ask for.",
			"assessment"
		]
	])
];
function categoryById(id) {
	return categories.find((category) => category.id === id);
}
function findService(id) {
	return services.find((service) => service.id === id);
}
function servicesIn(category) {
	if (!category || category === "all") return services;
	return services.filter((service) => service.category === category);
}
function filterServices(category, query, group) {
	const q = query.trim().toLowerCase();
	return servicesIn(category).filter((service) => {
		if (group && group !== "all" && service.group !== group) return false;
		if (!q) return true;
		return service.name.toLowerCase().includes(q) || service.summary.toLowerCase().includes(q) || (service.group?.toLowerCase().includes(q) ?? false);
	});
}
function groupsFor(category) {
	const names = /* @__PURE__ */ new Set();
	for (const service of servicesIn(category)) if (service.group) names.add(service.group);
	return [...names];
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-BIUHyiyQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function linkClass(active) {
	return "flex min-h-11 items-center px-3 text-sm font-semibold " + (active ? "text-teal-deep underline decoration-teal decoration-2 underline-offset-8" : "text-ink hover:text-teal-deep");
}
function NavLinks({ onNavigate, vertical = false }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const services = pathname.startsWith("/services");
	const portfolio = pathname.startsWith("/portfolio");
	const about = pathname.startsWith("/about");
	const contact = pathname.startsWith("/contact");
	const home = pathname === "/";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
		className: vertical ? "flex flex-col gap-1" : "flex items-center gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				onClick: onNavigate,
				className: linkClass(home),
				"aria-current": home ? "page" : void 0,
				children: "Home"
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/services",
				search: {
					category: "all",
					q: "",
					group: "all"
				},
				onClick: onNavigate,
				className: linkClass(services),
				"aria-current": services ? "page" : void 0,
				children: "Services"
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/portfolio",
				onClick: onNavigate,
				className: linkClass(portfolio),
				"aria-current": portfolio ? "page" : void 0,
				children: "Portfolio"
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/about",
				onClick: onNavigate,
				className: linkClass(about),
				"aria-current": about ? "page" : void 0,
				children: "About"
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/contact",
				onClick: onNavigate,
				className: linkClass(contact),
				"aria-current": contact ? "page" : void 0,
				children: "Contact"
			}) })
		]
	});
}
function Logo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: "flex items-center gap-3 text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 36 36",
			className: "size-9 shrink-0",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "36",
					height: "36",
					fill: "var(--color-navy)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M10 26V10h12",
					fill: "none",
					stroke: "var(--color-paper)",
					strokeWidth: "2.2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M16 26h10V14",
					fill: "none",
					stroke: "var(--color-teal)",
					strokeWidth: "2.2"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block font-display text-xl font-semibold tracking-tight",
				children: "Inojin"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-xs font-semibold uppercase tracking-widest text-ink-soft",
				children: "Services"
			})]
		})]
	});
}
function Shell({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [showTop, setShowTop] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setShowTop(window.scrollY > 500);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-navy focus:px-4 focus:py-3 focus:text-paper",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-6xl items-center justify-between gap-4 px-5 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden lg:block",
							"aria-label": "Primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/request",
								search: { service: "" },
								className: "inline-flex min-h-11 items-center bg-teal-deep px-3 text-sm font-semibold text-paper hover:bg-navy sm:px-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sm:hidden",
									children: "Request"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: site.copy.request
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
								open,
								onOpenChange: setOpen,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex size-11 items-center justify-center border border-line text-ink lg:hidden",
										"aria-label": "Open menu",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
											className: "size-5",
											"aria-hidden": "true"
										})
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-navy/60" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
									className: "fixed inset-y-0 right-0 z-50 flex w-[min(100%,20rem)] flex-col bg-paper px-5 py-4 shadow-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
												className: "font-display text-2xl text-ink",
												children: "Menu"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
												asChild: true,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "inline-flex size-11 items-center justify-center border border-line",
													"aria-label": "Close menu",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
												})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
											className: "sr-only",
											children: "Site sections"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
											className: "mt-6",
											"aria-label": "Mobile",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, {
												vertical: true,
												onNavigate: () => setOpen(false)
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/request",
											search: { service: "" },
											onClick: () => setOpen(false),
											className: "mt-6 inline-flex min-h-11 items-center justify-center bg-teal-deep px-4 font-semibold text-paper",
											children: site.copy.request
										})
									]
								})] })]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "content",
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			showTop ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed bottom-5 right-5 z-20 inline-flex size-11 items-center justify-center border border-line bg-paper text-ink shadow-none",
				onClick: () => window.scrollTo({
					top: 0,
					behavior: "smooth"
				}),
				"aria-label": "Back to top",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-5" })
			}) : null
		]
	});
}
function CopyButton({ value, label, doneLabel = "Copied" }) {
	const [state, setState] = (0, import_react.useState)("idle");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex flex-col items-start gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "inline-flex min-h-11 items-center gap-2 border border-ink bg-paper px-4 text-sm font-semibold text-ink hover:bg-ink hover:text-paper",
			onClick: async () => {
				const ok = await copyText(value);
				setState(ok ? "done" : "failed");
				if (ok) window.setTimeout(() => setState("idle"), 2e3);
			},
			children: [state === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "size-4",
				"aria-hidden": "true"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
				className: "size-4",
				"aria-hidden": "true"
			}), state === "done" ? doneLabel : label]
		}), state === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "max-w-xs text-sm text-danger",
			role: "status",
			children: "Clipboard is blocked. Select the number below and copy it yourself."
		}) : null]
	});
}
function ProfileLink({ href, network, name }) {
	if (!href) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-semibold text-ink",
				children: [
					network,
					": ",
					name
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: true,
				className: "mt-2 inline-flex min-h-11 items-center border border-line px-4 text-sm font-semibold text-ink-soft",
				children: ["Follow on ", network]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-ink-soft",
				children: [
					"The button stays off until a real ",
					network,
					" URL is saved in the site settings. The page name is ",
					name,
					"."
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "font-semibold text-ink",
		children: [
			network,
			": ",
			name
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href,
		target: "_blank",
		rel: "noreferrer",
		className: "mt-2 inline-flex min-h-11 items-center border border-ink px-4 text-sm font-semibold text-ink hover:bg-ink hover:text-paper",
		children: ["Follow on ", network]
	})] });
}
function DonationPanel({ compact = false }) {
	const [guide, setGuide] = (0, import_react.useState)(false);
	const number = site.gcash.number;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: compact ? void 0 : "support",
		className: compact ? "" : "scroll-mt-24 bg-foam",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: compact ? "" : "mx-auto w-full max-w-6xl px-5 py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-line bg-paper px-5 py-6 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 text-teal-deep",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
							className: "size-5",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-widest",
							children: "Voluntary support"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 max-w-xl font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl",
						children: site.copy.donationTitle
					}),
					compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl whitespace-pre-line text-ink-soft",
						children: site.copy.donationNear
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl whitespace-pre-line text-ink-soft",
						children: site.copy.donationBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 grid gap-4 border-t border-line pt-6 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs font-semibold uppercase tracking-widest text-ink-soft",
								children: "Payment method"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-semibold",
								children: site.gcash.method
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs font-semibold uppercase tracking-widest text-ink-soft",
								children: "Account name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-semibold",
								children: site.gcash.accountName
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs font-semibold uppercase tracking-widest text-ink-soft",
								children: "GCash number"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-semibold tracking-wide",
								children: number
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-ink-soft",
						children: site.copy.donationVerify
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-ink",
						children: "Donations are sent by you inside GCash. This website does not receive, total, or confirm them."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								value: number,
								label: "Copy GCash Number"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex min-h-11 items-center bg-teal-deep px-4 text-sm font-semibold text-paper hover:bg-navy",
								onClick: () => setGuide((value) => !value),
								"aria-expanded": guide,
								children: "Support Us via GCash"
							}),
							compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/support",
								className: "inline-flex min-h-11 items-center px-2 text-sm font-semibold text-teal-deep underline underline-offset-4",
								children: "Read the full note"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/services",
								search: {
									category: "all",
									q: "",
									group: "all"
								},
								className: "inline-flex min-h-11 items-center px-2 text-sm font-semibold text-teal-deep underline underline-offset-4",
								children: "Back to Our Services"
							})
						]
					}),
					guide ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-4 list-decimal space-y-2 bg-foam px-5 py-4 pl-9 text-sm text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open the GCash app yourself. Do not share an MPIN or OTP with anyone." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"Send to ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: number }),
								" and check that the recipient name is ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: site.gcash.accountName }),
								"."
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "There is no donation goal, progress bar, or automatic thank-you receipt on this site." }),
							site.gcash.paymentLink ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"A payment link was supplied:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "font-semibold text-teal-deep underline",
									href: site.gcash.paymentLink,
									children: "Open the supplied GCash link"
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "No GCash payment link has been added. Use the number and name above." })
						]
					}) : null,
					site.gcash.qrImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: site.gcash.qrImage,
						alt: "Supplied GCash QR code",
						className: "mt-6 h-40 w-40 border border-line object-contain"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-ink-soft",
						children: "A GCash QR image can be placed here after you supply one. None is shown until then."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 font-display text-xl text-ink",
						children: site.copy.donationThanks
					}),
					!compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 grid gap-6 border-t border-line pt-6 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileLink, {
							href: site.facebookUrl,
							network: "Facebook",
							name: site.facebookName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileLink, {
							href: site.instagramUrl,
							network: "Instagram",
							name: site.instagramName
						})]
					}) : null
				]
			})
		})
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-line bg-navy text-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid w-full max-w-6xl gap-10 px-5 py-14 md:grid-cols-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl",
							children: "Inojin Services"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xs text-sm text-paper/80",
							children: site.tagline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-paper/80",
							children: site.copy.socialNote
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-paper/60",
						children: "Visit"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/services",
								search: {
									category: "all",
									q: "",
									group: "all"
								},
								className: "underline-offset-4 hover:underline",
								children: "Services"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/portfolio",
								className: "underline-offset-4 hover:underline",
								children: "Portfolio"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/faq",
								className: "underline-offset-4 hover:underline",
								children: "FAQ"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/about",
								className: "underline-offset-4 hover:underline",
								children: "About"
							}) })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-widest text-paper/60",
							children: "Contact"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm",
							children: "Phone"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "font-semibold underline decoration-teal underline-offset-4",
							href: `tel:${site.phoneTel}`,
							children: site.phoneDisplay
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								value: site.phoneDisplay,
								label: "Copy phone number"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-sm",
							children: ["Facebook: ", site.facebookName]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: ["Instagram: ", site.instagramName]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-widest text-paper/60",
							children: "Support"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-paper/80",
							children: [
								"GCash · ",
								site.gcash.accountName,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-paper",
									children: site.gcash.number
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								value: site.gcash.number,
								label: "Copy GCash number"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/support",
							className: "mt-4 inline-flex min-h-11 items-center text-sm font-semibold text-paper underline decoration-teal underline-offset-4",
							children: "Support section"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-paper/15",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-6xl flex-wrap gap-x-5 gap-y-2 px-5 py-4 text-sm text-paper/70",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/privacy",
						className: "underline-offset-4 hover:underline",
						children: "Privacy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/terms",
						className: "underline-offset-4 hover:underline",
						children: "Terms"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/faq",
						className: "underline-offset-4 hover:underline",
						children: "FAQ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Donations are optional and separate from service payments." })
				]
			})
		})]
	});
}
var styles_default = "/assets/styles-CAiT5846.css";
var Route$12 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: `${site.name} — Technology, design, and websites` },
			{
				name: "description",
				content: site.tagline
			},
			{
				name: "theme-color",
				content: "#0b1726"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,560;9..144,680&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$11 = () => import("./routes-Du2BFLsh.mjs");
var Route$11 = createFileRoute("/")({
	head: () => ({ meta: [{ title: `${site.name} — Technology, design, and websites` }, {
		name: "description",
		content: site.heroText
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./about-d6q6F0Qq.mjs");
var Route$10 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: `About — ${site.name}` }, {
		name: "description",
		content: site.tagline
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./contact-CaTMux62.mjs");
var Route$9 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: `Contact — ${site.name}` }, {
		name: "description",
		content: "Call, text, or send a service inquiry to Inojin Services."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./faq-BzRHAQj3.mjs");
var Route$8 = createFileRoute("/faq")({
	head: () => ({ meta: [{ title: `FAQ — ${site.name}` }, {
		name: "description",
		content: "Common questions about inquiries, recovery limits, prices, and donations."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./portfolio-CF0g09GW.mjs");
var Route$7 = createFileRoute("/portfolio")({
	head: () => ({ meta: [{ title: `Portfolio — ${site.name}` }, {
		name: "description",
		content: "Demonstration concepts and studio photographs. Not client work."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./privacy-BLYQLxUk.mjs");
var Route$6 = createFileRoute("/privacy")({
	head: () => ({ meta: [{ title: `Privacy — ${site.name}` }, {
		name: "description",
		content: "What Inojin Services does and does not collect on this website."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./request-BUXpHbTa.mjs");
var Route$5 = createFileRoute("/request")({
	validateSearch: (search) => ({ service: typeof search.service === "string" ? search.service : "" }),
	head: () => ({ meta: [{ title: `Request a service — ${site.name}` }, {
		name: "description",
		content: "Tell Inojin Services what you need. The form prepares a message you send yourself."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./services-C5swur1F.mjs");
var Route$4 = createFileRoute("/services")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./support-DltYnRB2.mjs");
var Route$3 = createFileRoute("/support")({
	head: () => ({ meta: [{ title: `Support Inojin Services — ${site.name}` }, {
		name: "description",
		content: "Optional GCash support for Inojin Services. Not a payment for a service."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./terms-6ivnX6vH.mjs");
var Route$2 = createFileRoute("/terms")({
	head: () => ({ meta: [{ title: `Terms — ${site.name}` }, {
		name: "description",
		content: "How inquiries, quotations, recovery limits, and donations work."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./services.index-7rVPPggu.mjs");
var Route$1 = createFileRoute("/services/")({
	validateSearch: (search) => ({
		category: typeof search.category === "string" ? search.category : "all",
		q: typeof search.q === "string" ? search.q : "",
		group: typeof search.group === "string" ? search.group : "all"
	}),
	head: () => ({ meta: [{ title: `Services — ${site.name}` }, {
		name: "description",
		content: "Phone, computer, network, design, website, and business services from Inojin Services."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./services._serviceId-1OKLwHQf.mjs");
var Route = createFileRoute("/services/$serviceId")({
	head: ({ params }) => {
		const service = findService(params.serviceId);
		return { meta: [{ title: service ? `${service.name} — ${site.name}` : `Service — ${site.name}` }, {
			name: "description",
			content: service?.summary ?? "Service details"
		}] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$11.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$12
});
var AboutRoute = Route$10.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$12
});
var ContactRoute = Route$9.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$12
});
var FaqRoute = Route$8.update({
	id: "/faq",
	path: "/faq",
	getParentRoute: () => Route$12
});
var PortfolioRoute = Route$7.update({
	id: "/portfolio",
	path: "/portfolio",
	getParentRoute: () => Route$12
});
var PrivacyRoute = Route$6.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$12
});
var RequestRoute = Route$5.update({
	id: "/request",
	path: "/request",
	getParentRoute: () => Route$12
});
var ServicesRoute = Route$4.update({
	id: "/services",
	path: "/services",
	getParentRoute: () => Route$12
});
var SupportRoute = Route$3.update({
	id: "/support",
	path: "/support",
	getParentRoute: () => Route$12
});
var TermsRoute = Route$2.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$12
});
var ServicesIndexRoute = Route$1.update({
	id: "/",
	path: "/",
	getParentRoute: () => ServicesRoute
});
var ServicesRouteChildren = {
	ServicesServiceIdRoute: Route.update({
		id: "/$serviceId",
		path: "/$serviceId",
		getParentRoute: () => ServicesRoute
	}),
	ServicesIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	ContactRoute,
	FaqRoute,
	PortfolioRoute,
	PrivacyRoute,
	RequestRoute,
	ServicesRoute: ServicesRoute._addFileChildren(ServicesRouteChildren),
	SupportRoute,
	TermsRoute
};
var routeTree = Route$12._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { copyText as _, CopyButton as a, categories as c, findService as d, groupsFor as f, servicesIn as g, services as h, Route$5 as i, categoryById as l, priceText as m, Route as n, DonationPanel as o, priceKindLabel as p, Route$1 as r, ProfileLink as s, router_exports as t, filterServices as u };
