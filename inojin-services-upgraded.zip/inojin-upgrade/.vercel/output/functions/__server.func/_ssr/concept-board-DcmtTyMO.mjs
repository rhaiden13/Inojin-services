import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/concept-board-DcmtTyMO.js
var import_jsx_runtime = require_jsx_runtime();
var portfolioFilters = [
	"All",
	"Graphic Design",
	"Presentations",
	"Advertisements",
	"Websites",
	"Branding",
	"Digital Products",
	"Technical Projects",
	"Other Creative Work"
];
var portfolio = [
	{
		id: "studio-desk",
		title: "Studio desk study",
		category: "Other Creative Work",
		summary: "A photograph made for this website: laptop, phone, and paper on a work table. It is not a client commission.",
		tools: "Photograph",
		deliverables: "Website image",
		status: "Studio photograph — not client work",
		kind: "photo",
		image: "/images/desk.jpg",
		imageAlt: "Overhead photograph of a navy laptop, a phone, and printed sheets on a pale desk"
	},
	{
		id: "print-still",
		title: "Print material still life",
		category: "Graphic Design",
		summary: "Paper, a poster with abstract shapes, and a card stack. Used to show the kind of print work the studio can discuss. No client logo.",
		tools: "Photograph",
		deliverables: "Gallery image",
		status: "Studio photograph — not client work",
		kind: "photo",
		image: "/images/print.jpg",
		imageAlt: "Printed posters and cards with abstract navy and teal shapes on a table"
	},
	{
		id: "color-devices",
		title: "Color and device notes",
		category: "Branding",
		summary: "A phone and a small navy, teal, and paper swatch. A reference for the Inojin palette, not a client identity.",
		tools: "Photograph",
		deliverables: "Palette reference",
		status: "Demonstration concept",
		kind: "photo",
		image: "/images/swatches.jpg",
		imageAlt: "A dark phone beside a card of navy, teal, and cream color swatches"
	},
	{
		id: "workspace",
		title: "Workspace with a site on screen",
		category: "Websites",
		summary: "A desk photograph suggesting a website in progress. The screen is intentionally not a real client site.",
		tools: "Photograph",
		deliverables: "Gallery image",
		status: "Studio photograph — not client work",
		kind: "photo",
		image: "/images/workspace.jpg",
		imageAlt: "A laptop on a wooden desk with a blurred navy and cream page on the screen"
	},
	{
		id: "defense-deck",
		title: "Project defense deck",
		category: "Presentations",
		summary: "A sample slide structure for a student defense: problem, method, result, and a closing slide. Placeholder words only.",
		tools: "Layout concept",
		deliverables: "Slide structure preview",
		status: "Demonstration concept",
		kind: "deck"
	},
	{
		id: "community-poster",
		title: "Community afternoon poster",
		category: "Advertisements",
		summary: "A tarpaulin-style poster concept for a neighborhood event. The date and place are samples, not a real booking.",
		tools: "Layout concept",
		deliverables: "Poster preview",
		status: "Demonstration concept",
		kind: "poster"
	},
	{
		id: "product-post",
		title: "Weekend market post",
		category: "Advertisements",
		summary: "A square social post concept. It does not advertise a real product or a real discount.",
		tools: "Layout concept",
		deliverables: "Social frame preview",
		status: "Demonstration concept",
		kind: "social"
	},
	{
		id: "mark-board",
		title: "Wordmark and palette board",
		category: "Branding",
		summary: "How a small identity board can present a name, two colors, and a type note. This board is for Inojin itself, not a client.",
		tools: "Layout concept",
		deliverables: "Identity board preview",
		status: "Demonstration concept",
		kind: "brand"
	},
	{
		id: "resume-layout",
		title: "One-page resume layout",
		category: "Digital Products",
		summary: "A resume grid with sample section labels. It is empty of any person’s job history on purpose.",
		tools: "Layout concept",
		deliverables: "Resume preview",
		status: "Demonstration concept",
		kind: "resume"
	},
	{
		id: "menu-page",
		title: "Short menu website",
		category: "Websites",
		summary: "A phone-width menu page concept. Dishes listed here are examples, not a restaurant we represent.",
		tools: "HTML layout",
		deliverables: "Page preview",
		status: "Demonstration concept",
		kind: "web"
	},
	{
		id: "qr-card",
		title: "QR contact card",
		category: "Technical Projects",
		summary: "A contact card concept with a drawn QR placeholder. It does not encode a live payment or profile link.",
		tools: "Layout concept",
		deliverables: "Card preview",
		status: "Demonstration concept",
		kind: "qr"
	},
	{
		id: "planner-page",
		title: "Week planner page",
		category: "Digital Products",
		summary: "A printable week grid. A template direction, not a downloaded product for sale yet.",
		tools: "Layout concept",
		deliverables: "Planner preview",
		status: "Demonstration concept",
		kind: "resume"
	}
];
function ConceptBoard({ kind, title }) {
	if (kind === "deck") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid aspect-[4/3] grid-cols-2 gap-2 bg-navy p-3",
		children: [
			"Problem",
			"Method",
			"Result",
			"Close"
		].map((label, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col justify-between bg-paper p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
				children: ["0", index + 1]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-xl text-ink",
				children: label
			})]
		}, label))
	});
	if (kind === "poster") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex aspect-[3/4] flex-col justify-between bg-teal-deep p-5 text-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest",
				children: "Sample event"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl leading-none",
					children: "Afternoon on the street"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-px w-16 bg-paper" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm",
					children: "Date and place are examples."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest",
				children: "Demonstration"
			})
		]
	});
	if (kind === "social") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex aspect-square flex-col justify-between bg-paper-2 p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
				children: "Square post"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl leading-none text-ink",
				children: "Market day"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink-soft",
				children: "No real discount. No real shop."
			})
		]
	});
	if (kind === "brand") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "aspect-[4/3] bg-paper p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl text-ink",
				children: "Inojin"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-ink-soft",
				children: "Wordmark study"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-12 w-12 bg-navy" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-12 w-12 bg-teal-deep" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-12 w-12 border border-line bg-paper-2" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-ink-soft",
				children: title
			})
		]
	});
	if (kind === "web") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex aspect-[4/3] items-center justify-center bg-paper-2 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-40 border border-ink bg-paper p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
				children: "Menu"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2 text-sm text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between border-b border-line pb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Garlic rice" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "sample" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between border-b border-line pb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Iced tea" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "sample" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Contact" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "page" })]
					})
				]
			})]
		})
	});
	if (kind === "qr") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid aspect-[4/3] grid-cols-[1fr_auto] items-center gap-4 bg-paper p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
				children: "Contact card"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-3xl text-ink",
				children: "Inojin Services"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-ink-soft",
				children: "The pattern beside this text is decorative. It is not a scannable code."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid size-24 grid-cols-5 gap-1 bg-navy p-2",
			"aria-hidden": "true",
			children: Array.from({ length: 25 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: index % 3 === 0 ? "bg-paper" : "bg-navy" }, index))
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "aspect-[4/3] bg-paper p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-teal-deep",
				children: "Resume"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-3xl text-ink",
				children: "Name withheld"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-3 text-sm",
				children: [
					"Experience",
					"Education",
					"Tools"
				].map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-ink",
					children: section
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-ink-soft",
					children: "Sample line — not a real person"
				})] }, section))
			})
		]
	});
}
//#endregion
export { portfolio as n, portfolioFilters as r, ConceptBoard as t };
