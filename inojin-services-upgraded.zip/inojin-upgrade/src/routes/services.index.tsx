import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ServiceBrowser, type ServiceSearch } from "@/components/service-browser";
import { site } from "@/lib/site";

export const Route = createFileRoute("/services/")({
  validateSearch: (search: Record<string, unknown>): ServiceSearch => ({
    category: typeof search.category === "string" ? search.category : "all",
    q: typeof search.q === "string" ? search.q : "",
    group: typeof search.group === "string" ? search.group : "all",
  }),
  head: () => ({
    meta: [
      { title: `Services — ${site.name}` },
      { name: "description", content: "Phone, computer, network, design, website, and business services from Inojin Services." },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  return (
    <>
      <header className="border-b border-line">
        <div className="mx-auto w-full max-w-6xl px-5 py-12">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Catalog</p>
          <h1 className="mt-3 font-display text-4xl text-ink sm:text-5xl">Services</h1>
          <p className="mt-4 max-w-2xl text-lg text-ink-soft">
            Explore the full catalog, compare service scopes, and open any listing for its inclusions, preparation checklist, expected deliverables, and limitations. Prices stay unpublished until an official amount is set. {site.copy.priceDepends}
          </p>
        </div>
      </header>
      <ServiceBrowser
        search={search}
        onSearch={(next) => {
          void navigate({ to: "/services", search: next });
        }}
      />
    </>
  );
}
