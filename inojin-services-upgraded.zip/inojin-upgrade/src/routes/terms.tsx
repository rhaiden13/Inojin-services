import { createFileRoute } from "@tanstack/react-router";
import { site } from "@/lib/site";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: `Terms — ${site.name}` },
      { name: "description", content: "How inquiries, quotations, recovery limits, and donations work." },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <article className="mx-auto w-full max-w-3xl space-y-4 px-5 py-12 text-ink">
      <h1 className="font-display text-4xl sm:text-5xl">Terms</h1>
      <p>
        Browsing this site is free. A service starts only after you and Inojin Services agree on the scope, the price, and the schedule. A quotation is not a guarantee that every device can be fixed or that every file can be recovered.
      </p>
      <p>
        Recovery, password, and network help uses official methods and requires ownership or permission. Unauthorized access is not offered. Hardware repair may be referred elsewhere. Software help is not the same as opening a machine.
      </p>
      <p>{site.copy.priceDepends}</p>
      <p>
        Design and website work uses materials you have the right to share. We do not claim a front-end page is a complete system with accounts, storage, or payments unless that is written into the scope. Domain, hosting, printing, music licenses, and app-store fees are third-party costs you pay to those providers.
      </p>
      <p>
        School help explains the work. It is not an offer to sit an exam or submit a graded assignment as if it were yours alone.
      </p>
      <p>
        Voluntary GCash support is a gift, not a service payment and not a purchase. Send it only after you check the name {site.gcash.accountName} and the number {site.gcash.number}. This website cannot confirm, receipt, or automatically refund a transfer, because the transfer happens in GCash, not here. If a gift was a mistake, contact {site.phoneDisplay} and we will try to help, within what GCash allows.
      </p>
      <p>
        The portfolio is demonstration material unless a piece is clearly marked as permitted client work. Nothing on the site is a promise of an award, a ranking, or a business result.
      </p>
    </article>
  );
}
