import { createFileRoute } from "@tanstack/react-router";
import { InquiryForm } from "@/components/inquiry-form";
import { site } from "@/lib/site";

export const Route = createFileRoute("/request")({
  validateSearch: (search: Record<string, unknown>) => ({
    service: typeof search.service === "string" ? search.service : "",
  }),
  head: () => ({
    meta: [
      { title: `Request a service — ${site.name}` },
      { name: "description", content: "Tell Inojin Services what you need. The form prepares a message you send yourself." },
    ],
  }),
  component: RequestPage,
});

function RequestPage() {
  const { service } = Route.useSearch();
  return (
    <div className="mx-auto w-full max-w-3xl px-5 py-12">
      <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Inquiry</p>
      <h1 className="mt-3 font-display text-4xl text-ink sm:text-5xl">Request a service</h1>
      <p className="mt-4 text-ink-soft">
        Describe the job. You will review it before anything is copied. Service payments, if you later agree to them, are separate from donations.
      </p>
      <div className="mt-8">
        <InquiryForm initialService={service} />
      </div>
    </div>
  );
}
