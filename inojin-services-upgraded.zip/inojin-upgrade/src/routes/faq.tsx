import { createFileRoute } from "@tanstack/react-router";
import { faqs, site } from "@/lib/site";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: `FAQ — ${site.name}` },
      { name: "description", content: "Common questions about inquiries, recovery limits, prices, and donations." },
    ],
  }),
  component: FaqPage,
});

function FaqPage() {
  return (
    <div className="mx-auto w-full max-w-3xl px-5 py-12">
      <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">FAQ</p>
      <h1 className="mt-3 font-display text-4xl text-ink sm:text-5xl">Questions, answered plainly</h1>
      <div className="mt-8 divide-y divide-line border-y border-line">
        {faqs.map((item) => (
          <details key={item.q} className="group py-4">
            <summary className="cursor-pointer list-none font-semibold text-ink [&::-webkit-details-marker]:hidden">
              <span className="flex items-start justify-between gap-4">
                {item.q}
                <span className="text-teal-deep group-open:rotate-45" aria-hidden="true">+</span>
              </span>
            </summary>
            <p className="mt-3 max-w-2xl text-ink-soft">{item.a}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
