import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { categories } from "@/lib/catalog";
import { portfolio } from "@/lib/portfolio";
import { site } from "@/lib/site";
import { ConceptBoard } from "@/components/concept-board";
import { DonationPanel, ProfileLink } from "@/components/site-shell";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${site.name} — Technology, design, and websites` },
      { name: "description", content: site.heroText },
    ],
  }),
  component: Home,
});

const featured = categories.slice(0, 6);
const more = categories.slice(6);

function Home() {
  return (
    <>
      <section className="border-b border-line">
        <div className="mx-auto grid w-full max-w-6xl items-end gap-10 px-5 py-12 lg:grid-cols-12 lg:py-16">
          <div className="lg:col-span-6">
            <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Inojin Services</p>
            <h1 className="mt-3 font-display text-4xl font-semibold leading-tight tracking-tight text-ink sm:text-6xl">
              {site.heroTitle}
            </h1>
            <p className="mt-5 max-w-xl text-lg text-ink-soft">{site.heroText}</p>
            <p className="mt-4 text-sm font-medium text-ink">{site.tagline}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/services"
                search={{ category: "all", q: "", group: "all" }}
                className="inline-flex min-h-11 items-center bg-teal-deep px-5 font-semibold text-paper hover:bg-navy"
              >
                {site.copy.explore}
              </Link>
              <Link
                to="/request"
                search={{ service: "" }}
                className="inline-flex min-h-11 items-center border border-ink px-5 font-semibold text-ink hover:bg-ink hover:text-paper"
              >
                {site.copy.start}
              </Link>
            </div>
            <SearchStrip />
          </div>
          <figure className="lg:col-span-6">
            <img
              src="/images/desk.jpg"
              alt="Studio desk with a navy laptop, a phone, and printed sheets"
              className="aspect-[16/10] w-full object-cover"
            />
            <figcaption className="mt-2 text-sm text-ink-soft">
              Studio photograph for the site. Not a client project.
            </figcaption>
          </figure>
        </div>
      </section>

      <section className="mx-auto w-full max-w-6xl px-5 py-14">
        <div className="flex items-end justify-between gap-4">
          <h2 className="font-display text-4xl text-ink">Service categories</h2>
          <Link to="/services" search={{ category: "all", q: "", group: "all" }} className="text-sm font-semibold text-teal-deep underline underline-offset-4">
            Full list
          </Link>
        </div>
        <ol className="mt-8 divide-y divide-line border-y border-line">
          {featured.map((category, index) => (
            <li key={category.id}>
              <Link
                to="/services"
                search={{ category: category.id, q: "", group: "all" }}
                className="grid gap-2 py-5 sm:grid-cols-[4rem_1fr_auto] sm:items-baseline"
              >
                <span className="font-display text-2xl text-teal-deep">0{index + 1}</span>
                <span>
                  <span className="block font-display text-3xl text-ink">{category.name}</span>
                  <span className="mt-1 block max-w-xl text-ink-soft">{category.blurb}</span>
                </span>
                <span className="text-sm font-semibold text-teal-deep">Browse</span>
              </Link>
            </li>
          ))}
        </ol>
        <ul className="mt-6 flex flex-wrap gap-3">
          {more.map((category) => (
            <li key={category.id}>
              <Link
                to="/services"
                search={{ category: category.id, q: "", group: "all" }}
                className="inline-flex min-h-11 items-center border border-line px-3 text-sm font-semibold hover:border-ink"
              >
                {category.name}
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section className="border-y border-line bg-paper-2">
        <div className="mx-auto w-full max-w-6xl px-5 py-14">
          <h2 className="font-display text-4xl text-ink">Featured work</h2>
          <p className="mt-3 max-w-2xl text-ink-soft">{site.copy.portfolioNote}</p>
          <p className="mt-2 text-sm text-ink">Every item below is labeled. None of it is presented as a client commission.</p>
          <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {portfolio.slice(0, 4).map((item) => (
              <li key={item.id} className="border border-line bg-paper">
                {item.image ? (
                  <img src={item.image} alt={item.imageAlt ?? item.title} className="aspect-[4/3] w-full object-cover" />
                ) : (
                  <ConceptBoard kind={item.kind} title={item.title} />
                )}
                <div className="px-3 py-3">
                  <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">{item.status}</p>
                  <p className="mt-1 font-display text-xl text-ink">{item.title}</p>
                </div>
              </li>
            ))}
          </ul>
          <Link to="/portfolio" className="mt-6 inline-flex min-h-11 items-center font-semibold text-teal-deep underline underline-offset-4">
            Open the gallery
          </Link>
        </div>
      </section>

      <section className="mx-auto grid w-full max-w-6xl gap-12 px-5 py-14 lg:grid-cols-2">
        <div>
          <h2 className="font-display text-4xl text-ink">How it works</h2>
          <ol className="mt-6 space-y-5">
            {site.copy.steps.map((step, index) => (
              <li key={step} className="grid grid-cols-[3rem_1fr] gap-3">
                <span className="font-display text-2xl text-teal-deep">0{index + 1}</span>
                <span className="pt-1 text-ink">{step}</span>
              </li>
            ))}
          </ol>
        </div>
        <div>
          <h2 className="font-display text-4xl text-ink">Why Inojin Services</h2>
          <ul className="mt-6 space-y-5">
            {site.copy.why.map((item) => (
              <li key={item.title} className="border-t border-line pt-4">
                <p className="font-semibold text-ink">{item.title}</p>
                <p className="mt-1 text-ink-soft">{item.text}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="border-y border-line">
        <div className="mx-auto w-full max-w-6xl px-5 py-14">
          <h2 className="font-display text-4xl text-ink">Client notes</h2>
          <p className="mt-4 max-w-2xl text-ink-soft">
            No customer testimonials are published yet. When someone gives permission, their words can be added here. This site does not invent reviews, names, star ratings, or customer counts.
          </p>
        </div>
      </section>

      <DonationPanel compact />

      <section className="mx-auto w-full max-w-6xl px-5 py-14">
        <h2 className="font-display text-4xl text-ink">Contact</h2>
        <p className="mt-3 max-w-2xl text-ink-soft">{site.copy.contactNote}</p>
        <p className="mt-4">
          <a className="font-semibold text-teal-deep underline underline-offset-4" href={`tel:${site.phoneTel}`}>
            {site.phoneDisplay}
          </a>
        </p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <ProfileLink href={site.facebookUrl} network="Facebook" name={site.facebookName} />
          <ProfileLink href={site.instagramUrl} network="Instagram" name={site.instagramName} />
        </div>
        <Link to="/contact" className="mt-6 inline-flex min-h-11 items-center font-semibold text-ink underline underline-offset-4">
          Contact page
        </Link>
      </section>
    </>
  );
}

function SearchStrip() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  return (
    <form
      className="mt-8 flex max-w-xl flex-col gap-2 sm:flex-row"
      role="search"
      onSubmit={(event) => {
        event.preventDefault();
        void navigate({ to: "/services", search: { category: "all", q, group: "all" } });
      }}
    >
      <label className="sr-only" htmlFor="home-search">
        Search services
      </label>
      <input
        id="home-search"
        value={q}
        onChange={(event) => setQ(event.target.value)}
        placeholder="Search phone help, logos, websites"
        className="min-h-11 flex-1 border border-line bg-paper px-3"
      />
      <button type="submit" className="inline-flex min-h-11 items-center justify-center border border-ink px-4 font-semibold">
        Search
      </button>
    </form>
  );
}
