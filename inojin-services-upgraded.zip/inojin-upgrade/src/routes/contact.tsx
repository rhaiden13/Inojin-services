import { createFileRoute } from "@tanstack/react-router";
import { InquiryForm } from "@/components/inquiry-form";
import { CopyButton, ProfileLink } from "@/components/site-shell";
import { site } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: `Contact — ${site.name}` },
      { name: "description", content: "Call, text, or send a service inquiry to Inojin Services." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <div className="mx-auto grid w-full max-w-6xl gap-12 px-5 py-12 lg:grid-cols-[1fr_1.2fr]">
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Contact</p>
        <h1 className="mt-3 font-display text-4xl text-ink sm:text-5xl">Let’s work on your next idea together.</h1>
        <p className="mt-4 text-lg text-ink-soft">{site.copy.contactNote}</p>
        <dl className="mt-8 space-y-5">
          <div>
            <dt className="text-xs font-semibold uppercase tracking-widest text-ink-soft">Phone</dt>
            <dd className="mt-1">
              <a className="font-display text-3xl text-ink underline decoration-teal underline-offset-4" href={`tel:${site.phoneTel}`}>
                {site.phoneDisplay}
              </a>
              <div className="mt-3">
                <CopyButton value={site.phoneDisplay} label="Copy phone number" />
              </div>
            </dd>
          </div>
          <div>
            <dt className="text-xs font-semibold uppercase tracking-widest text-ink-soft">Social</dt>
            <dd className="mt-3 space-y-5">
              <ProfileLink href={site.facebookUrl} network="Facebook" name={site.facebookName} />
              <ProfileLink href={site.instagramUrl} network="Instagram" name={site.instagramName} />
              <p className="text-sm text-ink-soft">{site.copy.socialNote}</p>
            </dd>
          </div>
          <div>
            <dt className="text-xs font-semibold uppercase tracking-widest text-ink-soft">Donations through GCash</dt>
            <dd className="mt-1 text-ink">
              {site.gcash.accountName}
              <br />
              <span className="font-semibold">{site.gcash.number}</span>
            </dd>
          </div>
          <div>
            <dt className="text-xs font-semibold uppercase tracking-widest text-ink-soft">Availability</dt>
            <dd className="mt-1 text-ink">{site.availability}</dd>
          </div>
        </dl>
        <p className="mt-8 text-sm text-ink-soft">
          Privacy, in short: the form prepares a message on your device. It is not saved on this website. Do not send passwords, OTPs, or GCash MPINs. Read the privacy note for the rest.
        </p>
      </div>
      <InquiryForm />
    </div>
  );
}
