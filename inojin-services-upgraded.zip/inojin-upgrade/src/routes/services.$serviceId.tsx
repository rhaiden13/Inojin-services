import { createFileRoute, Link } from "@tanstack/react-router";
import { categoryById, findService, priceText, serviceGuideFor, services } from "@/lib/catalog";
import { site } from "@/lib/site";

export const Route = createFileRoute("/services/$serviceId")({
  head: ({ params }) => {
    const service = findService(params.serviceId);
    return {
      meta: [
        { title: service ? `${service.name} — ${site.name}` : `Service — ${site.name}` },
        { name: "description", content: service?.summary ?? "Service details" },
      ],
    };
  },
  component: ServicePage,
});

function ServicePage() {
  const { serviceId } = Route.useParams();
  const service = findService(serviceId);
  if (!service) {
    return (
      <div className="mx-auto w-full max-w-3xl px-5 py-16">
        <h1 className="font-display text-4xl text-ink">That service is not listed</h1>
        <p className="mt-3 text-ink-soft">The link may be old. The catalog is the current list.</p>
        <Link to="/services" search={{ category: "all", q: "", group: "all" }} className="mt-6 inline-flex min-h-11 items-center font-semibold text-teal-deep underline">
          Back to services
        </Link>
      </div>
    );
  }
  const category = categoryById(service.category);
  const related = services.filter((item) => item.category === service.category && item.id !== service.id).slice(0, 3);
  const guide = serviceGuideFor(service);

  return (
    <article className="mx-auto w-full max-w-3xl px-5 py-12">
      <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">
        <Link to="/services" search={{ category: service.category, q: "", group: "all" }} className="underline underline-offset-4">
          {category?.name}
        </Link>
        {service.group ? ` · ${service.group}` : ""}
      </p>
      <h1 className="mt-3 font-display text-4xl text-ink sm:text-5xl">{service.name}</h1>
      <p className="mt-4 text-lg text-ink-soft">{service.summary}</p>
      <p className="mt-6 border border-line bg-foam px-4 py-3 text-sm font-semibold text-ink">{priceText(service)}</p>
      <p className="mt-4 text-sm text-ink-soft">{site.copy.priceDepends}</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <section className="border border-line bg-paper-2 p-5">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">01 · What's included</p>
          <h2 className="mt-2 font-display text-2xl text-ink">Typical scope</h2>
          <p className="mt-2 text-sm text-ink-soft">The final checklist is confirmed before work begins.</p>
          <ul className="mt-4 space-y-3">
            {guide.includes.map((item) => (
              <li key={item} className="flex gap-2 text-sm text-ink">
                <span className="mt-1 size-1.5 shrink-0 rounded-full bg-teal" aria-hidden="true" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </section>
        <section className="border border-line bg-paper p-5">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">02 · Before we start</p>
          <h2 className="mt-2 font-display text-2xl text-ink">What to prepare</h2>
          <p className="mt-2 text-sm text-ink-soft">These details help us assess the request accurately.</p>
          <ul className="mt-4 space-y-3">
            {guide.prepare.map((item) => (
              <li key={item} className="flex gap-2 text-sm text-ink">
                <span className="mt-1 size-1.5 shrink-0 rounded-full bg-brass" aria-hidden="true" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </section>
        <section className="border border-line p-5 sm:col-span-2">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">03 · Expected result</p>
          <h2 className="mt-2 font-display text-2xl text-ink">What you can expect</h2>
          <p className="mt-2 text-ink-soft">{guide.delivery}</p>
          <div className="mt-5 border-l-2 border-brass pl-4">
            <p className="text-xs font-semibold uppercase tracking-widest text-ink-soft">Scope & limitations</p>
            <p className="mt-2 text-sm text-ink">{guide.scope}</p>
            {category ? <p className="mt-3 text-sm text-ink-soft">{category.disclaimer}</p> : null}
          </div>
        </section>
      </div>
      <div className="mt-8 flex flex-wrap gap-3">
        <Link to="/request" search={{ service: service.id }} className="inline-flex min-h-11 items-center bg-teal-deep px-5 font-semibold text-paper">
          Inquire about this
        </Link>
        <Link to="/services" search={{ category: service.category, q: "", group: service.group ?? "all" }} className="inline-flex min-h-11 items-center border border-ink px-5 font-semibold">
          More in this category
        </Link>
      </div>
      {related.length ? (
        <div className="mt-12 border-t border-line pt-8">
          <h2 className="font-display text-2xl text-ink">Nearby services</h2>
          <ul className="mt-4 space-y-3">
            {related.map((item) => (
              <li key={item.id}>
                <Link to="/services/$serviceId" params={{ serviceId: item.id }} className="font-semibold text-teal-deep underline underline-offset-4">
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </article>
  );
}
