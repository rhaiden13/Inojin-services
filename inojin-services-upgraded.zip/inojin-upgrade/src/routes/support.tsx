import { createFileRoute } from "@tanstack/react-router";
import { DonationPanel } from "@/components/site-shell";
import { site } from "@/lib/site";

export const Route = createFileRoute("/support")({
  head: () => ({
    meta: [
      { title: `Support Inojin Services — ${site.name}` },
      { name: "description", content: "Optional GCash support for Inojin Services. Not a payment for a service." },
    ],
  }),
  component: SupportPage,
});

function SupportPage() {
  return (
    <>
      <header className="border-b border-line">
        <div className="mx-auto w-full max-w-6xl px-5 py-12">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Support</p>
          <h1 className="mt-3 max-w-3xl font-display text-4xl text-ink sm:text-5xl">Support Inojin Services</h1>
          <p className="mt-4 max-w-2xl text-lg text-ink-soft">
            This page is only for voluntary gifts. It is not a checkout, and it is not how you pay for a design or a repair.
          </p>
        </div>
      </header>
      <DonationPanel />
    </>
  );
}
