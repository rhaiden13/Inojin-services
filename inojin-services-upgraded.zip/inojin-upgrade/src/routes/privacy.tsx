import { createFileRoute } from "@tanstack/react-router";
import { site } from "@/lib/site";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: `Privacy — ${site.name}` },
      { name: "description", content: "What Inojin Services does and does not collect on this website." },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <article className="mx-auto w-full max-w-3xl space-y-4 px-5 py-12 text-ink">
      <h1 className="font-display text-4xl sm:text-5xl">Privacy</h1>
      <p>
        Inojin Services uses this website to explain services and to help you prepare a message. The inquiry form runs in your browser. It does not save your name, number, or project notes on a server.
      </p>
      <p>
        When you choose to send, the message goes through your own SMS or email app to {site.phoneDisplay}
        {site.inquiryEmail ? ` or ${site.inquiryEmail}` : ""}. What happens after that is a normal message between you and the business.
      </p>
      <p>
        Do not put passwords, one-time codes, GCash MPINs, recovery codes, or card numbers in the form. The form blocks some of those words. It is not a place to hand over account access.
      </p>
      <p>
        Reference files you pick are not uploaded. Only the file names you select can be written into the message, and only on your device.
      </p>
      <p>
        Phone and GCash numbers on the page are business contact details, not a request for your private credentials. Donations are sent inside GCash by you. This site does not see them.
      </p>
      <p>
        The typefaces load from Google Fonts. That is a third-party request your browser makes when the page opens. Hosting and domain fees, if you later buy them for your own project, are charged by those companies, not hidden inside this page.
      </p>
      <p>
        Device and network help is only for equipment and networks you own or are allowed to administer. We do not want locks, passwords, or router admin secrets sent through the form.
      </p>
    </article>
  );
}
