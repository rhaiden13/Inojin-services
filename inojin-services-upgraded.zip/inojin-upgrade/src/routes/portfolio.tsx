import { createFileRoute } from "@tanstack/react-router";
import { PortfolioGallery } from "@/components/portfolio-gallery";
import { site } from "@/lib/site";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: `Portfolio — ${site.name}` },
      { name: "description", content: "Demonstration concepts and studio photographs. Not client work." },
    ],
  }),
  component: PortfolioPage,
});

function PortfolioPage() {
  return (
    <>
      <header className="border-b border-line">
        <div className="mx-auto w-full max-w-6xl px-5 py-12">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Gallery</p>
          <h1 className="mt-3 font-display text-4xl text-ink sm:text-5xl">Portfolio</h1>
          <p className="mt-4 max-w-2xl text-lg text-ink-soft">{site.copy.portfolioNote}</p>
          <p className="mt-3 max-w-2xl text-ink">
            These are demonstration concepts and studio photographs. They are not client projects, and they are not testimonials. Real jobs will be added only with permission.
          </p>
        </div>
      </header>
      <PortfolioGallery />
    </>
  );
}
