import { createFileRoute, Link } from "@tanstack/react-router";
import { site } from "@/lib/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: `About — ${site.name}` },
      { name: "description", content: site.tagline },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <article className="mx-auto w-full max-w-3xl px-5 py-12">
      <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">About</p>
      <h1 className="mt-3 font-display text-4xl text-ink sm:text-5xl">A small studio for practical digital work</h1>
      <p className="mt-5 text-lg text-ink-soft">{site.tagline}</p>
      <div className="mt-8 space-y-4 text-ink">
        <p>
          Inojin Services helps students, individuals, creators, and small businesses with phone and computer trouble, home networks, graphic design, and websites. The work is scoped in writing, then quoted, then done.
        </p>
        <p>
          This page does not list awards, years in business, or customer totals. Those claims are omitted until there is something real to say.
        </p>
        <p>{site.availability}</p>
      </div>
      <h2 className="mt-12 font-display text-3xl text-ink">What is working today</h2>
      <ul className="mt-4 list-disc space-y-2 pl-5 text-ink">
        <li>The service catalog, filters, and search.</li>
        <li>A portfolio of labeled demonstrations.</li>
        <li>An inquiry form that copies a message and opens your phone’s Messages app to {site.phoneDisplay}.</li>
        <li>Click-to-call, and copy buttons for the phone and GCash numbers.</li>
        <li>A voluntary GCash note for {site.gcash.accountName}, number {site.gcash.number}.</li>
      </ul>
      <h2 className="mt-12 font-display text-3xl text-ink">What still needs a real account or file</h2>
      <ul className="mt-4 list-disc space-y-2 pl-5 text-ink">
        <li>Facebook and Instagram buttons, until those profile URLs are pasted into the site settings.</li>
        <li>Official prices. Every service is labeled, but amounts are blank on purpose.</li>
        <li>An email inbox, if you want inquiries to open mail instead of SMS.</li>
        <li>Stored inquiries, file uploads, and an admin screen. Those need a database and sign-in. They are not pretended here.</li>
        <li>A GCash QR or payment link, only after you supply the real image or URL.</li>
        <li>Client projects and permitted testimonials.</li>
        <li>Service payments. Donations and invoices stay separate, and this site does not take card payments.</li>
      </ul>
      <p className="mt-8 text-ink-soft">
        Edit names, numbers, URLs, and the public sentences in the site configuration. Service names and summaries live beside the catalog.
      </p>
      <Link to="/contact" className="mt-8 inline-flex min-h-11 items-center font-semibold text-teal-deep underline underline-offset-4">
        Contact Inojin Services
      </Link>
    </article>
  );
}
