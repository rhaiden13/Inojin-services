import { z } from "zod";
import { findService, categoryById } from "@/lib/catalog";
import { site } from "@/lib/site";

export const contactMethods = [
  { id: "phone", label: "Phone call or text" },
  { id: "facebook", label: "Facebook" },
  { id: "instagram", label: "Instagram" },
  { id: "email", label: "Email" },
] as const;

export const meetingOptions = [
  { id: "remote", label: "Remote" },
  { id: "in-person", label: "In person" },
  { id: "either", label: "Either is fine" },
  { id: "not-applicable", label: "Not applicable" },
] as const;

export const budgetOptions = [
  "Prefer not to say",
  "I will decide after the quotation",
  "Student or modest budget",
  "A standard one-time project",
  "A larger or ongoing project",
] as const;

const secretPattern =
  /\b(passwords?|passcodes?|otp|one[-\s]?time|mpin|pin\s*code|recovery\s*codes?|cvv|seed\s*phrase)\b/i;

export const inquirySchema = z
  .object({
    fullName: z.string().trim().min(2, "Enter your name.").max(80, "Use a shorter name."),
    contactMethod: z.enum(["phone", "facebook", "instagram", "email"]),
    contactDetails: z.string().trim().min(5, "Enter a way for us to reply.").max(120),
    category: z.string().min(1, "Choose a category."),
    serviceId: z.string().min(1, "Choose a service."),
    projectType: z.string().trim().min(2, "Name the device or the project.").max(140),
    description: z
      .string()
      .trim()
      .min(20, "Describe the request in at least a sentence.")
      .max(2000, "Shorten the description to 2000 characters."),
    budget: z.string().max(80).optional(),
    schedule: z.string().trim().min(2, "Share a preferred schedule.").max(140),
    meeting: z.enum(["remote", "in-person", "either", "not-applicable"]),
    instructions: z.string().max(1000, "Shorten the extra notes.").optional(),
    consent: z.boolean(),
    website: z.string(),
  })
  .superRefine((value, ctx) => {
    if (value.website.trim() !== "") {
      ctx.addIssue({ code: "custom", message: "The form could not be prepared.", path: ["website"] });
    }
    if (!value.consent) {
      ctx.addIssue({
        code: "custom",
        message: "Consent is required before the message is prepared.",
        path: ["consent"],
      });
    }
    if (!categoryById(value.category)) {
      ctx.addIssue({ code: "custom", message: "Choose a category from the list.", path: ["category"] });
    }
    const service = findService(value.serviceId);
    if (!service || service.category !== value.category) {
      ctx.addIssue({ code: "custom", message: "Choose a service in that category.", path: ["serviceId"] });
    }
    const blob = `${value.description}\n${value.instructions ?? ""}\n${value.contactDetails}`;
    if (secretPattern.test(blob)) {
      ctx.addIssue({
        code: "custom",
        message: "Remove passwords, OTPs, MPINs, and recovery codes. We will never ask for them.",
        path: ["description"],
      });
    }
    if (value.contactMethod === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.contactDetails)) {
      ctx.addIssue({ code: "custom", message: "Enter a valid email address.", path: ["contactDetails"] });
    }
    if (value.contactMethod === "phone" && value.contactDetails.replace(/\D/g, "").length < 10) {
      ctx.addIssue({ code: "custom", message: "Enter a phone number with at least 10 digits.", path: ["contactDetails"] });
    }
  });

export type InquiryInput = z.infer<typeof inquirySchema>;

export function formatInquiry(input: InquiryInput, fileNames: string[]) {
  const service = findService(input.serviceId);
  const category = categoryById(input.category);
  const method = contactMethods.find((item) => item.id === input.contactMethod)?.label ?? input.contactMethod;
  const meeting = meetingOptions.find((item) => item.id === input.meeting)?.label ?? input.meeting;
  const lines = [
    "Inojin Services — service inquiry",
    "",
    `Name: ${input.fullName}`,
    `Preferred contact: ${method}`,
    `Contact details: ${input.contactDetails}`,
    `Category: ${category?.name ?? input.category}`,
    `Service: ${service?.name ?? input.serviceId}`,
    `Device or project: ${input.projectType}`,
    `Preferred schedule: ${input.schedule}`,
    `Remote or in person: ${meeting}`,
    `Budget note: ${input.budget?.trim() || "Not specified"}`,
    "",
    "Description:",
    input.description.trim(),
    "",
    "Additional instructions:",
    input.instructions?.trim() || "None",
    "",
    "Reference files to send separately:",
    fileNames.length ? fileNames.join(", ") : "None named",
    "",
    "I agree that these details may be used only to reply about this inquiry.",
    "This message was prepared on the Inojin Services website. The site does not store it.",
  ];
  return lines.join("\n");
}

export function smsHref(body: string) {
  const limit = 700;
  const text = body.length > limit ? `${body.slice(0, limit)}\n\n(Message shortened. Paste the full copied inquiry.)` : body;
  return `sms:${site.phoneTel}?body=${encodeURIComponent(text)}`;
}

export function mailtoHref(body: string, subject: string) {
  return `mailto:${site.inquiryEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
