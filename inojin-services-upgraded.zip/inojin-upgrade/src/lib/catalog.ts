export type PriceKind = "fixed" | "starting" | "quote" | "assessment";

export type CategoryId =
  | "phone"
  | "computer"
  | "network"
  | "design"
  | "web"
  | "business"
  | "video"
  | "products"
  | "tools"
  | "learning";

export type Service = {
  id: string;
  category: CategoryId;
  group?: string;
  name: string;
  summary: string;
  priceKind: PriceKind;
  /** Official amount. Null until you publish a real price. */
  priceAmount: string | null;
  notes?: string;
};

export type Category = {
  id: CategoryId;
  name: string;
  eyebrow: string;
  blurb: string;
  disclaimer: string;
};

const KIND: Record<PriceKind, string> = {
  fixed: "Fixed Price",
  starting: "Starting At",
  quote: "Custom Quotation",
  assessment: "Assessment Required",
};

export function priceKindLabel(kind: PriceKind) {
  return KIND[kind];
}

export function priceText(service: Service) {
  const kind = KIND[service.priceKind];
  if (service.priceAmount) return `${kind}: ${service.priceAmount}`;
  return `${kind}. Official price not published yet — request a quotation.`;
}

export const categories: Category[] = [
  {
    id: "phone",
    name: "Phone & Mobile",
    eyebrow: "Devices",
    blurb:
      "Diagnostics, setup, backups, and everyday phone problems. Recovery stays on official methods.",
    disclaimer:
      "Screen-lock and account recovery use the manufacturer or provider’s own steps, and only with proof that you own the device or have permission. We do not bypass locks and we do not guarantee access.",
  },
  {
    id: "computer",
    name: "Computers & Laptops",
    eyebrow: "Desk",
    blurb:
      "Windows help, setup, slow machines, and software that will not start. Physical repair is a separate question.",
    disclaimer:
      "This is software troubleshooting and setup, not a promise of physical repair. Reformatting and system installs can erase files, so we back up first when the disk still allows it. Data recovery and hardware faults are assessments only — not every file or part can be saved or fixed. Some jobs need the computer in front of us, or an authorized technician.",
  },
  {
    id: "network",
    name: "Wi-Fi & Networks",
    eyebrow: "Connection",
    blurb:
      "Home and small-shop networks you own or are allowed to administer.",
    disclaimer:
      "Password recovery and router changes are only for networks the client owns or is authorized to administer. We do not try to enter someone else’s network.",
  },
  {
    id: "design",
    name: "Graphic Design",
    eyebrow: "Studio",
    blurb:
      "Presentations, print, social posts, brand boards, and documents. Tell us the size, colors, audience, and deadline.",
    disclaimer:
      "Demonstration concepts in the gallery are not client work. A design job can include dimensions, colors, audience, platform, deadline, reference images you have rights to, and the deliverables you need. Revisions are agreed in the quotation.",
  },
  {
    id: "web",
    name: "Websites",
    eyebrow: "Web",
    blurb:
      "Portfolios, small business sites, landing pages, and focused web projects for students, creators, and shops.",
    disclaimer:
      "A page you can open in a browser is not the same as a hosted app with accounts, a database, or card payments. If a request needs those, the quotation says so. Domain, hosting, and third-party fees are paid by you to those providers.",
  },
  {
    id: "business",
    name: "Business Solutions",
    eyebrow: "Shops",
    blurb:
      "A practical digital presence: profile, menu, deck, catalog, and a site that can take inquiries.",
    disclaimer:
      "Packages can combine design and a website in one quotation. We do not invent sales results or claim a package will guarantee customers.",
  },
  {
    id: "video",
    name: "Video & Multimedia",
    eyebrow: "Motion",
    blurb:
      "Short edits, captions, thumbnails, and simple motion. Longer films are quoted after we see the footage.",
    disclaimer:
      "We can edit material you own or have permission to use. Advanced motion, licensed music, and long-form films are marked for assessment when the scope is not clear yet.",
  },
  {
    id: "products",
    name: "Digital Products",
    eyebrow: "Files",
    blurb:
      "Templates and starter files you can reuse: decks, planners, resumes, and simple HTML starts.",
    disclaimer:
      "Template packs are starting-price items once an official amount is published. A custom version is quoted separately. Files are delivered after the scope is approved.",
  },
  {
    id: "tools",
    name: "Productivity & Tools",
    eyebrow: "Systems",
    blurb:
      "Spreadsheets, checklists, simple calculators, and file organization for real daily use.",
    disclaimer:
      "Calculators and sheets are tools, not financial, legal, or medical advice. Automation that touches private accounts is assessed before any build.",
  },
  {
    id: "learning",
    name: "Technical Learning",
    eyebrow: "Lessons",
    blurb:
      "Beginner help with HTML, CSS, JavaScript, software setup, and how a small website fits together.",
    disclaimer:
      "Sessions are tutoring and setup help, not a certified course and not a promise of a grade or a job.",
  },
];

type Row = [string, string, PriceKind, string?];

function slug(value: string) {
  return value
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function add(category: CategoryId, group: string | undefined, rows: Row[]): Service[] {
  return rows.map(([name, summary, priceKind, notes]) => ({
    id: slug(`${category}-${name}`),
    category,
    group,
    name,
    summary,
    priceKind,
    priceAmount: null,
    notes,
  }));
}

const ownDevice =
  "Official recovery only, with proof of ownership or permission. No lock bypass, and no promise that access will be restored.";

const hardware =
  "This can turn out to be a physical fault. We will say if an in-person inspection or another technician is the honest next step.";

const noGuarantee = "Assessment only. We cannot promise the files or the repair.";

export const services: Service[] = [
  ...add("phone", "Support", [
    ["Phone Diagnostics and Troubleshooting", "We reproduce the problem where we can, then suggest the next practical step before anything is erased.", "assessment"],
    ["Forgotten Screen Lock Recovery Guidance", "A walkthrough of the official lock recovery for a phone you own.", "assessment", ownDevice],
    ["Official Phone Account Recovery Assistance", "Help using the account provider’s own recovery, not a shortcut around it.", "assessment", ownDevice],
    ["Phone Security and Privacy Checkups", "A calm pass over lock screen, accounts, and privacy choices you decide to change.", "assessment"],
    ["Suspicious Application and Permission Reviews", "We look at installed apps and permissions and explain which ones deserve a closer look.", "assessment"],
    ["App Installation and Configuration", "Install an app you are allowed to use and check that it opens and signs in with you present.", "quote"],
    ["Phone Setup and Personalization", "A new or freshly reset phone, arranged around how you actually use it.", "quote"],
    ["Storage Management and Performance Optimization", "See what is using space and apply safe cleanups you approve.", "assessment"],
    ["Software and Operating System Updates", "Check for an official system or app update and install it when the phone and connection allow.", "assessment"],
    ["Application Errors and Crash Troubleshooting", "Catch the crash, try the usual fixes, and stop before a reset if the data matters.", "assessment"],
    ["Contact and File Backup Assistance", "Copy contacts and files to a place you control and can open again.", "quote"],
    ["Photo and Video Backup Guidance", "Set up a backup you understand. Your gallery stays yours.", "quote"],
    ["Device-to-Device Data Transfer", "Move data between two devices when both are present and you unlock them.", "quote"],
    ["Wi-Fi and Mobile Data Troubleshooting", "Separate a phone setting from a router or SIM problem.", "assessment"],
    ["Notification and Permission Fixes", "Restore missing alerts or quiet the ones you do not want.", "assessment"],
    ["Battery Usage Assessment", "See which apps draw power. This is not a battery replacement.", "assessment", hardware],
    ["Factory Reset Guidance", "What a reset erases, and how to do it only after a backup you can verify.", "assessment"],
    ["Post-Reset Device Setup", "Accounts you can sign in to, essential apps, and the settings you still remember needing.", "quote"],
    ["Email Account Setup Assistance", "Add mail with the provider’s official settings.", "quote"],
    ["Bluetooth and Accessory Troubleshooting", "Pair headphones, watches, speakers, or other accessories you own.", "assessment", hardware],
    ["Mobile Browser Troubleshooting", "Unstick a browser, a site, or a download without wiping the phone first.", "assessment"],
    ["Phone Privacy Settings Review", "Walk the privacy screens and explain what each choice actually does.", "assessment"],
    ["Device Compatibility Assessment", "Check whether an app, cable, accessory, or file type fits this phone.", "assessment"],
    ["App Configuration and Data Organization", "Arrange app settings and on-phone files so they are easier to find.", "quote"],
    ["General Mobile Technology Support", "A practical session for a phone question that does not fit a narrower service.", "assessment"],
  ]),
  ...add("computer", "Support", [
    ["Computer and Laptop Diagnostics", "Find whether the trouble is software, settings, or something that looks physical.", "assessment", hardware],
    ["Windows Troubleshooting", "Everyday Windows faults: updates stuck, settings wrong, features missing.", "assessment"],
    ["Forgotten Password Recovery Guidance", "Official ways to regain a Windows or account sign-in you own.", "assessment", ownDevice],
    ["Official Account Recovery Assistance", "Microsoft, Google, or similar recovery using that company’s own flow.", "assessment", ownDevice],
    ["Operating System Installation Assistance", "Install or reinstall an operating system you are licensed to use, after a backup plan.", "assessment", "Installation can erase the disk. We confirm that with you first."],
    ["Computer Reformatting and Reinstallation", "A clean start when you have decided the current setup should be replaced.", "assessment", "Reformatting removes programs and files. Back up anything you still need."],
    ["Software Installation and Configuration", "Install software you own or that is free to use, then set the options you need.", "quote"],
    ["Driver Installation and Troubleshooting", "Official drivers for a device the computer should already support.", "assessment", hardware],
    ["Software and System Updates", "Apply updates that are actually offered for this machine.", "assessment"],
    ["Startup and Boot Error Diagnosis", "Read the startup failure and separate a setting issue from a disk or hardware fault.", "assessment", hardware],
    ["Blue Screen and System Error Troubleshooting", "Collect the error and try the safe software fixes. Not every stop code is repairable in software.", "assessment", noGuarantee],
    ["Slow PC Performance Assessment", "See startup apps, disk space, and settings that make a computer feel tired.", "assessment"],
    ["Storage Cleanup and File Organization", "Clear space you approve and put folders where you can find them.", "quote"],
    ["Application Crash and Compatibility Fixes", "An app that closes or refuses to run on this version of the system.", "assessment"],
    ["Basic Malware and Suspicious Software Checks", "A first look for unwanted programs. This is not a certified incident response.", "assessment", "If the machine holds sensitive work or the infection looks serious, we will say so."],
    ["Computer Security and Privacy Reviews", "Accounts, updates, browser, and sharing settings, changed only with you.", "assessment"],
    ["Browser Errors and Configuration", "Homepage, extensions, downloads, and sites that misbehave.", "assessment"],
    ["Printer and Peripheral Setup", "Install a printer, scanner, or similar device you own, on a computer or a network you administer.", "assessment", hardware],
    ["Data Backup and Migration Assistance", "Copy files to a drive or computer you control, and check that a sample opens.", "quote"],
    ["Local File Recovery Assessment", "See whether deleted or missing files still have a reasonable chance of return.", "assessment", noGuarantee],
    ["PC Setup and Personalization", "A new or reset computer: accounts, browser, and the programs you use.", "quote"],
    ["Basic Hardware Issue Assessment", "Ports, power, display, heat, or noise — enough to tell software from hardware.", "assessment", hardware],
    ["Keyboard, Mouse, and Accessory Troubleshooting", "Input devices that skip, disconnect, or type the wrong thing.", "assessment", hardware],
    ["Coding Environment Setup", "Install a beginner-friendly editor, language, and the tools a school or project named.", "quote"],
    ["Developer Tool Installation", "Git, a browser, runtimes, and similar tools, pinned to versions your project needs.", "quote"],
    ["Software Configuration and Maintenance", "A return visit to fix settings that drifted or to install an update you want.", "quote"],
    ["Video Conferencing Setup", "Camera, microphone, and a Zoom, Meet, or Teams check before a class or meeting.", "quote"],
    ["Email Client Configuration", "Desktop or web mail with the correct official server settings.", "quote"],
    ["External Drive Setup", "Format or organize a drive you own, after we explain what formatting erases.", "assessment"],
    ["General Computer Technical Support", "A session for a computer question that does not match a single service above.", "assessment"],
  ]),
  ...add("network", "Networks", [
    ["Wi-Fi Connection Troubleshooting", "Why a device associates, drops, or never joins a network you administer.", "assessment"],
    ["Forgotten Wi-Fi Password Recovery Guidance", "Official ways to view or replace a password for a network you own.", "assessment", "Only for a network you own or are authorized to administer."],
    ["Router Setup and Configuration", "First setup of a router you own: name, password, and a connection that actually passes traffic.", "quote"],
    ["Router Password Change Assistance", "Change the Wi-Fi or admin password and write down where you stored it. We never keep it.", "quote"],
    ["Slow Internet Troubleshooting", "Separate a busy Wi-Fi, a weak spot, and a line that is slow before it reaches the router.", "assessment"],
    ["Internet Connectivity Diagnosis", "No connection at all: modem, router, cables, and the device in your hand.", "assessment"],
    ["Wi-Fi Signal and Coverage Assessment", "Where the signal falls off in a home or a small shop, and simple placement changes.", "assessment"],
    ["Device Connection Troubleshooting", "One phone, laptop, or TV that will not stay on a network the others can use.", "assessment"],
    ["DNS and Basic Network Configuration", "Straightforward DNS or adapter settings when a site fails and the rest of the network is fine.", "assessment"],
    ["Router Firmware Update Guidance", "Install an official firmware update from the router maker, when one is offered.", "assessment"],
    ["Home Network Security Checkups", "Admin password, Wi-Fi password, encryption, and remote-admin settings left open by mistake.", "assessment"],
    ["Connected Device Reviews", "A list of what is on the network, so you can remove what you do not recognize.", "assessment"],
    ["Guest Network Setup Guidance", "A separate guest name for visitors, if the router supports it.", "quote"],
    ["Home Wi-Fi Optimization", "Channel, band, and placement changes that are realistic for the router you already have.", "assessment"],
    ["Basic LAN Configuration", "A small wired setup: router to switch to the computers that need a cable.", "assessment"],
    ["Network Setup for Small Businesses", "A simple shop network for till, printer, and staff phones. Larger builds are quoted after a look.", "quote"],
    ["Router Placement Recommendations", "Where to put the router you own, without selling you equipment you may not need.", "assessment"],
    ["Printer Network Troubleshooting", "A printer that used to be on the Wi-Fi and now is not.", "assessment", hardware],
    ["Internet Setup and Configuration", "New line or new modem: get the first devices online and the Wi-Fi named properly.", "quote"],
    ["Secure Wi-Fi Configuration Advice", "Encryption, a non-default password, and admin access that is not left on factory settings.", "assessment"],
    ["Basic Hotspot Configuration", "Phone hotspot or a small travel router, for a use you describe.", "assessment"],
    ["Network Device Compatibility Checks", "Whether a device can join the kind of Wi-Fi the router offers.", "assessment"],
    ["Connectivity Troubleshooting for Online Classes", "Camera, bandwidth, and a connection stable enough for a class period.", "assessment"],
    ["Remote Network Troubleshooting Guidance", "Help over chat or a call when we cannot stand next to the router. Some faults still need someone on site.", "assessment"],
  ]),
  ...add("design", "Presentations", [
    ["PowerPoint Design", "A deck with a clear order, readable type, and slides that match the talk you are actually giving.", "quote"],
    ["School Presentation Design", "Class reports and group slides, laid out so the teacher can follow the point.", "quote"],
    ["Research Presentation Layouts", "Findings, citations, and figures with room to breathe. We do not invent data.", "quote"],
    ["Business Presentation Decks", "A pitch or internal deck from notes you provide.", "quote"],
    ["Project Defense Presentation Layouts", "Defense or final-defense slides structured around the panel’s questions.", "quote"],
    ["Educational Infographics", "One topic, one page, explained in an order a student can scan.", "quote"],
    ["Learning Materials", "Handouts and visual explainers for a lesson you outline.", "quote"],
    ["Study Guides and Reviewer Layouts", "Reviewers that are easy to print or read on a phone.", "quote"],
    ["Lesson Presentation Templates", "A reusable school or training deck you can duplicate.", "starting"],
    ["Certificates and Recognition Designs", "Certificates with the names and wording you supply.", "quote"],
  ]),
  ...add("design", "Print", [
    ["Pubmat Design", "A publication material sized for the feed or the wall you name.", "quote"],
    ["Tarpaulin and Banner Design", "Large-format artwork with the printer’s size and bleed. Printing is a third-party cost.", "quote"],
    ["Advertisement Posters", "A poster with one offer, one date, and type that still reads across a room.", "quote"],
    ["Business Flyers", "A single sheet for a shop, event, or service.", "quote"],
    ["Brochures", "A folded piece with a front, an inside story, and a way to contact you.", "quote"],
    ["Event Posters", "Time, place, and what the event is, before decoration.", "quote"],
    ["Digital Invitations", "An invitation sized for chat or stories.", "quote"],
    ["Business Cards", "A card with the details you want public. We do not add private account numbers unless you ask.", "quote"],
    ["Product Price Lists", "A clean list from prices you provide. We do not invent discounts.", "quote"],
    ["Service Menus", "Services and how to inquire, without fake ‘limited time’ claims.", "quote"],
    ["Restaurant Menu Design", "A menu guests can read. Food photos only if you have rights to them.", "quote"],
    ["Product Catalogs", "A catalog or lookbook from your real products.", "quote"],
    ["Promotional Banners", "Web or print banners at the pixel or centimeter size you need.", "quote"],
    ["Event and Community Materials", "Programs, signage, and neighbor-scale announcements.", "quote"],
  ]),
  ...add("design", "Social", [
    ["Facebook Promotional Graphics", "Feed graphics sized for Facebook, with copy you approve.", "quote"],
    ["Instagram Posts and Stories", "Square posts and vertical stories for a campaign or a single announcement.", "quote"],
    ["Social Media Cover Photos", "Cover and channel art that still works when the screen crops it.", "quote"],
    ["Product Advertisement Pictures", "A product frame from photos you supply or from a simple studio setup we agree.", "quote"],
    ["Product Launch Graphics", "A small set for announcing something you are actually releasing.", "quote"],
    ["YouTube Thumbnails", "A thumbnail that stays readable at small size.", "quote"],
    ["Creator Branding Graphics", "A consistent frame for a creator who is not ready for a full identity system.", "quote"],
    ["Promotional Campaign Creatives", "A related set, not one isolated poster.", "quote"],
    ["Digital Marketing Materials", "Images for a specific offer, audience, and platform.", "quote"],
    ["Sale and Discount Posters", "Only for a discount you confirm. We do not draw fake countdown pressure.", "quote"],
    ["Content Calendar Templates", "A calendar you can fill. We do not pretend to schedule posts to your accounts.", "starting"],
    ["Profile and Channel Graphics", "Profile mark, banner, and a short visual note so the page looks settled.", "quote"],
  ]),
  ...add("design", "Brand", [
    ["Logo Concepts", "A small set of logo directions, delivered as files you can actually use. Not a trademark search.", "quote"],
    ["Color Palette and Typography Selection", "Colors and type chosen for print and screen, written down so the next piece matches.", "quote"],
    ["Brand Identity Boards", "A board that shows mark, color, and type together.", "quote"],
    ["Basic Brand Guidelines", "A short guide: clear space, misuse, and the files to hand a printer.", "quote"],
    ["Business Visual Identity", "The look of a small business across card, social, and a simple cover.", "quote"],
    ["Product Label Concepts", "A label sized for the package you describe. Printing is separate.", "quote"],
    ["Packaging Mockups", "A visual mockup. This is not manufacturing or a dieline unless we agree one.", "quote"],
    ["Brand Presentation Decks", "A deck that explains the identity to a partner or a printer.", "quote"],
    ["Personal Branding Materials", "A personal set for a student, freelancer, or creator.", "quote"],
  ]),
  ...add("design", "Documents", [
    ["Resume and CV Layouts", "A resume designed from your real history. We do not invent jobs or skills.", "quote"],
    ["Portfolio Layouts", "A PDF or slide portfolio of work you have the right to show.", "quote"],
    ["E-book Design", "Interior and cover for a manuscript you provide.", "quote"],
    ["PDF Formatting", "A long document made consistent: headings, margins, page numbers.", "quote"],
    ["Digital Workbooks", "Exercises and write-in space for a class or a workshop.", "quote"],
    ["Printable Planners", "Pages you can print at home: weeks, lists, or trackers you describe.", "starting"],
    ["Digital Catalogs", "A flip-friendly PDF catalog.", "quote"],
    ["Professional Reports", "A report layout. The findings stay yours — we do not write false results.", "quote"],
    ["Guides and Manuals", "Step-by-step guides with figures that match the real product.", "quote"],
    ["Document Cover Design", "A cover for a thesis, report, or booklet.", "quote"],
  ]),
  ...add("web", "Sites", [
    ["Personal Portfolio Websites", "A small site for your work, fast on a phone, with a way to contact you.", "quote"],
    ["Business Websites", "Pages for what you offer, where you are, and how to inquire. Not an online store unless scoped.", "quote"],
    ["Freelancer Websites", "Services, selected work, and a request form or contact path.", "quote"],
    ["Student Portfolio Websites", "School and personal work, labeled honestly, for applications or defense.", "quote"],
    ["School Project Websites", "A project site that matches the brief your class actually gave.", "quote"],
    ["Educational Websites", "Lessons or a school presence as pages. Student accounts are a larger build.", "quote", "A content site. Accounts, grades, and a full classroom need a separate scope."],
    ["Digital Services Websites", "A service list and inquiry path, similar in purpose to this one, built around your offers.", "quote"],
    ["Product Showcase Websites", "Products with photos and details. Checkout is not included unless a payment provider is scoped.", "quote", "Showcase only, unless payment integration is quoted separately."],
    ["Landing Pages", "One page, one action: call, message, or a request.", "quote"],
    ["Personal Profile Websites", "A simple personal page: who you are and how to reach you.", "quote"],
    ["Interactive Resume Websites", "A resume you can click through. Content comes from you.", "quote"],
    ["Online Event Invitation Websites", "Date, place, and a note. Not ticket sales unless scoped.", "quote"],
    ["Relationship Goals and Memory Websites", "A shared page for a story you want to tell.", "quote", "This is a page people can open. Private accounts are extra."],
    ["Family Memories Websites", "Photos and stories your family has rights to share.", "quote", "Private galleries need hosting and access rules, quoted separately."],
    ["Restaurant Menu Websites", "A menu that is easy to update in the files. Ordering and payments are extra.", "quote"],
    ["Product Catalog Websites", "A catalog to browse. Stock counts and checkout are a different project.", "quote"],
    ["Booking and Inquiry Websites", "A request a visitor can send. Live calendar booking and card payments are not assumed.", "quote", "Inquiry first. A connected booking system needs a provider and a backend."],
    ["Creator and Content Portfolio Websites", "A home for videos, posts, or writing, with links you control.", "quote"],
    ["Website Redesign", "A clearer structure and look for a site you already have.", "quote"],
    ["Mobile-Friendly Website Improvements", "Fix overflow, tiny tap targets, and type that is hard to read on a phone.", "quote"],
    ["HTML, CSS, and JavaScript Projects", "A front-end project for school or for yourself, explained so you can present it.", "quote"],
    ["Frontend Interface Development", "The screens and interactions. Data storage and sign-in are named separately if you need them.", "quote", "Interface only, unless a backend is part of the written scope."],
    ["Interactive Browser-Based Tools", "A small tool that runs in the browser: a calculator, a planner, a checker.", "quote"],
    ["Simple Browser Games", "A small game with a clear rule. Not a multiplayer live service unless scoped.", "quote"],
    ["Dashboard Interface Prototypes", "A clickable picture of a dashboard. Live data is not included unless we say it is.", "assessment", "Prototype. Not a connected admin system by default."],
    ["Website Bug Fixes", "A specific bug on a site we can access with your permission.", "assessment"],
    ["Content and Layout Improvements", "Rewrite placement, headings, and sections so the page says what you mean.", "quote"],
    ["Website Maintenance", "Small updates after launch, quoted per visit or as a short retainer once we know the site.", "quote"],
    ["Basic Search Engine Optimization", "Titles, descriptions, headings, and speed basics. No promise of a ranking.", "assessment"],
    ["Website Performance Improvements", "Images, scripts, and layout choices that make a page feel late.", "assessment"],
    ["Domain and Hosting Setup Guidance", "Help on an account you own. You pay the registrar and the host directly.", "assessment", "We do not take ownership of your domain."],
    ["Custom Interactive Web Projects", "Something that does not fit the list, scoped in writing before build.", "quote"],
    ["Online Learning Platform Prototypes", "Screens for a lesson flow. Not a finished school platform with accounts.", "assessment", "Prototype only, unless hosting, accounts, and storage are quoted."],
    ["Digital Product Showcase Pages", "A page that presents a template or download you sell or give away.", "quote"],
    ["QR Code Landing Pages", "A short page a QR code can open: contact, menu, or event.", "quote"],
    ["Small Business Online Presence Setup", "The minimum useful set: a page, a contact path, and graphics that match.", "quote"],
  ]),
  ...add("business", "Presence", [
    ["Business Branding Packages", "Mark, colors, and a few pieces that match, scoped as one project.", "quote"],
    ["Business Profile Design", "A profile image set for the networks you actually use.", "quote"],
    ["Digital Service Menus", "What you offer and how to ask, in a file or a page.", "quote"],
    ["Business Presentation Decks", "A deck for a partner, a lender, or a customer meeting.", "quote"],
    ["Social Media Content Packages", "A defined number of graphics, not an endless posting contract.", "quote"],
    ["Digital Product Catalogs", "Products, variants, and prices you confirm.", "quote"],
    ["Promotional Campaign Materials", "One campaign, one message, several sizes.", "quote"],
    ["Product Advertisement Sets", "A matched set for a product you are ready to show.", "quote"],
    ["Online Portfolio Setup", "Where the work lives and how a visitor writes to you.", "quote"],
    ["Inquiry and Contact Page Setup", "A contact path that tells the truth about how you reply.", "quote"],
    ["Small Business Website Development", "A compact site for a shop, tutor, or independent service.", "quote"],
    ["Digital Workflow Planning", "A written map of how an inquiry becomes a finished file. Not software unless scoped.", "assessment"],
    ["Online Presence Improvements", "What to fix first on the page and profiles you already have.", "assessment"],
    ["Product Launch Visuals", "The pictures and the page for a launch date you choose.", "quote"],
    ["Custom Digital Project Consultation", "A paid or quoted conversation to decide scope before design starts.", "assessment"],
    ["QR Code Contact Pages", "One QR, one page, the details you want public.", "quote"],
    ["Digital Brochure Creation", "A brochure PDF a customer can download.", "quote"],
    ["Basic Content Organization", "Headings and folders so your existing text is easier to publish.", "quote"],
    ["Business Information Page Setup", "Hours, service area, and contact, only with facts you provide.", "quote"],
    ["Digital Proposal and Pitch Deck Design", "A proposal that states scope, not imaginary guarantees.", "quote"],
  ]),
  ...add("video", "Video", [
    ["Short Promotional Video Editing", "A short cut from footage you provide and have rights to use.", "quote"],
    ["Social Media Video Layouts", "Captions, crop, and a cover frame for Reels, Stories, or a short post.", "quote"],
    ["YouTube Intro and Outro Concepts", "A short open and close. Longer channel packages are quoted after a sample.", "quote"],
    ["Basic Motion Graphics", "Simple moving type and shapes. Complex animation is assessed first.", "assessment"],
    ["Animated Presentation Elements", "A few motions inside a deck, not a full cartoon.", "quote"],
    ["Video Thumbnail Design", "A still thumbnail. Listed here when it belongs to a video, not only a poster.", "quote"],
    ["Simple Product Showcase Videos", "A short product clip from footage or photos you supply.", "quote"],
    ["Video Captions and Subtitle Formatting", "Captions timed to speech you provide. We do not invent a transcript of audio we cannot hear.", "quote"],
  ]),
  ...add("products", "Templates", [
    ["Presentation Templates", "A deck shell you can duplicate for class or work.", "starting"],
    ["Social Media Template Packs", "A set of editable post sizes.", "starting"],
    ["Website Template Designs", "A visual starting point. Connecting a database is not included.", "starting"],
    ["Digital Planners", "Undated or dated pages, as agreed.", "starting"],
    ["Budget Tracking Templates", "A spreadsheet for personal tracking. Not financial advice.", "starting"],
    ["Personal Productivity Templates", "Lists and weekly pages for your own use.", "starting"],
    ["Printable Worksheets", "Exercises for a subject you specify.", "starting"],
    ["Study and Reviewer Templates", "A reviewer structure students can fill.", "starting"],
    ["Digital Invitation Templates", "An invitation file you can edit with your event details.", "starting"],
    ["Resume Templates", "A layout. The career history has to be yours.", "starting"],
    ["Business Document Templates", "Letter, quotation, or simple proposal shells.", "starting"],
    ["Simple HTML Starter Templates", "A small HTML and CSS start for learning or a school hand-in.", "starting"],
    ["Beginner Coding Resources", "Notes and tiny examples we are willing to maintain. Not a full course.", "starting"],
    ["Downloadable Design Assets", "Patterns, frames, or marks made for reuse, with a note on how you may use them.", "starting"],
    ["Custom Digital Product Concepts", "A product idea scoped before any files are made.", "assessment"],
  ]),
  ...add("tools", "Tools", [
    ["Spreadsheet Design and Formatting", "A sheet that calculates what you describe, with labels a stranger could follow.", "quote"],
    ["Basic Budget Calculators", "A calculator for a budget you define. Not a forecast of your income.", "quote"],
    ["Online Forms and Checklists", "A form or checklist. Permanent storage needs an inbox or a database, which we will name if it is missing.", "quote"],
    ["Simple Web Calculators", "A browser calculator for one job: fees, sizes, or a class formula you provide.", "quote"],
    ["Digital Recordkeeping Templates", "A table for records you decide to keep. Not a legal archive.", "quote"],
    ["Interactive Information Tools", "A small explainer someone can click through.", "quote"],
    ["Basic Data Organization", "Sort and label a spreadsheet or folder of files you are allowed to share.", "assessment"],
    ["PDF and Document Formatting", "Consistent styles in a document that already has the words.", "quote"],
    ["File Organization Guidance", "A folder plan for a computer or drive, applied with you.", "assessment"],
    ["Basic Automation Prototypes", "A small script or macro. Anything that logs into accounts is assessed and may be declined.", "assessment"],
    ["Website Content Migration Assistance", "Move text and images you own from an old page to a new one.", "quote"],
    ["Simple QR Code Generation", "A QR code that points at a real URL you control.", "quote"],
    ["Web-Based Project Prototypes", "A prototype in the browser so you can react before a larger build.", "assessment"],
  ]),
  ...add("learning", "Learning", [
    ["Basic Coding Assistance", "Help on a beginner exercise. We will not quietly do a graded exam for you.", "assessment", "We help you understand the work. We do not take tests in your place."],
    ["HTML and CSS Learning Projects", "A page you build, with review of structure and layout.", "quote"],
    ["Beginner JavaScript Projects", "A small interactive page and an explanation of the parts you wrote.", "quote"],
    ["Website Troubleshooting Tutorials", "A guided look at a broken page so you can fix the next one.", "assessment"],
    ["Programming Environment Setup", "Editor, browser, and a first file that runs on your machine.", "quote"],
    ["Software Setup Guidance", "Install a program your class or job named, using a license you have.", "assessment"],
    ["Beginner Technology Consultations", "A plain-language session before you buy a course, a laptop, or a website.", "assessment"],
    ["Digital Productivity Guidance", "A simpler way to keep files, classes, and messages you already use.", "assessment"],
    ["Basic Website Accessibility Improvements", "Contrast, labels, headings, and keyboard use on a site we can review.", "assessment"],
    ["Website Usability Assessments", "Where a visitor gets stuck, written as notes rather than a redesign you did not ask for.", "assessment"],
  ]),
];

export type ServiceGuide = {
  includes: string[];
  prepare: string[];
  delivery: string;
  scope: string;
};

/**
 * Plain-language guidance shown on every service detail page. These are typical
 * planning points, not a promise that every item is included in every quotation.
 */
const SERVICE_GUIDES: Record<CategoryId, ServiceGuide> = {
  phone: {
    includes: [
      "Clarify the symptoms, phone model, and when the issue started.",
      "Review compatible settings and official troubleshooting or recovery steps.",
      "Explain risks before a reset, restore, or change that could affect data.",
    ],
    prepare: [
      "Phone brand/model and Android or iOS version, if known.",
      "The exact error message or a screenshot with private details hidden.",
      "A note on whether important files are backed up and whether you own the device or have permission to manage it.",
    ],
    delivery: "A plain-language assessment and next-step guide based on the information available.",
    scope: "Physical damage may need in-person inspection. Recovery is not guaranteed, and screen-lock or account help uses official provider methods only.",
  },
  computer: {
    includes: [
      "Identify the computer, operating system, and the steps that trigger the issue.",
      "Check reasonable software, settings, compatibility, and configuration causes.",
      "Discuss backup and data-loss risks before any reinstall or destructive change.",
    ],
    prepare: [
      "Computer make/model, operating system, and any relevant error messages.",
      "A short list of what you already tried and when the issue began.",
      "Confirmation that important files are backed up where possible; software license details only if needed.",
    ],
    delivery: "A troubleshooting summary with practical next steps, setup guidance, or an assessment of what needs an in-person technician.",
    scope: "Software support is not a guarantee of hardware repair or data recovery. Reinstallation can erase files and must be approved first.",
  },
  network: {
    includes: [
      "Separate likely device, router, Wi-Fi coverage, and internet-provider causes.",
      "Review safe configuration checks for a network you own or are authorized to administer.",
      "Prioritize changes that can be tested and reversed when practical.",
    ],
    prepare: [
      "Router model and internet provider, if available.",
      "Which devices are affected, where the signal drops, and any error messages.",
      "Confirmation that you own the network or have permission to manage it. Do not send router passwords.",
    ],
    delivery: "A connection assessment and an ordered checklist of settings or tests to try.",
    scope: "Support is limited to authorized networks. Provider outages, damaged cabling, and faulty hardware may require the ISP or an on-site technician.",
  },
  design: {
    includes: [
      "Clarify the design goal, audience, platform, and intended use.",
      "Agree on dimensions, visual direction, key text, and the number of deliverables before work begins.",
      "Prepare exports in the formats and sizes confirmed in the quotation.",
    ],
    prepare: [
      "Final wording, correct names/details, preferred colors, and required dimensions.",
      "Brand logos, photos, or reference material you have permission to use.",
      "Deadline, target platform, and any required editable-file format.",
    ],
    delivery: "The agreed design files and export formats, with revision rounds defined in the quotation.",
    scope: "Stock assets, licensed fonts, printing, editable source files, and extra revisions are included only when stated in the approved scope.",
  },
  web: {
    includes: [
      "Define the website goal, target visitors, required pages, and main action.",
      "Plan a readable, mobile-friendly layout with clear navigation and contact paths.",
      "Check the interactions and handoff items that are explicitly listed in the project scope.",
    ],
    prepare: [
      "Page names, written content, logo, and images you have permission to publish.",
      "Examples you like, must-have features, and the devices your visitors commonly use.",
      "Any existing domain/hosting information you can safely share. Never send passwords or one-time codes.",
    ],
    delivery: "A website or prototype matching the agreed page list and feature scope, plus handoff notes for the agreed files or deployment.",
    scope: "Hosting, domain costs, database, user accounts, backups, email delivery, analytics, and payment processing are not assumed unless specifically scoped and quoted.",
  },
  business: {
    includes: [
      "Clarify the offer, target customers, preferred tone, and the information customers need first.",
      "Organize approved business facts into consistent visuals, menus, catalogs, or online pages.",
      "Review the contact path and calls to action so customers know how to inquire.",
    ],
    prepare: [
      "Confirmed service/product names, descriptions, current prices, and contact details.",
      "Logo, brand colors, product photos, and audience information if available.",
      "The specific deliverables, platforms, and launch deadline you have in mind.",
    ],
    delivery: "A coordinated set of business materials or an online presence defined in the written quotation.",
    scope: "Customer growth, revenue, ad performance, and search rankings cannot be guaranteed. Publishing, paid ads, and third-party charges are separate unless stated.",
  },
  video: {
    includes: [
      "Set the intended length, platform, aspect ratio, and main message.",
      "Plan the edit, pacing, titles/captions, and visual elements within the agreed scope.",
      "Export a review copy and final format as specified in the quotation.",
    ],
    prepare: [
      "Original footage, photos, logo, and text you have permission to use.",
      "Target platform, preferred style, approximate duration, and deadline.",
      "Any licensed music or assets you want included, with proof of usage rights if relevant.",
    ],
    delivery: "An edited video or multimedia asset in the agreed dimensions and file format.",
    scope: "Complex animation, extensive cleanup, licensed media, voice-over, and major revisions may require a separate quote or assessment.",
  },
  products: {
    includes: [
      "Confirm the purpose, intended audience, format, and editing software.",
      "Build or prepare the template around the agreed structure and required fields.",
      "Provide brief use instructions when they are part of the agreed deliverables.",
    ],
    prepare: [
      "Preferred format or app, examples, content, and page/slide requirements.",
      "Whether you need editable files, print-ready exports, or both.",
      "Any license or reuse requirements that matter for your project.",
    ],
    delivery: "The agreed digital files and a clear note of the formats and usage terms supplied.",
    scope: "Custom tailoring, updates, commercial-use rights, and connected online features are separate unless included in the listing or quotation.",
  },
  tools: {
    includes: [
      "Map the inputs, rules/formulas, outputs, and expected user flow.",
      "Use clear labels and representative examples to make the tool easier to understand.",
      "Check typical and edge-case examples agreed for the project.",
    ],
    prepare: [
      "The rules or formula the tool should follow, plus at least two example scenarios.",
      "Required fields, expected results, preferred file/browser, and who will use it.",
      "Whether you need export, sharing, or permanent data storage—these change the technical scope.",
    ],
    delivery: "A spreadsheet, checklist, calculator, or browser tool with the agreed inputs and outputs.",
    scope: "The tool does not replace professional financial, legal, or medical advice. Accounts, private integrations, and permanent storage require a separate security and technical assessment.",
  },
  learning: {
    includes: [
      "Start from your current skill level and the specific concept or error you want to understand.",
      "Break the topic into manageable steps with an example you can run or review.",
      "Explain how to test the result and how to approach similar problems independently.",
    ],
    prepare: [
      "Your goal, language/software, and what you have tried so far.",
      "The instructions or error message, with personal or school account data removed.",
      "Any relevant project files you are allowed to share.",
    ],
    delivery: "Guided explanation, practical examples, and next steps tailored to the requested topic.",
    scope: "Learning support helps you understand the work. It is not a certified qualification, a guaranteed grade, or a service that takes an exam on your behalf.",
  },
};

const SERVICE_DETAIL_RULES: Array<{
  category?: CategoryId;
  match: RegExp;
  includes?: string[];
  prepare?: string[];
  delivery?: string;
  scope?: string;
}> = [
  {
    category: "phone",
    match: /screen lock|account recovery|forgotten.*lock/i,
    includes: ["Identify the device/provider's official recovery route and explain the prerequisites."],
    prepare: ["Keep proof of ownership available if requested by the manufacturer or service provider."],
    delivery: "Official recovery steps and a checklist of what you may need to complete them yourself.",
    scope: "No lock bypass, security circumvention, or guaranteed account access is offered.",
  },
  {
    category: "phone",
    match: /backup|transfer|photo|file recovery|data recovery/i,
    includes: ["Review supported backup/transfer options and how to verify the destination copy."],
    prepare: ["Approximate data size, source/destination devices, available storage, and whether each device can be unlocked normally."],
    delivery: "A transfer or backup plan using supported tools, with verification steps where possible.",
    scope: "Deleted, corrupted, or inaccessible data may not be recoverable. No passwords, OTPs, or recovery codes are needed in chat.",
  },
  {
    category: "computer",
    match: /data recovery|file recovery|reinstall|reformat|reset/i,
    includes: ["Assess data-loss risk and backup options before recommending a reset, reinstall, or recovery attempt."],
    prepare: ["Tell us whether the drive makes unusual noises, the files are irreplaceable, and whether a backup exists."],
    delivery: "A risk-aware recommendation on whether to continue, back up first, or seek specialist recovery.",
    scope: "Do not keep retrying a failing drive if the data is important. Recovery is assessment-only and is never guaranteed.",
  },
  {
    category: "computer",
    match: /install|setup|update|driver|software/i,
    includes: ["Check compatibility, setup requirements, update path, and license/activation considerations."],
    prepare: ["Software name/version, operating system, device specs if known, and license status."],
    delivery: "A supported setup plan or configuration guidance for your own device.",
  },
  {
    category: "network",
    match: /router|wi.?fi|internet|network|connection/i,
    includes: ["Test a structured set of connection checks before suggesting router or device changes."],
    prepare: ["Where the problem happens, whether wired internet works, and which devices are affected."],
    delivery: "A prioritized checklist to help distinguish Wi-Fi coverage, local-device, router, and ISP issues.",
  },
  {
    category: "design",
    match: /logo|brand|identity|brand board/i,
    includes: ["Explore a clear visual direction, legibility at small sizes, and consistency with your brand."],
    prepare: ["Brand name spelling, audience, preferred mood, colors to use/avoid, and competitors or references."],
    delivery: "The logo/brand assets, versions, and file formats expressly listed in the approved scope.",
  },
  {
    category: "design",
    match: /social media|social post|poster|advertisement|ad set/i,
    includes: ["Shape the message hierarchy for fast reading and adapt layout to the agreed platform size."],
    prepare: ["Final headline, dates/prices if any, call to action, target platform, and source images."],
    delivery: "The agreed promotional graphic sizes, with all factual wording checked against the information you supply.",
  },
  {
    category: "design",
    match: /presentation|pitch deck|deck/i,
    includes: ["Organize information into a consistent slide flow with readable typography and visual hierarchy."],
    prepare: ["Outline/content, audience, presentation length, brand assets, and any reference/template requirements."],
    delivery: "The agreed editable presentation and/or PDF export. Research and writing are included only if scoped.",
  },
  {
    category: "design",
    match: /resume|brochure|document|menu|catalog/i,
    includes: ["Set up a readable content hierarchy and prepare the layout for its intended screen or print use."],
    prepare: ["Final and proofread text, page size, required sections, images, and output format."],
    delivery: "A final document or export in the agreed size and file format.",
  },
  {
    category: "web",
    match: /account|login|database|payment|checkout|booking|admin|dashboard/i,
    includes: ["Separate the visible interface from data storage, authentication, permissions, and third-party connections."],
    prepare: ["List required roles, data fields, privacy expectations, and any providers you already use—never share live secrets."],
    delivery: "A scoped technical plan or prototype first; connected production features are included only when specifically quoted.",
    scope: "A visual prototype is not a secure production backend. Authentication, database, payment, email, backups, and deployment must be explicitly designed and tested.",
  },
  {
    category: "web",
    match: /landing page|contact page|inquiry|qr code/i,
    includes: ["Make the page's primary action obvious and test the destination/contact path listed in the brief."],
    prepare: ["Final public contact details, destination URL, call-to-action wording, and brand assets."],
    delivery: "A focused page that sends visitors to the agreed contact, information, or destination link.",
  },
  {
    category: "web",
    match: /portfolio|profile|resume/i,
    includes: ["Organize biography, work samples, skills, and contact information into a scannable responsive page."],
    prepare: ["Approved bio, work samples you may publish, links, and the contact method you want public."],
    delivery: "A personal/creator page with the content and sections agreed in the scope.",
  },
  {
    category: "video",
    match: /caption|subtitle/i,
    includes: ["Align captions with the supplied speech/transcript and check timing and legibility."],
    prepare: ["A clean source video plus transcript, if available, and preferred caption style/language."],
    delivery: "Captioned video or a separate subtitle file in the agreed format.",
  },
  {
    category: "video",
    match: /thumbnail/i,
    includes: ["Build a clear focal point and readable text for the platform's thumbnail size."],
    prepare: ["Video topic/title, approved photo or frame, and any branding that must appear."],
    delivery: "A thumbnail image exported to the agreed size and file format.",
  },
  {
    category: "products",
    match: /html|coding|website template/i,
    includes: ["Clarify which editor/browser is expected and keep starter files organized for beginners."],
    prepare: ["Preferred language or design goal, skill level, and any school or personal requirements."],
    delivery: "A starter file set plus short setup/use notes as agreed; hosting and backend features are not automatic.",
  },
  {
    category: "products",
    match: /study|reviewer|worksheet/i,
    includes: ["Arrange material into readable topics, practice prompts, and a consistent page structure."],
    prepare: ["Subject, grade/level, required curriculum or learning objectives, and any teacher-provided source material."],
    delivery: "An editable or printable learning template based on the supplied scope and source material.",
  },
  {
    category: "tools",
    match: /spreadsheet|calculator|budget|recordkeeping/i,
    includes: ["Define calculation rules, label units clearly, and test representative example values."],
    prepare: ["Expected formulas, sample inputs with expected outputs, and preferred spreadsheet/file format."],
    delivery: "A labeled spreadsheet or calculator with the agreed calculations and brief usage notes.",
  },
  {
    category: "tools",
    match: /form|checklist/i,
    includes: ["Define required/optional fields, useful validation, and what should happen after submission."],
    prepare: ["Field list, submission destination, who can access results, and retention/privacy expectations."],
    delivery: "A form or checklist matching the agreed flow. Persistent storage is separate unless quoted.",
  },
  {
    category: "learning",
    match: /html|css|javascript|coding|programming/i,
    includes: ["Work through the relevant syntax, a small example, and a way to test or debug it yourself."],
    prepare: ["Your current code or exercise, what you expect it to do, and the error/result you actually see."],
    delivery: "An explained learning example and actionable feedback so you can continue the work independently.",
  },
];

export function serviceGuideFor(service: Service): ServiceGuide {
  const base = SERVICE_GUIDES[service.category];
  const specific = SERVICE_DETAIL_RULES.find(
    (rule) => (!rule.category || rule.category === service.category) && rule.match.test(service.name),
  );
  return {
    includes: [...(specific?.includes ?? []), ...base.includes],
    prepare: [...(specific?.prepare ?? []), ...base.prepare],
    delivery: specific?.delivery ?? base.delivery,
    scope: [specific?.scope, service.notes]
      .filter((note): note is string => Boolean(note))
      .filter((note, index, notes) => notes.indexOf(note) === index)
      .join(" ") || base.scope,
  };
}

export function categoryById(id: string) {
  return categories.find((category) => category.id === id);
}

export function findService(id: string) {
  return services.find((service) => service.id === id);
}

export function servicesIn(category: string) {
  if (!category || category === "all") return services;
  return services.filter((service) => service.category === category);
}

export function filterServices(category: string, query: string, group?: string) {
  const q = query.trim().toLowerCase();
  return servicesIn(category).filter((service) => {
    if (group && group !== "all" && service.group !== group) return false;
    if (!q) return true;
    const guide = serviceGuideFor(service);
    const searchableDetails = [
      ...(guide.includes ?? []),
      ...(guide.prepare ?? []),
      guide.delivery,
      guide.scope,
      service.notes ?? "",
    ];
    return (
      service.name.toLowerCase().includes(q) ||
      service.summary.toLowerCase().includes(q) ||
      (service.group?.toLowerCase().includes(q) ?? false) ||
      searchableDetails.some((detail) => detail.toLowerCase().includes(q))
    );
  });
}

export function groupsFor(category: string) {
  const names = new Set<string>();
  for (const service of servicesIn(category)) {
    if (service.group) names.add(service.group);
  }
  return [...names];
}
