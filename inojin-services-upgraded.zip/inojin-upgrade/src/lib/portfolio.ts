export const portfolioFilters = [
  "All",
  "Graphic Design",
  "Presentations",
  "Advertisements",
  "Websites",
  "Branding",
  "Digital Products",
  "Technical Projects",
  "Other Creative Work",
] as const;

export type PortfolioFilter = (typeof portfolioFilters)[number];

export type BoardKind =
  | "photo"
  | "deck"
  | "poster"
  | "social"
  | "brand"
  | "web"
  | "resume"
  | "qr";

export type PortfolioItem = {
  id: string;
  title: string;
  category: Exclude<PortfolioFilter, "All">;
  summary: string;
  tools: string;
  deliverables: string;
  status: string;
  kind: BoardKind;
  image?: string;
  imageAlt?: string;
};

export const portfolio: PortfolioItem[] = [
  {
    id: "studio-desk",
    title: "Studio desk study",
    category: "Other Creative Work",
    summary:
      "A photograph made for this website: laptop, phone, and paper on a work table. It is not a client commission.",
    tools: "Photograph",
    deliverables: "Website image",
    status: "Studio photograph — not client work",
    kind: "photo",
    image: "/images/desk.jpg",
    imageAlt: "Overhead photograph of a navy laptop, a phone, and printed sheets on a pale desk",
  },
  {
    id: "print-still",
    title: "Print material still life",
    category: "Graphic Design",
    summary:
      "Paper, a poster with abstract shapes, and a card stack. Used to show the kind of print work the studio can discuss. No client logo.",
    tools: "Photograph",
    deliverables: "Gallery image",
    status: "Studio photograph — not client work",
    kind: "photo",
    image: "/images/print.jpg",
    imageAlt: "Printed posters and cards with abstract navy and teal shapes on a table",
  },
  {
    id: "color-devices",
    title: "Color and device notes",
    category: "Branding",
    summary:
      "A phone and a small navy, teal, and paper swatch. A reference for the Inojin palette, not a client identity.",
    tools: "Photograph",
    deliverables: "Palette reference",
    status: "Demonstration concept",
    kind: "photo",
    image: "/images/swatches.jpg",
    imageAlt: "A dark phone beside a card of navy, teal, and cream color swatches",
  },
  {
    id: "workspace",
    title: "Workspace with a site on screen",
    category: "Websites",
    summary:
      "A desk photograph suggesting a website in progress. The screen is intentionally not a real client site.",
    tools: "Photograph",
    deliverables: "Gallery image",
    status: "Studio photograph — not client work",
    kind: "photo",
    image: "/images/workspace.jpg",
    imageAlt: "A laptop on a wooden desk with a blurred navy and cream page on the screen",
  },
  {
    id: "defense-deck",
    title: "Project defense deck",
    category: "Presentations",
    summary:
      "A sample slide structure for a student defense: problem, method, result, and a closing slide. Placeholder words only.",
    tools: "Layout concept",
    deliverables: "Slide structure preview",
    status: "Demonstration concept",
    kind: "deck",
  },
  {
    id: "community-poster",
    title: "Community afternoon poster",
    category: "Advertisements",
    summary:
      "A tarpaulin-style poster concept for a neighborhood event. The date and place are samples, not a real booking.",
    tools: "Layout concept",
    deliverables: "Poster preview",
    status: "Demonstration concept",
    kind: "poster",
  },
  {
    id: "product-post",
    title: "Weekend market post",
    category: "Advertisements",
    summary:
      "A square social post concept. It does not advertise a real product or a real discount.",
    tools: "Layout concept",
    deliverables: "Social frame preview",
    status: "Demonstration concept",
    kind: "social",
  },
  {
    id: "mark-board",
    title: "Wordmark and palette board",
    category: "Branding",
    summary:
      "How a small identity board can present a name, two colors, and a type note. This board is for Inojin itself, not a client.",
    tools: "Layout concept",
    deliverables: "Identity board preview",
    status: "Demonstration concept",
    kind: "brand",
  },
  {
    id: "resume-layout",
    title: "One-page resume layout",
    category: "Digital Products",
    summary:
      "A resume grid with sample section labels. It is empty of any person’s job history on purpose.",
    tools: "Layout concept",
    deliverables: "Resume preview",
    status: "Demonstration concept",
    kind: "resume",
  },
  {
    id: "menu-page",
    title: "Short menu website",
    category: "Websites",
    summary:
      "A phone-width menu page concept. Dishes listed here are examples, not a restaurant we represent.",
    tools: "HTML layout",
    deliverables: "Page preview",
    status: "Demonstration concept",
    kind: "web",
  },
  {
    id: "qr-card",
    title: "QR contact card",
    category: "Technical Projects",
    summary:
      "A contact card concept with a drawn QR placeholder. It does not encode a live payment or profile link.",
    tools: "Layout concept",
    deliverables: "Card preview",
    status: "Demonstration concept",
    kind: "qr",
  },
  {
    id: "planner-page",
    title: "Week planner page",
    category: "Digital Products",
    summary:
      "A printable week grid. A template direction, not a downloaded product for sale yet.",
    tools: "Layout concept",
    deliverables: "Planner preview",
    status: "Demonstration concept",
    kind: "resume",
  },
];
