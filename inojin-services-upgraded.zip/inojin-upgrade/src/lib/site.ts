/**
 * Edit Inojin Services details and page copy here.
 * Use the verified profile URLs recorded below; update them if the accounts change.
 * Do not invent profile links, prices, QR codes, or reviews.
 */

export const site = {
  name: "Inojin Services",
  legalName: "Inojin Services",
  tagline: "Your Ideas. Our Creativity. Smarter Digital Solutions.",
  heroTitle: "Technology Solutions. Creative Designs. Websites That Work.",
  heroText:
    "From troubleshooting your devices to creating beautiful designs and professional websites, Inojin Services helps bring your digital ideas to life.",
  phoneDisplay: "09346305091",
  phoneTel: "+639346305091",
  facebookName: "Inojin Services",
  /** Official Facebook profile supplied by the site owner. */
  facebookUrl: "https://www.facebook.com/profile.php?id=61595177465614",
  instagramName: "@yameinojin",
  /** Instagram profile supplied by the site owner. */
  instagramUrl: "https://www.instagram.com/yameinojin/",
  /**
   * Optional inbox for inquiries, such as hello@yourdomain.com.
   * While this is empty, the form prepares an SMS to the phone number above.
   * The site does not store inquiries on a server.
   */
  inquiryEmail: "",
  availability:
    "Availability is arranged per request. No public hours are posted yet.",
  gcash: {
    method: "GCash",
    accountName: "Imma Conception",
    number: "09675479656",
    /** Optional image path in /public, for example /images/gcash-qr.png, after you supply a real QR. */
    qrImage: "",
    /** Optional official GCash payment link, only after you supply one. */
    paymentLink: "",
  },
  copy: {
    explore: "Explore Our Services",
    start: "Start a Project",
    request: "Request a Service",
    portfolioNote:
      "Every design starts with an idea. Thank you for letting us help bring yours to life. ♡",
    contactNote:
      "Have an idea in mind or need a little tech help? We would love to hear from you. Let's make something useful together!",
    socialNote:
      "Stay connected with Inojin Services! Follow our page for new designs, projects, updates, and digital creations.",
    donationTitle: "Love what we create? Help us create even more! ♡",
    donationBody:
      "If you love our designs, enjoy our services, or appreciate the work we put into our projects, you can support Inojin Services through a voluntary donation. Every contribution, big or small, helps us improve our website, explore new ideas, create better digital experiences, and build more useful services for everyone.\n\nYour support means a lot to us. Thank you for believing in our little journey and helping our ideas grow. And remember, there is absolutely no pressure to donate. Following our page, sharing our work, leaving feedback, or recommending us to a friend already means so much. Thank you for being here! :> ♡",
    donationNear:
      "If our work made your day easier or inspired you, consider supporting our journey. Your kindness helps us keep learning, creating, and improving. Thank you so much! ♡",
    donationThanks: "Thank you for your support ♡",
    donationVerify:
      "Please verify the recipient name and number before sending. Donations are voluntary and separate from payments for services. Please never share your GCash MPIN, OTP, or other private security information with anyone.",
    inquiryWarmth:
      "Thank you for reaching out to Inojin Services! Your project matters to us. We look forward to reviewing your request and discussing the next steps.",
    priceDepends:
      "A final price can depend on complexity, device condition, materials, required revisions, delivery schedule, third-party costs, and technical limits. Nothing starts until you approve the scope, budget, and schedule.",
    why: [
      {
        title: "Clear quotations",
        text: "You see the kind of pricing a service uses, then receive a quotation before any paid work is agreed.",
      },
      {
        title: "Practical help",
        text: "Device support stays on official methods. If a job needs an in-person look or another technician, we say so.",
      },
      {
        title: "Creative work with a brief",
        text: "Design and websites start from your sizes, colors, audience, deadline, and the files you are allowed to use.",
      },
      {
        title: "Privacy-conscious",
        text: "We do not ask for passwords, OTPs, MPINs, or recovery codes. Donations are never required to read this site or to contact us.",
      },
    ],
    steps: [
      "Choose the service you need.",
      "Tell us about your requirements.",
      "Receive an assessment and quotation.",
      "Approve the scope, budget, and schedule.",
      "Receive updates and the agreed deliverables.",
    ],
  },
} as const;

export const faqs = [
  {
    q: "How do I request a service?",
    a: "Open Request a Service, choose a category, describe the job, and review the message. The form copies it and opens your messaging app addressed to our phone number. This website does not keep a copy on a server. You can also call or text 09346305091.",
  },
  {
    q: "Do I have to pay before you look at the request?",
    a: "No. You can ask for a quotation first. Paid work starts only after you approve the scope, budget, and schedule. Service payments are separate from voluntary donations.",
  },
  {
    q: "Can you unlock a phone or account that is not mine?",
    a: "No. Recovery help is limited to official methods for a device or account you own, or that you have permission to administer. We do not bypass locks, and we do not guarantee access.",
  },
  {
    q: "Will you ask for my password, OTP, or GCash MPIN?",
    a: "No. Never send those. If anyone claiming to be Inojin Services asks for an MPIN, OTP, password, or recovery code, do not share it.",
  },
  {
    q: "Do you repair broken screens and other hardware?",
    a: "We assess software problems and can tell you when a fault looks physical. Hardware repair may need an in-person inspection or an authorized technician. We do not promise that every hardware issue can be repaired.",
  },
  {
    q: "Are the portfolio pieces real client jobs?",
    a: "No. The gallery currently shows demonstration concepts and studio photographs, labeled as such. Client work will be shown only when a client agrees.",
  },
  {
    q: "Why are many prices not listed as amounts?",
    a: "Official prices have not been published yet. Each service is marked Fixed Price, Starting At, Custom Quotation, or Assessment Required so you know how it will be priced. Ask for a quotation.",
  },
  {
    q: "Are donations required?",
    a: "No. GCash support is voluntary and separate from service fees. The site cannot see or confirm a donation. You send it yourself in GCash after checking the name Imma Conception and the number 09675479656.",
  },
] as const;
