import type { BoardKind } from "@/lib/portfolio";

export function ConceptBoard({ kind, title }: { kind: BoardKind; title: string }) {
  if (kind === "deck") {
    return (
      <div className="grid aspect-[4/3] grid-cols-2 gap-2 bg-navy p-3">
        {["Problem", "Method", "Result", "Close"].map((label, index) => (
          <div key={label} className="flex flex-col justify-between bg-paper p-3">
            <span className="text-xs font-semibold uppercase tracking-widest text-teal-deep">0{index + 1}</span>
            <span className="font-display text-xl text-ink">{label}</span>
          </div>
        ))}
      </div>
    );
  }
  if (kind === "poster") {
    return (
      <div className="flex aspect-[3/4] flex-col justify-between bg-teal-deep p-5 text-paper">
        <p className="text-xs font-semibold uppercase tracking-widest">Sample event</p>
        <div>
          <p className="font-display text-4xl leading-none">Afternoon on the street</p>
          <div className="mt-4 h-px w-16 bg-paper" />
          <p className="mt-3 text-sm">Date and place are examples.</p>
        </div>
        <p className="text-xs uppercase tracking-widest">Demonstration</p>
      </div>
    );
  }
  if (kind === "social") {
    return (
      <div className="flex aspect-square flex-col justify-between bg-paper-2 p-5">
        <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Square post</p>
        <p className="font-display text-4xl leading-none text-ink">Market day</p>
        <p className="text-sm text-ink-soft">No real discount. No real shop.</p>
      </div>
    );
  }
  if (kind === "brand") {
    return (
      <div className="aspect-[4/3] bg-paper p-5">
        <p className="font-display text-4xl text-ink">Inojin</p>
        <p className="text-xs uppercase tracking-widest text-ink-soft">Wordmark study</p>
        <div className="mt-6 flex gap-3">
          <span className="h-12 w-12 bg-navy" />
          <span className="h-12 w-12 bg-teal-deep" />
          <span className="h-12 w-12 border border-line bg-paper-2" />
        </div>
        <p className="mt-4 text-sm text-ink-soft">{title}</p>
      </div>
    );
  }
  if (kind === "web") {
    return (
      <div className="flex aspect-[4/3] items-center justify-center bg-paper-2 p-4">
        <div className="w-40 border border-ink bg-paper p-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Menu</p>
          <ul className="mt-3 space-y-2 text-sm text-ink">
            <li className="flex justify-between border-b border-line pb-1"><span>Garlic rice</span><span>sample</span></li>
            <li className="flex justify-between border-b border-line pb-1"><span>Iced tea</span><span>sample</span></li>
            <li className="flex justify-between"><span>Contact</span><span>page</span></li>
          </ul>
        </div>
      </div>
    );
  }
  if (kind === "qr") {
    return (
      <div className="grid aspect-[4/3] grid-cols-[1fr_auto] items-center gap-4 bg-paper p-5">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Contact card</p>
          <p className="mt-2 font-display text-3xl text-ink">Inojin Services</p>
          <p className="mt-2 text-sm text-ink-soft">The pattern beside this text is decorative. It is not a scannable code.</p>
        </div>
        <div className="grid size-24 grid-cols-5 gap-1 bg-navy p-2" aria-hidden="true">
          {Array.from({ length: 25 }, (_, index) => (
            <span key={index} className={index % 3 === 0 ? "bg-paper" : "bg-navy"} />
          ))}
        </div>
      </div>
    );
  }
  return (
    <div className="aspect-[4/3] bg-paper p-5">
      <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">Resume</p>
      <p className="mt-2 font-display text-3xl text-ink">Name withheld</p>
      <div className="mt-4 space-y-3 text-sm">
        {["Experience", "Education", "Tools"].map((section) => (
          <div key={section}>
            <p className="font-semibold text-ink">{section}</p>
            <p className="text-ink-soft">Sample line — not a real person</p>
          </div>
        ))}
      </div>
    </div>
  );
}
