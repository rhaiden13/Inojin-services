import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { categories, findService, servicesIn } from "@/lib/catalog";
import { copyText } from "@/lib/copy-text";
import {
  budgetOptions,
  contactMethods,
  formatInquiry,
  inquirySchema,
  mailtoHref,
  meetingOptions,
  smsHref,
  type InquiryInput,
} from "@/lib/inquiry";
import { site } from "@/lib/site";

const empty: InquiryInput = {
  fullName: "",
  contactMethod: "phone",
  contactDetails: "",
  category: "",
  serviceId: "",
  projectType: "",
  description: "",
  budget: "",
  schedule: "",
  meeting: "remote",
  instructions: "",
  consent: false,
  website: "",
};

export function InquiryForm({ initialService = "" }: { initialService?: string }) {
  const preset = findService(initialService);
  const [values, setValues] = useState<InquiryInput>({
    ...empty,
    category: preset?.category ?? "",
    serviceId: preset?.id ?? "",
  });
  const [fileNames, setFileNames] = useState<string[]>([]);
  const [fileNote, setFileNote] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [phase, setPhase] = useState<"edit" | "review" | "ready">("edit");
  const [message, setMessage] = useState("");
  const [copyState, setCopyState] = useState<"idle" | "copied" | "failed">("idle");

  useEffect(() => {
    if (!preset) return;
    setValues((current) => ({ ...current, category: preset.category, serviceId: preset.id }));
  }, [preset]);

  const choices = useMemo(() => servicesIn(values.category || "none"), [values.category]);
  const designHint = values.category === "design" || values.category === "business";

  function update<K extends keyof InquiryInput>(key: K, value: InquiryInput[K]) {
    setValues((current) => {
      const next = { ...current, [key]: value };
      if (key === "category") next.serviceId = "";
      return next;
    });
  }

  function validate(target: InquiryInput) {
    const parsed = inquirySchema.safeParse(target);
    if (parsed.success) {
      setErrors({});
      return parsed.data;
    }
    const next: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      if (!next[key]) next[key] = issue.message;
    }
    setErrors(next);
    return null;
  }

  function review(event: FormEvent) {
    event.preventDefault();
    const parsed = validate(values);
    if (!parsed) {
      setPhase("edit");
      return;
    }
    setValues(parsed);
    setMessage(formatInquiry(parsed, fileNames));
    setPhase("review");
    setCopyState("idle");
  }

  async function handoff() {
    const ok = await copyText(message);
    setCopyState(ok ? "copied" : "failed");
    if (ok) setPhase("ready");
  }

  const destination = site.inquiryEmail
    ? mailtoHref(message, `Inquiry from ${values.fullName || "a visitor"}`)
    : smsHref(message);

  return (
    <div className="border border-line bg-paper px-4 py-6 sm:px-6">
      <p className="text-sm text-ink-soft">
        {site.inquiryEmail
          ? `Submitting opens your email app to ${site.inquiryEmail} after the message is copied. This website does not store the request.`
          : `There is no server inbox yet. Submitting copies your inquiry and opens Messages to ${site.phoneDisplay}. We see it only after you press send.`}
      </p>

      {phase === "edit" ? (
        <form className="mt-6 grid gap-5" onSubmit={review} noValidate>
          <Honeypot value={values.website} onChange={(value) => update("website", value)} />
          <Field label="Full name" error={errors.fullName} htmlFor="full-name">
            <input id="full-name" className={inputClass} value={values.fullName} onChange={(event) => update("fullName", event.target.value)} autoComplete="name" required />
          </Field>
          <Field label="Preferred contact method" error={errors.contactMethod} htmlFor="contact-method">
            <select id="contact-method" className={inputClass} value={values.contactMethod} onChange={(event) => update("contactMethod", event.target.value as InquiryInput["contactMethod"])}>
              {contactMethods.map((method) => (
                <option key={method.id} value={method.id}>{method.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Contact details" error={errors.contactDetails} htmlFor="contact-details">
            <input
              id="contact-details"
              className={inputClass}
              value={values.contactDetails}
              onChange={(event) => update("contactDetails", event.target.value)}
              autoComplete={values.contactMethod === "email" ? "email" : "tel"}
              placeholder={values.contactMethod === "email" ? "you@email.com" : "Your number or profile name"}
              required
            />
          </Field>
          <Field label="Service category" error={errors.category} htmlFor="category">
            <select
              id="category"
              className={inputClass}
              value={values.category}
              onChange={(event) => update("category", event.target.value)}
              required
            >
              <option value="">Choose a category</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Specific service" error={errors.serviceId} htmlFor="service">
            <select
              id="service"
              className={inputClass}
              value={values.serviceId}
              onChange={(event) => update("serviceId", event.target.value)}
              required
              disabled={!values.category}
            >
              <option value="">{values.category ? "Choose a service" : "Choose a category first"}</option>
              {choices.map((service) => (
                <option key={service.id} value={service.id}>{service.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Device or project type" error={errors.projectType} htmlFor="project-type">
            <input id="project-type" className={inputClass} value={values.projectType} onChange={(event) => update("projectType", event.target.value)} placeholder="Android phone, class deck, small shop site" required />
          </Field>
          <Field label="Description" error={errors.description} htmlFor="description">
            <textarea id="description" className={`${inputClass} min-h-36`} value={values.description} onChange={(event) => update("description", event.target.value)} required />
            {designHint ? (
              <p className="text-sm text-ink-soft">For design work, include dimensions, colors, audience, platform, deadline, and the deliverables you want.</p>
            ) : null}
          </Field>
          <Field label="Budget range, optional" error={errors.budget} htmlFor="budget">
            <select id="budget" className={inputClass} value={values.budget ?? ""} onChange={(event) => update("budget", event.target.value)}>
              <option value="">No budget note</option>
              {budgetOptions.map((option) => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
          </Field>
          <Field label="Preferred schedule" error={errors.schedule} htmlFor="schedule">
            <input id="schedule" className={inputClass} value={values.schedule} onChange={(event) => update("schedule", event.target.value)} placeholder="This week, or a date you have in mind" required />
          </Field>
          <Field label="Remote or in person" error={errors.meeting} htmlFor="meeting">
            <select id="meeting" className={inputClass} value={values.meeting} onChange={(event) => update("meeting", event.target.value as InquiryInput["meeting"])}>
              {meetingOptions.map((option) => (
                <option key={option.id} value={option.id}>{option.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Reference files, optional" error="" htmlFor="files">
            <input
              id="files"
              type="file"
              multiple
              className="block w-full text-sm"
              onChange={(event) => {
                const files = [...(event.target.files ?? [])];
                const large = files.filter((file) => file.size > 15 * 1024 * 1024);
                setFileNames(files.map((file) => file.name));
                setFileNote(
                  large.length
                    ? "A selected file is over 15 MB. Nothing is uploaded. Only the file name is added to the message so you can send it later."
                    : "Files stay on your device. This site cannot store uploads yet. The names are added to the message.",
                );
              }}
            />
            {fileNote ? <p className="text-sm text-ink-soft">{fileNote}</p> : null}
            {fileNames.length ? <p className="text-sm text-ink">Named: {fileNames.join(", ")}</p> : null}
          </Field>
          <Field label="Additional instructions" error={errors.instructions} htmlFor="instructions">
            <textarea id="instructions" className={`${inputClass} min-h-24`} value={values.instructions ?? ""} onChange={(event) => update("instructions", event.target.value)} />
          </Field>
          <label className="flex items-start gap-3 text-sm text-ink">
            <input
              type="checkbox"
              className="mt-1 size-5"
              checked={values.consent}
              onChange={(event) => update("consent", event.target.checked)}
            />
            <span>
              I agree that Inojin Services may use this information only to reply about the inquiry. I will not include passwords, OTPs, or payment PINs.
            </span>
          </label>
          {errors.consent ? <p className="text-sm text-danger" role="alert">{errors.consent}</p> : null}
          {errors.website ? <p className="text-sm text-danger" role="alert">{errors.website}</p> : null}
          <button type="submit" className="inline-flex min-h-11 items-center justify-center bg-teal-deep px-5 font-semibold text-paper hover:bg-navy">
            Review inquiry
          </button>
        </form>
      ) : null}

      {phase === "review" ? (
        <div className="mt-6">
          <h2 className="font-display text-3xl text-ink">Review before sending</h2>
          <pre className="mt-4 overflow-x-auto whitespace-pre-wrap border border-line bg-paper-2 p-4 text-sm text-ink">{message}</pre>
          <div className="mt-4 flex flex-wrap gap-3">
            <button type="button" className="inline-flex min-h-11 items-center border border-ink px-4 font-semibold" onClick={() => setPhase("edit")}>
              Edit
            </button>
            <button type="button" className="inline-flex min-h-11 items-center bg-teal-deep px-4 font-semibold text-paper" onClick={() => void handoff()}>
              {site.inquiryEmail ? "Copy inquiry and open email" : "Copy inquiry and open Messages"}
            </button>
          </div>
          {copyState === "failed" ? (
            <p className="mt-3 text-sm text-danger" role="alert">
              The message was not copied, so it was not handed to your phone or email app. Select the text above and copy it, then contact {site.phoneDisplay}.
            </p>
          ) : null}
        </div>
      ) : null}

      {phase === "ready" ? (
        <div className="mt-6 border border-teal bg-foam px-4 py-5" role="status">
          <h2 className="font-display text-3xl text-ink">Ready to send — not received yet</h2>
          <p className="mt-3 text-ink">{site.copy.inquiryWarmth}</p>
          <p className="mt-3 text-ink">
            The full inquiry is on your clipboard.
            {site.inquiryEmail
              ? ` Open your email app to send it to ${site.inquiryEmail}.`
              : ` Open Messages to send it to ${site.phoneDisplay}.`}
            {" "}This website cannot confirm delivery, and it does not keep a copy.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <a href={destination} className="inline-flex min-h-11 items-center bg-teal-deep px-4 font-semibold text-paper">
              {site.inquiryEmail ? "Open email" : "Open Messages"}
            </a>
            <a href={`tel:${site.phoneTel}`} className="inline-flex min-h-11 items-center border border-ink px-4 font-semibold">
              Call {site.phoneDisplay}
            </a>
            <button type="button" className="inline-flex min-h-11 items-center px-2 font-semibold text-teal-deep underline" onClick={() => setPhase("edit")}>
              Start another inquiry
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

const inputClass = "mt-2 w-full border border-line bg-paper px-3 py-3 text-ink";

function Field({
  label,
  htmlFor,
  error,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="text-sm font-semibold text-ink">
        {label}
      </label>
      {children}
      {error ? (
        <p className="mt-1 text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

function Honeypot({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <div className="sr-only" aria-hidden="true">
      <label>
        Company website
        <input tabIndex={-1} autoComplete="off" value={value} onChange={(event) => onChange(event.target.value)} />
      </label>
    </div>
  );
}
