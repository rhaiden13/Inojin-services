import { Link } from "@tanstack/react-router";
import { categories, filterServices, groupsFor, priceKindLabel, type CategoryId } from "@/lib/catalog";

export type ServiceSearch = {
  category: string;
  q: string;
  group: string;
};

export function ServiceBrowser({
  search,
  onSearch,
}: {
  search: ServiceSearch;
  onSearch: (next: ServiceSearch) => void;
}) {
  const groups = search.category === "all" ? [] : groupsFor(search.category);
  const list = filterServices(search.category, search.q, search.group);
  const active = categories.find((item) => item.id === search.category);

  return (
    <div className="mx-auto w-full max-w-6xl px-5 py-10">
      <form
        className="grid gap-3 sm:grid-cols-[1fr_auto]"
        onSubmit={(event) => event.preventDefault()}
        role="search"
      >
        <div>
          <label htmlFor="service-search" className="text-sm font-semibold text-ink">
            Search services
          </label>
          <input
            id="service-search"
            value={search.q}
            onChange={(event) => onSearch({ ...search, q: event.target.value })}
            placeholder="Try backup, logo, Wi-Fi, resume"
            className="mt-2 w-full border border-line bg-paper px-3 py-3 text-ink"
          />
        </div>
        <button
          type="button"
          className="mt-auto inline-flex min-h-11 items-center justify-center border border-ink px-4 text-sm font-semibold"
          onClick={() => onSearch({ category: "all", q: "", group: "all" })}
        >
          Clear
        </button>
      </form>

      <div className="mt-6 flex gap-2 overflow-x-auto pb-2" role="tablist" aria-label="Service categories">
        <FilterChip
          active={search.category === "all"}
          onClick={() => onSearch({ ...search, category: "all", group: "all" })}
          label={`All (${filterServices("all", "", "all").length})`}
        />
        {categories.map((category) => (
          <FilterChip
            key={category.id}
            active={search.category === category.id}
            onClick={() => onSearch({ ...search, category: category.id, group: "all" })}
            label={category.name}
          />
        ))}
      </div>

      {groups.length > 1 ? (
        <div className="mt-3 flex flex-wrap gap-2">
          <FilterChip active={search.group === "all"} onClick={() => onSearch({ ...search, group: "all" })} label="Every group" />
          {groups.map((group) => (
            <FilterChip
              key={group}
              active={search.group === group}
              onClick={() => onSearch({ ...search, group })}
              label={group}
            />
          ))}
        </div>
      ) : null}

      {active ? (
        <div className="mt-8 border-l-2 border-teal pl-4">
          <h2 className="font-display text-3xl text-ink">{active.name}</h2>
          <p className="mt-2 max-w-3xl text-ink-soft">{active.blurb}</p>
          <p className="mt-3 max-w-3xl text-sm text-ink">{active.disclaimer}</p>
        </div>
      ) : null}

      {list.length === 0 ? (
        <p className="mt-10 border border-line bg-paper-2 px-4 py-6 text-ink" role="status">
          No services match that search. Try a shorter word, or choose another category.
        </p>
      ) : (
        <ul className="mt-8 divide-y divide-line border-y border-line">
          {list.map((service) => (
            <li key={service.id} className="grid gap-3 py-5 md:grid-cols-[1fr_auto] md:items-center">
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">
                  {categories.find((item) => item.id === service.category)?.name}
                  {service.group ? ` · ${service.group}` : ""}
                </p>
                <h3 className="mt-1 font-display text-2xl text-ink">{service.name}</h3>
                <p className="mt-2 max-w-2xl text-ink-soft">{service.summary}</p>
                <p className="mt-2 text-sm font-semibold text-ink">{priceKindLabel(service.priceKind)}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Link
                  to="/services/$serviceId"
                  params={{ serviceId: service.id }}
                  className="inline-flex min-h-11 items-center border border-ink px-4 text-sm font-semibold hover:bg-ink hover:text-paper"
                >
                  Details
                </Link>
                <Link
                  to="/request"
                  search={{ service: service.id }}
                  className="inline-flex min-h-11 items-center bg-teal-deep px-4 text-sm font-semibold text-paper hover:bg-navy"
                >
                  Inquire
                </Link>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function FilterChip({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={
        "inline-flex min-h-11 shrink-0 items-center px-3 text-sm font-semibold " +
        (active ? "bg-navy text-paper" : "border border-line bg-paper text-ink hover:border-ink")
      }
    >
      {label}
    </button>
  );
}

export function isCategoryId(value: string): value is CategoryId {
  return categories.some((category) => category.id === value);
}
