import { useEffect, useId, useRef, useState } from "react";
import { X } from "lucide-react";
import { portfolio, portfolioFilters, type PortfolioFilter, type PortfolioItem } from "@/lib/portfolio";
import { ConceptBoard } from "@/components/concept-board";

export function PortfolioGallery({ initial = "All" as PortfolioFilter }: { initial?: PortfolioFilter }) {
  const [filter, setFilter] = useState<PortfolioFilter>(initial);
  const [open, setOpen] = useState<PortfolioItem | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const titleId = useId();
  const visible = portfolio.filter((item) => filter === "All" || item.category === filter);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(null);
    };
    window.addEventListener("keydown", onKey);
    closeRef.current?.focus();
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [open]);

  return (
    <div className="mx-auto w-full max-w-6xl px-5 py-10">
      <div className="flex gap-2 overflow-x-auto pb-2" role="tablist" aria-label="Portfolio filters">
        {portfolioFilters.map((item) => (
          <button
            key={item}
            type="button"
            role="tab"
            aria-selected={filter === item}
            onClick={() => setFilter(item)}
            className={
              "inline-flex min-h-11 shrink-0 items-center px-3 text-sm font-semibold " +
              (filter === item ? "bg-navy text-paper" : "border border-line bg-paper text-ink")
            }
          >
            {item}
          </button>
        ))}
      </div>
      {visible.length === 0 ? (
        <p className="mt-8 border border-line px-4 py-6" role="status">
          Nothing in this filter yet.
        </p>
      ) : (
        <ul className="mt-8 grid gap-8 sm:grid-cols-2">
          {visible.map((item) => (
            <li key={item.id} className="border border-line bg-paper">
              <button type="button" className="block w-full text-left" onClick={() => setOpen(item)}>
                <Preview item={item} />
                <span className="block px-4 py-4">
                  <span className="text-xs font-semibold uppercase tracking-widest text-teal-deep">{item.status}</span>
                  <span className="mt-1 block font-display text-2xl text-ink">{item.title}</span>
                  <span className="mt-2 block text-sm text-ink-soft">{item.category}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
      {open ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-navy/70 sm:items-center" role="presentation" onClick={() => setOpen(null)}>
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            className="max-h-[92vh] w-full max-w-3xl overflow-y-auto bg-paper p-4 sm:p-6"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">{open.status}</p>
                <h2 id={titleId} className="mt-1 font-display text-3xl text-ink">{open.title}</h2>
              </div>
              <button ref={closeRef} type="button" className="inline-flex size-11 items-center justify-center border border-line" onClick={() => setOpen(null)} aria-label="Close preview">
                <X className="size-5" />
              </button>
            </div>
            <div className="mt-4">
              <Preview item={open} large />
            </div>
            <p className="mt-4 text-ink-soft">{open.summary}</p>
            <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-3">
              <div>
                <dt className="font-semibold">Category</dt>
                <dd>{open.category}</dd>
              </div>
              <div>
                <dt className="font-semibold">Tools</dt>
                <dd>{open.tools}</dd>
              </div>
              <div>
                <dt className="font-semibold">Deliverables</dt>
                <dd>{open.deliverables}</dd>
              </div>
            </dl>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Preview({ item, large = false }: { item: PortfolioItem; large?: boolean }) {
  if (item.kind === "photo" && item.image) {
    return (
      <img
        src={item.image}
        alt={item.imageAlt ?? item.title}
        className={large ? "max-h-[60vh] w-full object-cover" : "aspect-[4/3] w-full object-cover"}
      />
    );
  }
  return <ConceptBoard kind={item.kind} title={item.title} />;
}
