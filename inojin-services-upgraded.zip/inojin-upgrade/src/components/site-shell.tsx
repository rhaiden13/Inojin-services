import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import * as Dialog from "@radix-ui/react-dialog";
import { ArrowUp, ArrowUpRight, Check, Copy, Heart, Menu, X } from "lucide-react";
import { site } from "@/lib/site";
import { copyText } from "@/lib/copy-text";

function linkClass(active: boolean) {
  return (
    "flex min-h-11 items-center px-3 text-sm font-semibold " +
    (active
      ? "text-teal-deep underline decoration-teal decoration-2 underline-offset-8"
      : "text-ink hover:text-teal-deep")
  );
}

function NavLinks({ onNavigate, vertical = false }: { onNavigate?: () => void; vertical?: boolean }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const services = pathname.startsWith("/services");
  const portfolio = pathname.startsWith("/portfolio");
  const about = pathname.startsWith("/about");
  const contact = pathname.startsWith("/contact");
  const home = pathname === "/";
  return (
    <ul className={vertical ? "flex flex-col gap-1" : "flex items-center gap-1"}>
      <li>
        <Link to="/" onClick={onNavigate} className={linkClass(home)} aria-current={home ? "page" : undefined}>
          Home
        </Link>
      </li>
      <li>
        <Link
          to="/services"
          search={{ category: "all", q: "", group: "all" }}
          onClick={onNavigate}
          className={linkClass(services)}
          aria-current={services ? "page" : undefined}
        >
          Services
        </Link>
      </li>
      <li>
        <Link to="/portfolio" onClick={onNavigate} className={linkClass(portfolio)} aria-current={portfolio ? "page" : undefined}>
          Portfolio
        </Link>
      </li>
      <li>
        <Link to="/about" onClick={onNavigate} className={linkClass(about)} aria-current={about ? "page" : undefined}>
          About
        </Link>
      </li>
      <li>
        <Link to="/contact" onClick={onNavigate} className={linkClass(contact)} aria-current={contact ? "page" : undefined}>
          Contact
        </Link>
      </li>
    </ul>
  );
}
export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-3 text-ink">
      <svg viewBox="0 0 36 36" className="size-9 shrink-0" aria-hidden="true">
        <rect width="36" height="36" fill="var(--color-navy)" />
        <path d="M10 26V10h12" fill="none" stroke="var(--color-paper)" strokeWidth="2.2" />
        <path d="M16 26h10V14" fill="none" stroke="var(--color-teal)" strokeWidth="2.2" />
      </svg>
      <span className="leading-none">
        <span className="block font-display text-xl font-semibold tracking-tight">Inojin</span>
        <span className="mt-1 block text-xs font-semibold uppercase tracking-widest text-ink-soft">Services</span>
      </span>
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 500);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-navy focus:px-4 focus:py-3 focus:text-paper"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-30 border-b border-line bg-paper">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-4 px-5 py-3">
          <Logo />
          <nav className="hidden lg:block" aria-label="Primary">
            <NavLinks />
          </nav>
          <div className="flex items-center gap-2">
            <Link
              to="/request"
              search={{ service: "" }}
              className="inline-flex min-h-11 items-center bg-teal-deep px-3 text-sm font-semibold text-paper hover:bg-navy sm:px-4"
            >
              <span className="sm:hidden">Request</span>
              <span className="hidden sm:inline">{site.copy.request}</span>
            </Link>
            <Dialog.Root open={open} onOpenChange={setOpen}>
              <Dialog.Trigger asChild>
                <button
                  type="button"
                  className="inline-flex size-11 items-center justify-center border border-line text-ink lg:hidden"
                  aria-label="Open menu"
                >
                  <Menu className="size-5" aria-hidden="true" />
                </button>
              </Dialog.Trigger>
              <Dialog.Portal>
                <Dialog.Overlay className="fixed inset-0 z-40 bg-navy/60" />
                <Dialog.Content className="fixed inset-y-0 right-0 z-50 flex w-[min(100%,20rem)] flex-col bg-paper px-5 py-4 shadow-none">
                  <div className="flex items-center justify-between">
                    <Dialog.Title className="font-display text-2xl text-ink">Menu</Dialog.Title>
                    <Dialog.Close asChild>
                      <button type="button" className="inline-flex size-11 items-center justify-center border border-line" aria-label="Close menu">
                        <X className="size-5" />
                      </button>
                    </Dialog.Close>
                  </div>
                  <Dialog.Description className="sr-only">Site sections</Dialog.Description>
                  <nav className="mt-6" aria-label="Mobile">
                    <NavLinks vertical onNavigate={() => setOpen(false)} />
                  </nav>
                  <Link
                    to="/request"
                    search={{ service: "" }}
                    onClick={() => setOpen(false)}
                    className="mt-6 inline-flex min-h-11 items-center justify-center bg-teal-deep px-4 font-semibold text-paper"
                  >
                    {site.copy.request}
                  </Link>
                </Dialog.Content>
              </Dialog.Portal>
            </Dialog.Root>
          </div>
        </div>
      </header>
      <main id="content" className="flex-1">
        {children}
      </main>
      <Footer />
      {showTop ? (
        <button
          type="button"
          className="fixed bottom-5 right-5 z-20 inline-flex size-11 items-center justify-center border border-line bg-paper text-ink shadow-none"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="Back to top"
        >
          <ArrowUp className="size-5" />
        </button>
      ) : null}
    </div>
  );
}

export function CopyButton({
  value,
  label,
  doneLabel = "Copied",
}: {
  value: string;
  label: string;
  doneLabel?: string;
}) {
  const [state, setState] = useState<"idle" | "done" | "failed">("idle");

  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button
        type="button"
        className="inline-flex min-h-11 items-center gap-2 border border-ink bg-paper px-4 text-sm font-semibold text-ink hover:bg-ink hover:text-paper"
        onClick={async () => {
          const ok = await copyText(value);
          setState(ok ? "done" : "failed");
          if (ok) window.setTimeout(() => setState("idle"), 2000);
        }}
      >
        {state === "done" ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
        {state === "done" ? doneLabel : label}
      </button>
      {state === "failed" ? (
        <span className="max-w-xs text-sm text-danger" role="status">
          Clipboard is blocked. Select the number below and copy it yourself.
        </span>
      ) : null}
    </span>
  );
}

export function ProfileLink({
  href,
  network,
  name,
}: {
  href: string;
  network: string;
  name: string;
}) {
  if (!href) {
    return (
      <div className="max-w-sm">
        <p className="font-semibold text-ink">
          {network}: {name}
        </p>
        <button
          type="button"
          disabled
          className="mt-2 inline-flex min-h-11 items-center border border-line px-4 text-sm font-semibold text-ink-soft"
        >
          Follow on {network}
        </button>
        <p className="mt-2 text-sm text-ink-soft">
          The button stays off until a real {network} URL is saved in the site settings. The page name is {name}.
        </p>
      </div>
    );
  }
  return (
    <div>
      <p className="font-semibold text-ink">
        {network}: {name}
      </p>
      <a
        href={href}
        target="_blank"
        rel="noreferrer"
        className="mt-2 inline-flex min-h-11 items-center border border-ink px-4 text-sm font-semibold text-ink hover:bg-ink hover:text-paper"
      >
        Follow on {network}
        <ArrowUpRight className="ml-2 size-4" aria-hidden="true" />
      </a>
    </div>
  );
}

export function DonationPanel({ compact = false }: { compact?: boolean }) {
  const [guide, setGuide] = useState(false);
  const number = site.gcash.number;
  return (
    <section id={compact ? undefined : "support"} className={compact ? "" : "scroll-mt-24 bg-foam"}>
      <div className={compact ? "" : "mx-auto w-full max-w-6xl px-5 py-16"}>
        <div className="border border-line bg-paper px-5 py-6 sm:px-8">
          <div className="flex items-center gap-3 text-teal-deep">
            <Heart className="size-5" aria-hidden="true" />
            <p className="text-xs font-semibold uppercase tracking-widest">Voluntary support</p>
          </div>
          <h2 className="mt-3 max-w-xl font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
            {site.copy.donationTitle}
          </h2>
          {compact ? (
            <p className="mt-4 max-w-2xl whitespace-pre-line text-ink-soft">{site.copy.donationNear}</p>
          ) : (
            <p className="mt-4 max-w-2xl whitespace-pre-line text-ink-soft">{site.copy.donationBody}</p>
          )}
          <dl className="mt-6 grid gap-4 border-t border-line pt-6 sm:grid-cols-3">
            <div>
              <dt className="text-xs font-semibold uppercase tracking-widest text-ink-soft">Payment method</dt>
              <dd className="mt-1 font-semibold">{site.gcash.method}</dd>
            </div>
            <div>
              <dt className="text-xs font-semibold uppercase tracking-widest text-ink-soft">Account name</dt>
              <dd className="mt-1 font-semibold">{site.gcash.accountName}</dd>
            </div>
            <div>
              <dt className="text-xs font-semibold uppercase tracking-widest text-ink-soft">GCash number</dt>
              <dd className="mt-1 font-semibold tracking-wide">{number}</dd>
            </div>
          </dl>
          <p className="mt-4 text-sm text-ink-soft">{site.copy.donationVerify}</p>
          <p className="mt-3 text-sm text-ink">
            Donations are sent by you inside GCash. This website does not receive, total, or confirm them.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <CopyButton value={number} label="Copy GCash Number" />
            <button
              type="button"
              className="inline-flex min-h-11 items-center bg-teal-deep px-4 text-sm font-semibold text-paper hover:bg-navy"
              onClick={() => setGuide((value) => !value)}
              aria-expanded={guide}
            >
              Support Us via GCash
            </button>
            {compact ? (
              <Link to="/support" className="inline-flex min-h-11 items-center px-2 text-sm font-semibold text-teal-deep underline underline-offset-4">
                Read the full note
              </Link>
            ) : (
              <Link to="/services" search={{ category: "all", q: "", group: "all" }} className="inline-flex min-h-11 items-center px-2 text-sm font-semibold text-teal-deep underline underline-offset-4">
                Back to Our Services
              </Link>
            )}
          </div>
          {guide ? (
            <ol className="mt-4 list-decimal space-y-2 bg-foam px-5 py-4 pl-9 text-sm text-ink">
              <li>Open the GCash app yourself. Do not share an MPIN or OTP with anyone.</li>
              <li>
                Send to <strong>{number}</strong> and check that the recipient name is <strong>{site.gcash.accountName}</strong>.
              </li>
              <li>There is no donation goal, progress bar, or automatic thank-you receipt on this site.</li>
              {site.gcash.paymentLink ? (
                <li>
                  A payment link was supplied:{" "}
                  <a className="font-semibold text-teal-deep underline" href={site.gcash.paymentLink}>
                    Open the supplied GCash link
                  </a>
                </li>
              ) : (
                <li>No GCash payment link has been added. Use the number and name above.</li>
              )}
            </ol>
          ) : null}
          {site.gcash.qrImage ? (
            <img src={site.gcash.qrImage} alt="Supplied GCash QR code" className="mt-6 h-40 w-40 border border-line object-contain" />
          ) : (
            <p className="mt-6 text-sm text-ink-soft">A GCash QR image can be placed here after you supply one. None is shown until then.</p>
          )}
          <p className="mt-6 font-display text-xl text-ink">{site.copy.donationThanks}</p>
          {!compact ? (
            <div className="mt-8 grid gap-6 border-t border-line pt-6 sm:grid-cols-2">
              <ProfileLink href={site.facebookUrl} network="Facebook" name={site.facebookName} />
              <ProfileLink href={site.instagramUrl} network="Instagram" name={site.instagramName} />
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-line bg-navy text-paper">
      <div className="mx-auto grid w-full max-w-6xl gap-10 px-5 py-14 md:grid-cols-12">
        <div className="md:col-span-4">
          <p className="font-display text-3xl">Inojin Services</p>
          <p className="mt-3 max-w-xs text-sm text-paper/80">{site.tagline}</p>
          <p className="mt-4 text-sm text-paper/80">{site.copy.socialNote}</p>
        </div>
        <div className="md:col-span-2">
          <p className="text-xs font-semibold uppercase tracking-widest text-paper/60">Visit</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link to="/services" search={{ category: "all", q: "", group: "all" }} className="underline-offset-4 hover:underline">Services</Link></li>
            <li><Link to="/portfolio" className="underline-offset-4 hover:underline">Portfolio</Link></li>
            <li><Link to="/faq" className="underline-offset-4 hover:underline">FAQ</Link></li>
            <li><Link to="/about" className="underline-offset-4 hover:underline">About</Link></li>
          </ul>
        </div>
        <div className="md:col-span-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-paper/60">Contact</p>
          <p className="mt-3 text-sm">Phone</p>
          <a className="font-semibold underline decoration-teal underline-offset-4" href={`tel:${site.phoneTel}`}>
            {site.phoneDisplay}
          </a>
          <div className="mt-3">
            <CopyButton value={site.phoneDisplay} label="Copy phone number" />
          </div>
          <div className="mt-3 flex flex-col items-start gap-2 text-sm">
            <a
              href={site.facebookUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-10 items-center gap-2 underline decoration-teal underline-offset-4 hover:text-teal"
            >
              Facebook · {site.facebookName}
              <ArrowUpRight className="size-4" aria-hidden="true" />
            </a>
            <a
              href={site.instagramUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-10 items-center gap-2 underline decoration-teal underline-offset-4 hover:text-teal"
            >
              Instagram · {site.instagramName}
              <ArrowUpRight className="size-4" aria-hidden="true" />
            </a>
          </div>
        </div>
        <div className="md:col-span-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-paper/60">Support</p>
          <p className="mt-3 text-sm text-paper/80">
            GCash · {site.gcash.accountName}
            <br />
            <span className="font-semibold text-paper">{site.gcash.number}</span>
          </p>
          <div className="mt-3">
            <CopyButton value={site.gcash.number} label="Copy GCash number" />
          </div>
          <Link to="/support" className="mt-4 inline-flex min-h-11 items-center text-sm font-semibold text-paper underline decoration-teal underline-offset-4">
            Support section
          </Link>
        </div>
      </div>
      <div className="border-t border-paper/15">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap gap-x-5 gap-y-2 px-5 py-4 text-sm text-paper/70">
          <Link to="/privacy" className="underline-offset-4 hover:underline">Privacy</Link>
          <Link to="/terms" className="underline-offset-4 hover:underline">Terms</Link>
          <Link to="/faq" className="underline-offset-4 hover:underline">FAQ</Link>
          <span>Donations are optional and separate from service payments.</span>
        </div>
      </div>
    </footer>
  );
}

export function PageIntro({
  eyebrow,
  title,
  lede,
}: {
  eyebrow: string;
  title: string;
  lede: string;
}) {
  return (
    <header className="border-b border-line">
      <div className="mx-auto w-full max-w-6xl px-5 py-12 sm:py-16">
        <p className="text-xs font-semibold uppercase tracking-widest text-teal-deep">{eyebrow}</p>
        <h1 className="mt-3 max-w-3xl font-display text-4xl font-semibold tracking-tight text-ink sm:text-5xl">{title}</h1>
        <p className="mt-4 max-w-2xl text-lg text-ink-soft">{lede}</p>
      </div>
    </header>
  );
}
