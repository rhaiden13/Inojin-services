# Inojin Services

Public website for Inojin Services. Phone, computer, and network help; graphic design; websites; and a voluntary GCash note.

## Edit the business

- `src/lib/site.ts` — name, phone, Facebook and Instagram URLs, inquiry email, GCash number, account name, optional QR path, and the public sentences.
- `src/lib/catalog.ts` — services. Set `priceAmount` only when you have a real price. Leave it `null` until then.
- `src/lib/portfolio.ts` — gallery items. Keep client work labeled only when a client allowed it.

Leave a social URL empty rather than guessing. Buttons stay disabled until a real link is saved.

## What the inquiry form does

There is no database. The form checks the fields, shows a review, copies the message, and opens SMS to the phone in `site.ts` (or email, if `inquiryEmail` is set). The site does not claim the message was received.

Uploads are not stored. Only file names can be added to the message.

## Not included, on purpose

Sign-in, stored inquiries, private file hosting, card payments, a fake GCash QR, invented reviews, and invented prices. Those need real accounts and should be added only when they exist.

## Run

```
npm run dev
```

The dev server is part of this project’s preview setup. Production uses `npm run build`.
